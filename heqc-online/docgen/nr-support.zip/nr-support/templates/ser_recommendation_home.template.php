<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "ser_recommendation_home";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Self-evaluation report', 'Manage recommendation writers', 'Assign user and access dates');
	$this->formHidden["DELETE_RECORD"] = "";
?>