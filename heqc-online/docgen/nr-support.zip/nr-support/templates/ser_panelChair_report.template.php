<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "ser_panelChair_report";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Process desktop evaluation', 'Manage chair report');
?>