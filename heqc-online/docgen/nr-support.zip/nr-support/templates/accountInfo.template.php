<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "accountInfo";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('My account', 'Account Info');
?>