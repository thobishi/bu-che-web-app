<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "rg_meeting_report";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Reports', 'Reference group meeting Report');
?>