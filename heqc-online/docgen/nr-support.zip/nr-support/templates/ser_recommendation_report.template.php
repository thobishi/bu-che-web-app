<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "ser_recommendation_report";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Self-evaluation report', 'Manage recommendation writer', 'Process recommendation - Manage reports');
	$this->formHidden["DELETE_RECORD"] = "";
?>