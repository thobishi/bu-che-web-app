<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "manageGroups";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Admin', 'Manage Groups');
?>