<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "ser_recommWriterCriteriaEvaluation";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Self-evaluation report', "Recommendation's evaluation against criteria");
?>