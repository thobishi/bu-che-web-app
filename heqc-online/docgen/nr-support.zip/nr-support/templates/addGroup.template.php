<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "addGroup";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Admin', 'Manage groups', 'Add group');
?>