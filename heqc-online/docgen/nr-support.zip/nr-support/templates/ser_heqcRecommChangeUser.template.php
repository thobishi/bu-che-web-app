<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "ser_heqcRecommChangeUser";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Self-evaluation report', 'Upload recommendation report to the HEQC', 'Send Application to colleague');
	$this->formHidden["DELETE_RECORD"] = "";
?>