<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "manageRGMeetings";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Admin', 'Manage RG Meetings');
?>