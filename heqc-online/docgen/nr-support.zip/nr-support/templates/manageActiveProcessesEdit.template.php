<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "manageActiveProcessesEdit";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Admin', 'Manage active processes', 'Edit');
?>