<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "ser_upload_files_preview";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Self-evaluation report - readOnly');
	$this->formHidden["DELETE_RECORD"] = "";
?>