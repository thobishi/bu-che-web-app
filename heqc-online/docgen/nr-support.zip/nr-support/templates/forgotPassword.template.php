<?php
	$this->title			= "CHE Accreditation";
	$this->bodyHeader		= "formHead";
	$this->body				= "forgotPassword";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar 	= array('User information');;
?>
