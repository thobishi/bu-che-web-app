<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "ser_NRC_report_complete";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Self-evaluation report', 'Process upload  National Review Committee - Finish');
?>