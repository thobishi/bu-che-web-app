<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "ser_llb";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Self-evaluation report');
	$this->formHidden["DELETE_RECORD"] = "";
?>