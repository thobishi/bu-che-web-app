<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "report_nr_progress_edit";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Reports', 'Progress report of National Reviews');
?>