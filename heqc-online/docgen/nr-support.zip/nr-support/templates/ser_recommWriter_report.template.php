<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "ser_recommWriter_report";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Self-evaluation report', 'Recommendations to write', 'Upload recommendation report');
	$this->formHidden["DELETE_RECORD"] = "";
?>