<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "ser_prelim_analysis_reports";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Self-evaluation report', 'Manage preliminary analysis and panel members', 'Process desktop evaluation - Manage reports');
	$this->formHidden["DELETE_RECORD"] = "";
?>