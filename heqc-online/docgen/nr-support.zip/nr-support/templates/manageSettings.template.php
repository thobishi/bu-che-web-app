<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "manageSettings";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Admin', 'Manage Settings');
?>