<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "inst_reports_recommendation";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Reports', 'SERs for recommendation');
?>