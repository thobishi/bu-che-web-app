<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "ser_academic_demographic_race";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Self-evaluation report', 'Academic staff', 'Table 4.6 B2 Demographic profile of staff in the Department/Unit (Race)');
?>