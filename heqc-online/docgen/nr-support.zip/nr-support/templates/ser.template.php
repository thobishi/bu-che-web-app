<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "ser";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Self-evaluation report');
	$this->formHidden["DELETE_RECORD"] = "";
?>