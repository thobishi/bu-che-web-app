<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "nrc_member_report";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Reports', 'NRC member Report');
?>