<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "ser_budget_expenses";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Self-evaluation report', 'Table 4.5 B Expenses');
	$this->formHidden["DELETE_RECORD"] = "";
?>