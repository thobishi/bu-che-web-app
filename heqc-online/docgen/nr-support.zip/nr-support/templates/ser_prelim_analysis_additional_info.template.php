<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "ser_prelim_analysis_additional_info";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Self-evaluation report', 'Manage preliminary analysis and panel members', 'Process desktop evaluation - Additional information');
	$this->formHidden["DELETE_RECORD"] = "";
?>