<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "ser_RC_ChangeUser";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Self-evaluation report', 'Upload Reference Committee report', 'Send Application to colleague');
	$this->formHidden["DELETE_RECORD"] = "";
?>