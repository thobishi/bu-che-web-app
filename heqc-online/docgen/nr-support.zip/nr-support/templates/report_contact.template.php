<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "report_contact";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Reports', 'Institutions contact list');
?>