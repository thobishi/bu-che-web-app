<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "ser_prelimChangeUser";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Self-evaluation report', 'Manage preliminary analysis and panel members', 'Send Application to colleague');
	$this->formHidden["DELETE_RECORD"] = "";
?>