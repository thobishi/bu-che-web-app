<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "ser_budget_student";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Self-evaluation report', 'Budget', 'Table 4.5 C1 Student Support - Number of students');
?>