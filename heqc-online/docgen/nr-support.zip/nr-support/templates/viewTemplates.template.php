<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "viewTemplates";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Admin', 'View templates');
	$this->formHidden["DELETE_RECORD"] = "";
?>