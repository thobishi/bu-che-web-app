<?php
    $this->title            = "CHE National Reviews";
    $this->bodyHeader        = "formHead";
    $this->body                = "improvement_plan";
    $this->bodyFooter        = "formFoot";
    $this->NavigationBar    = array('Reports', 'Improvement Plan');
?>