<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "ser_prelimSubmit";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Analyst report', 'Submission to the CHE');
?>