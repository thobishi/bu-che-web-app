<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "report_inst_progress";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Reports', 'Institution progress report');
?>