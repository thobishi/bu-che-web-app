<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "ser_heqcRecommendation_report";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Self-evaluation report', 'Upload Recommendation Report to the HEQC', 'Process upload HEQC recommendation - Manage reports');
	$this->formHidden["DELETE_RECORD"] = "";
?>