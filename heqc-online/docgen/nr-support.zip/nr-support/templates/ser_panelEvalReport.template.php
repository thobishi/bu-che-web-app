<?php
	$this->title			= "CHE National Reviews";
	$this->bodyHeader		= "formHead";
	$this->body				= "ser_panelEvalReport";
	$this->bodyFooter		= "formFoot";
	$this->NavigationBar	= array('Self-evaluation report', 'Panel member report and recommendations');
	$this->formHidden["DELETE_RECORD"] = "";
?>