<?php
	$this->formFields["panel_user_ref"]->fieldValue = Settings::get('currentUserID');
?>