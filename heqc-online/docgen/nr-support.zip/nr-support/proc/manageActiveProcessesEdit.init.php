<?php
	// $this->pr($_POST);
	// $user_ref = readPost('FLD_user_ref');
	// $active_processes_id = $this->dbTableInfoArray['active_processes']->dbTableCurrentID;
	// $this->pr($this);
	// $to = $this->db->getValueFromTable("users", "user_id", $user_ref, "email");
	// $subject = "Process request";
	// $message = $this->getTextContent ("generic", "colleagueRequest");
	// $this->Email->misMailByName($to, $mail_subject, $mail_content);

	// $GIVETO = $this->db->getValueFromTable("lkp_title","lkp_title_id",$this->db->getValueFromTable("users","user_id",$_POST["FLD_user_ref"],"title_ref"),"lkp_title_desc").' '.$this->db->getValueFromTable("users","user_id",$_POST["FLD_user_ref"],"name").' '.$this->db->getValueFromTable("users","user_id",$_POST["FLD_user_ref"],"surname");

	// $processId = $this->db->getValueFromTable("processes","processes_id",$this->db->getValueFromTable("active_processes","active_processes_id",$this->dbTableInfoArray[$this->dbTableCurrent]->dbTableCurrentID,"processes_ref"),"processes_id");

	
	// getValueFromTable($table, $field, $key, $ret){
	// $SQL = "SELECT $ret FROM `$table` WHERE `$field` = :key";
	
	// $this->workflowDescription($active_processes_id,$processId);

	// $this->pr($this->workflowDescription($active_processes_id,$processId));
 ?>
