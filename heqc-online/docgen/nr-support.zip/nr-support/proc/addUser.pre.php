<?php
	// $this->formFields['registration_date']->fieldValue = date("Y-m-d"); 
	
	// if (isset($this->prev_workFlowID) && ($this->prev_workFlowID > 0)) {
		// $ID = $this->prev_workFlowID;		
	// } else {
		// if ( isset ($_POST["LAST_WORKFLOW_ID"]) ) {
			// $ID = $_POST["LAST_WORKFLOW_ID"];
		// } else {
			// $ID = $_POST["FLOW_ID"];
		// }
	// }
	
	// $link = "javascript:moveto(".$ID.");|off";
?>
<script>
	// $("#action_previous")
		// .find('a').attr('href', '<?php echo $link; ?>');
</script>