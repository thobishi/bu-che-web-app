<h3>Upload evaluator report</h3>
<?php
	$this->makeLink("analyst_report_doc", "Upload evaluator report");
?>
