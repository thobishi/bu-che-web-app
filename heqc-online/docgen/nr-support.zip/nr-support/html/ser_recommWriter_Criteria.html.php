<h3>Criteria evaluation comparison</h3>
<?php
	$this->displayCriteriaComparison();
?>