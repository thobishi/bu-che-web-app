<div class="alert alert-success">
	Your process has been <strong>completed</strong>.<br />
<?php
	if ($this->addProcessText > "") {
		echo 'This is what happened with the process:<br><strong>' . $this->addProcessText . '</strong>';
	}
?>
</div>