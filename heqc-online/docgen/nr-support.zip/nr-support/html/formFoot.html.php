	</div>
	</div></div>
	</form>
</div>

<div id="infoModal" class="modal hide fade">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
		<div class="print hidden">
			<a class="btn pdfDownloadBtn" href="#" target="" title="Download Pdf version" >Download PDF version</a>
		</div>
		<h3></h3>
	</div>
	<div class="modal-body">
	</div>
	<div class="modal-footer">
		<a href="#" data-dismiss="modal" class="btn btn-primary">Ok</a>
	</div>
</div>

<div id="fileUploader" class="modal hide fade">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
		<h3>Modal header</h3>
	</div>
	<div class="modal-body">
	</div>
	<div class="modal-footer">
		<a href="#" data-dismiss="modal" class="btn">Close</a>
	</div>
</div>