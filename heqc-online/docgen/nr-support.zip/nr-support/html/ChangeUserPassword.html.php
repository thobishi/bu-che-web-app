<?php
	$this->showBootstrapField('newPassword', 'New Password');
	$this->showBootstrapField('newPasswordRetype', 'Re-type new password');
	
?>