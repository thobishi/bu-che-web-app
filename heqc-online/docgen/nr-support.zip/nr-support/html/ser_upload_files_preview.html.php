<h3>SER and Sign-off Cover sheet</h3>
<?php
	echo '<div class="cover_sheet">';
	$this->makeLink("ser_doc", "SER document");
	echo '<br />';
	$this->makeLink("signoff_doc", "SER sign-off document");
	echo '</div>';
?>