<h3>Screening</h3>
<?php
	echo '<div class="row-fluid">';
	$this->displayProgrammeInfo();
	echo '<div class="clear"></div>';
	echo '</div>';
	
	echo '<div class= "alert alert-block alert-success alert-large">';
	echo "You have indicated that the SER has satiesfied all screening criteria. The screening process is now complete. Click on '<strong>Next</strong>' to proceed to the next user and process";
	echo '</div>';
?>