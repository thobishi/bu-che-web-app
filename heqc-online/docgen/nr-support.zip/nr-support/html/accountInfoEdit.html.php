<?php
	$this->showBootstrapField('name', 'Name');
	$this->showBootstrapField('surname', 'Surname');
	$this->showBootstrapField('title_ref', 'Title');
	$this->showBootstrapField('email', 'Email');
	$this->showBootstrapField('contact_nr', 'Contact number');
	$this->showBootstrapField('contact_cell_nr', 'Contact cellular number');
?>