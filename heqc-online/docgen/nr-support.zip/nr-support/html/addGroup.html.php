<h3>Add new group</h3>
<?php
	
	// $this->showField('registration_date');
	$this->showBootstrapField('sec_group_desc', 'Group name:');
	$this->showBootstrapField('sec_group_type', 'Group type:');	
	$this->showBootstrapField('goal', 'Group goal:');
	// $this->showBootstrapField('email', 'E-mail:');	

	// $this->showBootstrapField('contact_nr', 'Contact Number:');
	// $this->showBootstrapField('contact_cell_nr', 'Mobile Cell number:');	
	// $this->showBootstrapField('active', 'Login status:');	
?>