<h3>Preview and submit</h3>

<?php	
	$prog_id = $this->dbTableInfoArray["nr_programmes"]->dbTableCurrentID;
	$this->previewReadOnly();
?>

<div class="back-to-top">[<a href="#">Back to Top</a>]</div>

<link rel="stylesheet" type="text/css" media="print" href="css_print/print.css">
