<?php
	$this->showField('registration_date');
	$this->showBootstrapField('title_ref', 'Title:');
	$this->showBootstrapField('name', 'Name:');	
	$this->showBootstrapField('surname', 'Surname:');
	$this->showBootstrapField('email', 'E-mail:');	
	 $this->showBootstrapField('password', 'Password:');
	$this->showBootstrapField('contact_nr', 'Contact Number:');
	$this->showBootstrapField('contact_cell_nr', 'Mobile Cell number:');	
	$this->showBootstrapField('active', 'Login status:');	
?>