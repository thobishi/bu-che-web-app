<?php
	echo $this->element('homePage', compact('groupProcesses', 'processes', 'processHeading', 'processRef'));
?>
