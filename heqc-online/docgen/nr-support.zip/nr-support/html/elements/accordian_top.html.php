<div class="accordion-group">
	<div class="accordion-heading">
	  <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionHome" href="#collapse_<?php echo $collapse; ?>">
		<h3><?php echo $accHeader; ?></h3>
	  </a>
	</div>
	<div id="collapse_<?php echo $collapse; ?>" class="accordion-body collapse in">
		<div class="accordion-inner">