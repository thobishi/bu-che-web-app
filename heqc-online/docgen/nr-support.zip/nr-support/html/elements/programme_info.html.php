<div class="well headerInfo span6">
<?php
	echo '<strong>' . $institution_name . '</strong>';
	echo '<br /><br />';
	echo $nr_programme_name . ' (' . $nr_national_review_id . ')';
	echo '<br /><br />';
	echo 'Administrator: ' . $admInfoArr["name"] . ' ' . $admInfoArr["surname"] . ' (' . $admInfoArr["email"] . $contactNr . ')';
?>
</div>

