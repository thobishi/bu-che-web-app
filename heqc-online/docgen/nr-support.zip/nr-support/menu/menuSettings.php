<?php
$menuAlways = array();
array_push ($menuAlways,"1");
array_push ($menuAlways,"2");
array_push ($menuAlways,"4");
?>
