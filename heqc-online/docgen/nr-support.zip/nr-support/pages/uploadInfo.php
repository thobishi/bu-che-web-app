<html>
	<head>
		<title>File Upload</title>
		<link rel=STYLESHEET TYPE="text/css" href="/var/www/nr-support/styles.css" title="Normal Style">
	
	</head>
	<body onblur="doFocus();">
		<table width="80%" align=center>
			<tr>
				<td align=center>
					After the upload has completed, the "File Upload" page will close automatically and you will be prompted to close this window.
				</td>
			</tr>
		</table>
	</body>
</html>

