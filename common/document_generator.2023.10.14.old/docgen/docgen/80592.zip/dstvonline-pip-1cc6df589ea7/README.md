# pip

This repo houses:
- The PIP API
- The PIP UI
- The PIP AlertServer

Run ```mvn spring-boot:run``` to start the server. This command will install node, npm and run npm install and build the frontend because of this you can not run the project straight from you IntelliJ IDE.

If you are using a proxy for npm there might be problems using this project.

The project will start on port ```:2332```


