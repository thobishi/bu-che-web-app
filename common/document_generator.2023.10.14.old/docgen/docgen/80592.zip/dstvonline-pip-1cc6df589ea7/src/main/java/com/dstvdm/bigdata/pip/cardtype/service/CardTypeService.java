package com.dstvdm.bigdata.pip.cardtype.service;

import com.dstvdm.bigdata.pip.cardtype.entity.CardType;
import com.dstvdm.bigdata.pip.cardtype.resource.CardTypeRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class CardTypeService {

    private CardTypeRepository repository;

    public List<CardType> getCardTypes() {
        return repository.findAll();
    }

    public Optional<CardType> getCardType(Long id) {
        return repository.findById(id);
    }
}
