package com.dstvdm.bigdata.pip.card.resource;

import com.dstvdm.bigdata.pip.card.entity.Card;
import com.dstvdm.bigdata.pip.carddata.entity.CardData;
import com.dstvdm.bigdata.pip.cardtype.entity.CardType;
import com.dstvdm.bigdata.pip.common.ViewableStatus;
import lombok.Data;
import lombok.extern.java.Log;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.*;

@Log
@Data
@Repository
public class TemplateCardRepository {

    private final JdbcTemplate jdbcTemplate;

    public List<Card> getTaggedCardList(List<String> tags) {
        return jdbcTemplate.query("SELECT card.*, card_data.data, card_data.created, " +
                        "card_data.status AS card_data_status FROM card " +
                        "INNER JOIN card_data ON latest_card_data_id=card_data.id " +
                        "WHERE card.status = 0 AND (" + buildSqlGetCards(tags) + ")",
                (rs, rowNum) -> rowMapCardWithCardData(rs)
        );
    }

    public List<Card> getCardListForCollection(String collectionReference) {
        return jdbcTemplate.query("select card.* from cardcollection INNER JOIN " +
                        "collection_card ON cardcollection.id=collection_card.collection_id INNER JOIN " +
                        "card ON collection_card.card_id=card.id " +
                        "WHERE cardcollection.reference='"+collectionReference+"' AND card.status=0",
                (rs, rowNum) -> rowMapCard(rs)
        );
    }

    public List<Card> getTaggedCardListForCollection(String collectionReference, List<String> tags) {
        return jdbcTemplate.query("select card.*, card_data.data, card_data.created, card_data.status AS card_data_status " +
                        "from cardcollection INNER JOIN " +
                        "collection_card ON cardcollection.id=collection_card.collection_id INNER JOIN " +
                        "card ON collection_card.card_id=card.id LEFT JOIN card_data ON latest_card_data_id=card_data.id " +
                        "WHERE cardcollection.reference='"+collectionReference+"' AND card.status=0 AND (" + buildSqlGetCards(tags) + ")",
                (rs, rowNum) -> rowMapCardWithCardData(rs)
        );
    }

    public List<Card> findEmptyCards() {
        return jdbcTemplate.query("SELECT * FROM card WHERE status = 0 AND NOT EXISTs " +
                        "(SELECT * FROM card_data WHERE card.id = card_data.card_id);",
                (rs, rowNum) -> rowMapCard(rs)
        );
    }

    public List<Card> findEmptyCards(Set<Card> cards) {
        return jdbcTemplate.query("SELECT * FROM card WHERE status = 0 AND NOT EXISTs " +
                        "(SELECT * FROM card_data WHERE card.id = card_data.card_id) AND card.id IN (" +buildCardIds(cards)+");",
                (rs, rowNum) -> rowMapCard(rs)
        );
    }

    public List<Card> findEmptyCards(List<String> tags) {
        return jdbcTemplate.query("SELECT * FROM card WHERE status = 0 AND (" + buildSqlGetCards(tags) + ") AND NOT EXISTs " +
                        "(SELECT * FROM card_data WHERE card.id = card_data.card_id);",
                (rs, rowNum) -> rowMapCard(rs)
        );
    }

    public List<Card> findEmptyCards(Set<Card> cards, List<String> tags) {
        return jdbcTemplate.query("SELECT * FROM card WHERE status = 0 AND (" + buildSqlGetCards(tags) + ") AND NOT EXISTs " +
                        "(SELECT * FROM card_data WHERE card.id = card_data.card_id) AND card.id IN (" +buildCardIds(cards)+");",
                (rs, rowNum) -> rowMapCard(rs)
        );
    }

    private Card rowMapCard(ResultSet rs) throws SQLException {
        CardType cardType = new CardType();
        cardType.setId(rs.getLong("card_type_id"));
        Card card = new Card(rs.getString("title"), rs.getString("description"),
                rs.getString("reference"), cardType,
                rs.getString("tags"));
        Double lowerBound = rs.getDouble("lower_bound");
        card.setLowerBound(rs.wasNull() ? null : lowerBound);
        Double upperBound = rs.getDouble("upper_bound");
        card.setUpperBound(rs.wasNull() ? null : upperBound);
        card.setStatus(ViewableStatus.values()[rs.getInt("status")]);
        card.setId(rs.getLong("id"));
        return card;
    }

    private Card rowMapCardWithCardData(ResultSet rs) throws SQLException {
        Timestamp created = rs.getTimestamp("created");
        CardData cardData = null;
        if (!rs.wasNull()) {
            cardData = new CardData(rs.getString("data"), created, rs.getString("card_data_status"));
        }
        CardType cardType = new CardType();
        cardType.setId(rs.getLong("card_type_id"));
        Card card = new Card(rs.getString("title"), rs.getString("description"),
                rs.getString("reference"), cardType,
                rs.getString("tags"));
        Double lowerBound = rs.getDouble("lower_bound");
        card.setLowerBound(rs.wasNull() ? null : lowerBound);
        Double upperBound = rs.getDouble("upper_bound");
        card.setUpperBound(rs.wasNull() ? null : upperBound);
        card.setStatus(ViewableStatus.values()[rs.getInt("status")]);
        card.setId(rs.getLong("id"));
        card.setLatestCardData(cardData);
        return card;
    }

    public Set<String> findAllTags() {
        Set<String> tagSet = new TreeSet<>();

        jdbcTemplate.query("SELECT card.tags FROM card WHERE status = 0",
                (rs, rowNum) -> {
                    String tagsString = rs.getString("tags");
                    List<String> cardTagList = new ArrayList<>();
                    if (tagsString != null) {
                        cardTagList = Arrays.asList(rs.getString("tags").split(","));
                    }
                    return cardTagList;
                }
        ).forEach(tagSet::addAll);

        return tagSet;
    }

    private String buildSqlGetCards(List<String> tags) {
        List<String> tagsList = new ArrayList<>();
        for (String tag : tags) {
            tagsList.add("LOWER(tags) LIKE '%" + tag.toLowerCase() + "%'");
        }
        return String.join(" or ", tagsList);
    }

    private String buildCardIds(Set<Card> cards) {
        List<String> cardIdList = new ArrayList<>();
        for (Card card: cards) {
            cardIdList.add(card.getId().toString());
        }
        return String.join(",", cardIdList);
    }

    public List<CardData> getCardData(String card_ref, String datepriorto, String numocc) {
        log.info("SELECT card.*, card_data.data, card_data.status AS card_data_status, card_data.card_id, card_data.created FROM card INNER JOIN " +
                "card_data ON card.id=card_data.card_id " +
                "WHERE card.status=0 AND card_data.created < CONVERT_TZ('"+datepriorto.replace('T', ' ')+"','+00:00','-2:00') and card.reference IN ('"+card_ref+"') order by card_data.created desc LIMIT "+numocc);
        return jdbcTemplate.query("SELECT card.*, card_data.data, card_data.status AS card_data_status, card_data.card_id, card_data.created FROM card INNER JOIN " +
                        "card_data ON card.id=card_data.card_id " +
                        "WHERE card.status=0 AND card_data.created < CONVERT_TZ('"+datepriorto.replace('T', ' ')+"','+00:00','-2:00') and card.reference IN ('"+card_ref+"') order by card_data.created desc LIMIT "+numocc,
                (rs, rowNum) -> mapCardData(rs)
        );
    }


    private CardData mapCardData(ResultSet rs) throws SQLException {
        CardType cardType = new CardType();
        cardType.setId(rs.getLong("card_type_id"));
        Card card = new Card(rs.getString("title"), rs.getString("description"),
                rs.getString("reference"), cardType, rs.getString("tags"));
        CardData cardData = new CardData(rs.getString("data"), rs.getTimestamp("created"),
                rs.getString("card_data_status"));
        cardData.setCard(card);
        return cardData;
    }


}
