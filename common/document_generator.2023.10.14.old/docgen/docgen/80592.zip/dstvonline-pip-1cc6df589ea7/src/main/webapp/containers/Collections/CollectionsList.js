import React, {Component} from 'react';
import PropTypes from 'prop-types';
import {Button, withStyles} from '@material-ui/core';
import axios from "axios/index";
import {connect} from "react-redux";
import CollectionGrid from "../../components/CollectionGrid/CollectionGrid";

const styles = theme => ({
    title: {
        margin: "30px",
    },
    gridItem: {
        border: '1px solid grey',
        borderRadius: '5px',
        margin: '2px',
    },
    badge: {
        float: 'right',
        fontSize: 20,
    },
    avatar: {
        backgroundColor: theme.palette.secondary.main
    },
});

class CollectionsList extends Component {

    constructor(props) {
        super(props);
        this.state = {
            collections: [],
            homeCollection: localStorage.getItem('homeCollection') ? localStorage.getItem('homeCollection') : null,
        };

        if (this.state.homeCollection === null) {
            this.props.onShowSnackbar("Choose a collection to set it as your home collection")
        }

        axios.get('/api/card-collection')
            .then(response => {
                this.setState({collections: response.data})
            })
            .catch(error => {
                console.log("error getting cards", error);
            });

    }

    checkHomeCollection = (reference, event) => {

        if (event.target.attributes.getNamedItem('donotroute') === null)
        {
            if (this.state.homeCollection === null) {
                localStorage.setItem('homeCollection', reference);
            }

            this.props.history.push({
                pathname: '/card-collection/' + reference,
            });
        }
    };

    resetHomeCollection = () => {
        this.setState({homeCollection: null});
        localStorage.removeItem('homeCollection');
        this.props.onShowSnackbar("Choose a collection to set it as your home collection")
    };

    render() {
        const {classes} = this.props;
        return (
            <div>
                <Button style={{right: '5px', position: 'absolute'}} variant="outlined" color="primary"
                        onClick={this.resetHomeCollection}>
                    Reset Home
                </Button>
                <h1 className={classes.title}>Collections</h1>
                <div style={{margin: '10px'}}>
                    <CollectionGrid
                        collections={this.state.collections}
                        homeCollection={this.state.homeCollection}
                        history={this.props.history}
                        setHomeCollection={(reference,event) => this.checkHomeCollection(reference,event)}
                    />
                </div>
            </div>
        );
    }

}

CollectionsList.propTypes = {
    classes: PropTypes.object.isRequired,
};

const mapDispatchToProps = dispatch => {
    return {
        onShowSnackbar: (snackbar) => dispatch({type: 'SHOW_SNACKBAR', value: snackbar})
    }
};

export default connect(null, mapDispatchToProps)(withStyles(styles)(CollectionsList));

