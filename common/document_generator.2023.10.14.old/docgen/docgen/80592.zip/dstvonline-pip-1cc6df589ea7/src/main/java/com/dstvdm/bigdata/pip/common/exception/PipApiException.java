package com.dstvdm.bigdata.pip.common.exception;


abstract class PipApiException extends RuntimeException {

    PipApiException() {
    }

    PipApiException(String message) {
        super(message);
    }

    PipApiException(String message, Throwable cause) {
        super(message, cause);
    }

    PipApiException(Throwable cause) {
        super(cause);
    }

    PipApiException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
