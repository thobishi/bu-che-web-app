import React from 'react';
import {Avatar, CardHeader, Grid, Icon, IconButton, Menu, MenuItem, withStyles} from "@material-ui/core";
import Link from "react-router-dom/es/Link";
import MoreVertIcon from "@material-ui/icons/MoreVert";
import {connect} from "react-redux";


const styles = theme => ({
    gridItem: {
        border: '1px solid grey',
        borderRadius: '5px',
        margin: '2px',
    },
    badge: {
        float: 'right',
        fontSize: 20,
    },
    iconbadge: {
        float: 'right',
        fontSize: 20,
        position:'relative',
        bottom:0,
    },
    avatar: {
        backgroundColor: theme.palette.secondary.main

    },
    pointer: {
        cursor: 'pointer'
    }
});


class CollectionGrid extends React.Component
{

 state = {anchorEl:null,
 curr_reference:null
 };

 handleClick = (event, reference) => {
    this.setState({ anchorEl: event.currentTarget,
    curr_reference: reference});
  };

 handleClose = () => {
    this.setState({ anchorEl: null });
 };



  render()
  {

    const { classes } = this.props;
    const open = Boolean(this.state.anchorEl);

    let editcollectionbtn = null;

    if (this.props.userRole === 'ADMIN')
    {
     editcollectionbtn = (<MoreVertIcon donotroute='1'/>)
    }

    return (
        <Grid container>
            {this.props.collections.map((collection, key) => (
                <Grid item xs
                      key={key}
                      className={classes.gridItem}
                >
                        <CardHeader className={classes.pointer}
                            onClick={(event) => this.props.setHomeCollection(collection.reference, event, 0)}
                            avatar={
                                <Avatar
                                    className={classes.avatar}>
                                    {collection.fontIcon ?
                                        <Icon>{collection.fontIcon}</Icon> : <Icon>view_carousel</Icon>}
                                </Avatar>
                            }
                            title={collection.collectionName}
                            subheader={collection.description}
                            action={
                            <div>
                             <IconButton className={classes.badge}
                              aria-owns={open ? 'simple-menu' : null}
                              aria-haspopup="true"
                              onClick={(event)=>this.handleClick(event, collection.reference)}
                              >
                               {editcollectionbtn}
                             </IconButton>

                            <Icon
                                className={classes.iconbadge}
                                color="error"
                                style={this.props.homeCollection === collection.reference ? {visibility: 'visible'} : {visibility: 'hidden'}}
                            >home
                            </Icon>
                            </div>

                            }
                        />
                </Grid>
            )


            )}

             <Menu
              id="simple-menu"
              anchorEl={this.state.anchorEl}
              open={open}
              onClose={this.handleClose}
             >
              <MenuItem donotroute='1'
                onClick={() => this.props.history.push({
                            pathname: '/card-collection/' + this.state.curr_reference + "/edit",
                         })}

                >Edit Collection</MenuItem>
             </Menu>


            <Grid item xs
                  className={classes.gridItem}
                  key={-1}>
                <Link style={{textDecoration: 'none', visibility: 'visible'}}
                      to={"/card-collection/all"}>
                    <CardHeader
                        avatar={
                            <Avatar>
                                <Icon>view_comfy</Icon>
                            </Avatar>
                        }
                        title={"All"}
                        subheader={"all the existing cards"}
                    />
                </Link>
            </Grid>
        </Grid>
    )
  }
};

const mapStateToProps = state => {
    return {
        userRole: state.user.role,
    };
};

export default connect(mapStateToProps)(withStyles(styles)(CollectionGrid));