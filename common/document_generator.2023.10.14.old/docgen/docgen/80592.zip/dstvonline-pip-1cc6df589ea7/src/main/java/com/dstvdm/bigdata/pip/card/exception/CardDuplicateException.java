package com.dstvdm.bigdata.pip.card.exception;

import com.dstvdm.bigdata.pip.common.exception.PipApiBadRequestException;

public class CardDuplicateException extends PipApiBadRequestException {

    public CardDuplicateException(String message) {
        super(message);
    }
}
