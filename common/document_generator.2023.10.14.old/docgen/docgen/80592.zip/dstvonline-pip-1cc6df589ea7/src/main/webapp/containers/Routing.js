import React from 'react';
import {BrowserRouter, Redirect, Route, Switch} from "react-router-dom";
import NewCard from "./NewCard/NewCard";
import CollectionsList from "./Collections/CollectionsList";
import NewCollection from "./Collections/NewCollection";
import EnhancedCard from "./EnhancedCard/EnhancedCard";
import NavigationBar from "./NavigationBar/NavigationBar";
import axios from "axios/index";
import {connect} from "react-redux";
import Collection from "./Collections/Collection";
import {Snackbar} from "@material-ui/core";
import ManageSubscriptions from "./ManageSubscriptions/ManageSubscriptions";
import EditCollection from "./Collections/EditCollection";
import './Routing.css';

class Routing extends React.Component {

    state = {
        openSnackbar: false,
        homeCollection: localStorage.getItem('homeCollection') ? localStorage.getItem('homeCollection') : '',
    };

    componentDidMount() {
        axios.get('/api/user/current')
            .then(response => {
                this.props.onLoggedIn(response.data);
            })
            .catch(error => {
                console.log("error getting roles", error);
            });
    }


    render() {
        return (

         <div className="parallax">
           <div className="parallax-layer">
             <BrowserRouter>
                <Switch>
                    <Route exact path='/card-collection' render={(props) => (
                        <div>
                            <NavigationBar
                                {...props}
                            />
                            <CollectionsList
                                {...props}
                            />
                        </div>
                    )}/>
                    <Route exact path='/card-collection/new' render={(props) => (
                        <div>
                            <NavigationBar
                                {...props}
                            />
                            <NewCollection
                                {...props}
                            />
                        </div>
                    )}/>
                    <Route exact path='/card-collection/:id' render={(props) => (
                        <div>
                            <Collection
                                {...props}
                                key={props.location.search+props.match.params.id}
                            />
                        </div>
                    )}/>
                    <Route exact path='/card-collection/:id/edit' render={(props) => (
                        <div>
                            <NavigationBar
                                {...props}
                            />
                            <EditCollection
                                {...props}
                            />
                        </div>
                    )}/>
                    <Route exact path='/card/add' render={(props) => (
                        <div>
                            <NavigationBar
                                {...props}
                            />
                            <NewCard
                                {...props}
                            />
                        </div>
                    )}/>
                    <Route exact path='/card/:id/' render={(props) => (
                        <div>
                            <NavigationBar
                                {...props}
                            />
                            <EnhancedCard
                                {...props}
                            />
                        </div>
                    )}
                    />
                    <Route exact path='/manage-subscriptions' render={(props) => (
                        <div>
                            <NavigationBar
                                {...props}
                            />
                            <ManageSubscriptions
                                {...props}
                            />
                        </div>
                    )}
                    />
                    <Redirect from="/" to={"/card-collection/" + this.state.homeCollection}/>
                </Switch>
            </BrowserRouter>

                <Snackbar
                    anchorOrigin={{vertical: 'bottom', horizontal: 'right'}}
                    open={this.props.openSnackbar}
                    onClose={this.props.onCloseSnackbar}
                    autoHideDuration={6000}
                    ContentProps={{
                        'aria-describedby': 'message-id',
                    }}
                    message={<span id="message-id">{this.props.snackbarMessage}</span>}
                />
            </div>
         </div>
        )
    }

}

const mapDispatchToProps = dispatch => {
    return {
        onLoggedIn: (user) => dispatch({type: 'LOGGED_IN', value: user}),
        onCloseSnackbar: () => dispatch({type: 'CLOSE_SNACKBAR'})
    }
};

const mapStateToProps = state => {
    return {
        snackbarMessage: state.snackbar.message,
        openSnackbar: state.snackbar.openSnackbar,
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(Routing);


