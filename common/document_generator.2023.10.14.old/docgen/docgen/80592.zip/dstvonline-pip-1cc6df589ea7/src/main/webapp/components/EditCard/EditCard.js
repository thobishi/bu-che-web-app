import React from 'react';
import CardInputFields from "../Shared/CardInputFields/CardInputFields";
import {
    Button, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, IconButton, Menu, MenuItem
} from "@material-ui/core";
import MoreVertIcon from '@material-ui/icons/MoreVert';

const editCard = props => {

    return (
        <div>
            <Menu
                id="header-menu"
                anchorEl={props.editMenuAnchor}
                open={Boolean(props.editMenuAnchor)}
                onClose={props.closeEditMenu}
            >
                <MenuItem key={1} onClick={props.openConfirmDelete}>Delete Card</MenuItem>
            </Menu>
            <IconButton
                style={{float: 'right'}}
                aria-label="More"
                aria-owns={props.editMenuAnchor ? 'long-menu' : null}
                aria-haspopup="true"
                onClick={props.openEditMenu}
            >
                <MoreVertIcon />
            </IconButton>
            <CardInputFields
                card={props.card}
                setField={props.setField}
                types={props.cardTypes}
                setType={props.setType}
                setTags={props.setTags}
                titleNull={props.titleNull}
            />

            <Button style={{float: 'right'}} color='primary' variant='outlined'
                    onClick={props.openConfirmEdit}>Submit</Button>

            <Dialog
                disableEnforceFocus
                open={props.confirmEdit}
                onClose={props.closeConfirmEdit}
            >
                <DialogTitle>{"Update Card?"}</DialogTitle>
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        Are you sure you want to update this card?
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={props.closeConfirmEdit} color="primary">
                        Cancel
                    </Button>
                    <Button onClick={props.updateCard} color="primary">
                        OK
                    </Button>
                </DialogActions>
            </Dialog>

            <Dialog
                disableEnforceFocus
                open={props.confirmDelete}
                onClose={props.closeConfirmDelete}
            >
                <DialogTitle>{"Delete Card?"}</DialogTitle>
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        Are you sure you want to delete this card?
                        This will delete the card for everyone.
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={props.closeConfirmDelete} color="primary">
                        Cancel
                    </Button>
                    <Button onClick={props.deleteCard} color="primary">
                        OK
                    </Button>
                </DialogActions>
            </Dialog>
        </div>
    )
};

export default editCard;