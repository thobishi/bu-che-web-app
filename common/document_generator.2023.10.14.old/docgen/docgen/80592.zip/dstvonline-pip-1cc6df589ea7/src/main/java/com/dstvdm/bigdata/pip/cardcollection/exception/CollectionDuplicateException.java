package com.dstvdm.bigdata.pip.cardcollection.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST)
public class CollectionDuplicateException extends RuntimeException {

    public CollectionDuplicateException(String message) {
        super(message);
    }
}
