package com.dstvdm.bigdata.pip.carddata.entity;

import com.dstvdm.bigdata.pip.card.entity.Card;
import com.dstvdm.bigdata.pip.common.entity.AuditingEntity;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(indexes = {@Index(name = "idx_created", columnList = "card_id, created")})
@EqualsAndHashCode(callSuper = true, exclude = "card")
@ToString(exclude = "card")
public class CardData extends AuditingEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column(nullable = false)
    @Lob
    private String data;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(nullable = false, columnDefinition = "datetime(6)")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS", timezone = "GMT+2")
    private Date created;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "card_id", nullable = false)
    @JsonBackReference
    private Card card;

    @Enumerated(EnumType.STRING)
    @Column
    private CardDataStatus status;


    public CardData() {
    }

    public CardData(String data, Date created) {
        this.data = data;
        if (created == null) {
            this.created = new Date();
        } else {
            this.created = created;
        }
    }

    public CardData(String data, Date created, String status) {
        this(data, created);
        if (status == null) {
            this.status = null;
        } else {
            switch (status.toLowerCase()) {
                case "green":
                    this.status = CardDataStatus.GREEN;
                    break;
                case "red":
                    this.status = CardDataStatus.RED;
                    break;
                case "amber":
                    this.status = CardDataStatus.AMBER;
                    break;
                case "blue":
                    this.status = CardDataStatus.BLUE;
                    break;
                case "gray":
                    this.status = CardDataStatus.GRAY;
                    break;
                default:
                    this.status = null;
            }
        }
    }
}
