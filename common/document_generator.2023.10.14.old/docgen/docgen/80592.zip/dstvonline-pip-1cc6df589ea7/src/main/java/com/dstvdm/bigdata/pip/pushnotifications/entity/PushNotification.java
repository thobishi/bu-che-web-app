package com.dstvdm.bigdata.pip.pushnotifications.entity;

import com.dstvdm.bigdata.pip.card.entity.Card;
import com.dstvdm.bigdata.pip.common.entity.AuditingEntity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.*;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "push_notifications")
@Data
@ToString(exclude = "cards")
@EqualsAndHashCode(exclude = "cards", callSuper = true)
public class PushNotification extends AuditingEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column
    private String endpoint;
    @Column
    private String auth;
    @Column
    private String p256dh;

    @Column
    private Date lastPush;

    @ManyToMany(fetch = FetchType.LAZY, cascade = { CascadeType.ALL })
    @JoinTable(
            name = "join_Pushnotifications_Card",
            joinColumns = { @JoinColumn(name="push_notification_id")},
            inverseJoinColumns = { @JoinColumn(name = "card_id")}
    )
    private Set<Card> cards;

    protected PushNotification() {
        this.cards = new HashSet<>();
    }

    public PushNotification(String endpoint, String auth, String p256dh) {
        this.endpoint = endpoint;
        this.auth = auth;
        this.p256dh = p256dh;
        this.cards = new HashSet<>();
    }

    @JsonIgnore
    public void setCards(Set<Card> cards) {
        this.cards = cards;
    }
}
