const initialState = {
    counter: 0,
    user: {
        username: '',
        role: 'NONE',
    },
    snackbar: {
        openSnackbar: false,
        message: 'I love snacks'
    }
};

const reducer = (state = initialState, action) => {
    if (action.type === 'INCREMENT') {
        return {
            counter: state.counter + 1
        }
    }
    if (action.type === 'LOGGED_IN') {
        return {
            ...state,
            user: action.value
        }
    }
    if (action.type === 'SHOW_SNACKBAR') {
        return {
            ...state,
            snackbar: {
                openSnackbar: true,
                message: action.value
            }
        }
    }
    if (action.type === 'CLOSE_SNACKBAR') {
        return {
            ...state,
            snackbar: {
                openSnackbar: false,
                message: 'I love snacks'
            }
        }
    }
    return state;
};

export default reducer