package com.dstvdm.bigdata.pip.card.exception;

import com.dstvdm.bigdata.pip.common.exception.PipApiNotFoundException;

public class NoCardException extends PipApiNotFoundException {

    public NoCardException(String message) {
        super(message);
    }

}
