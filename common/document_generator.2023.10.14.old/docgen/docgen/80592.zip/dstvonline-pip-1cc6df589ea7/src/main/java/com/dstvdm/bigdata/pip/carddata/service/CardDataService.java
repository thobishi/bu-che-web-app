package com.dstvdm.bigdata.pip.carddata.service;

import com.dstvdm.bigdata.pip.card.entity.Card;
import com.dstvdm.bigdata.pip.carddata.entity.CardData;
import com.dstvdm.bigdata.pip.carddata.exception.NoCardDataException;
import com.dstvdm.bigdata.pip.carddata.resource.CardDataRepository;
import com.dstvdm.bigdata.pip.carddata.resource.TemplateCardDataRepository;
import com.dstvdm.bigdata.pip.common.DateUtility;
import com.dstvdm.bigdata.pip.pushnotifications.service.PushNotificationsService;
import lombok.AllArgsConstructor;
import lombok.extern.java.Log;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

@Service
@AllArgsConstructor
@Log
public class CardDataService {

    private PushNotificationsService pushNotificationsService;

    private CardDataRepository repository;
    private TemplateCardDataRepository templateCardDataRepository;
    private SimpMessagingTemplate template;
    private DateUtility dateUtility;

    public CardData getNewestCardData(Card card) {
        final CardData cardData = repository.findFirstByCardOrderByCreatedDesc(card);
        if (cardData == null) {
            throw new NoCardDataException("No card data exists for card: " + card.getTitle());
        }
        return cardData;
    }

    public List<CardData> getCardData(Card card) {
        List<CardData> cardDataList = repository.findTop20ByCardOrderByCreatedDesc(card);
        if (cardDataList.isEmpty()) {
            throw new NoCardDataException("No card data exists for card: " + card.getTitle());
        }
        return cardDataList;
    }

    public List<CardData> findLatestCardData(Set<Card> cardsInCollection) {
        if (cardsInCollection == null || cardsInCollection.isEmpty()) {
            return new ArrayList<>();
        } else {
            return templateCardDataRepository.getLatestCardDataForCards(cardsInCollection);
        }
    }

    public List<CardData> findLatestCardData(Set<Card> cardsInCollection, List<String> tags) {
        if (cardsInCollection == null || cardsInCollection.isEmpty()) {
            return new ArrayList<>();
        } else if (tags == null || tags.isEmpty()) {
            return templateCardDataRepository.getLatestCardDataForCards(cardsInCollection);
        } else {
            return templateCardDataRepository.getLatestCardDataForCards(cardsInCollection, tags);
        }
    }

    public List<CardData> findLatestCardDataByCardIds(List<Long> cardsIds) {
        return templateCardDataRepository.getLatestCardDataForCardsByIds(cardsIds);
    }

    public List<CardData> findLatestCardData(List<String> tags) {
        if (tags == null || tags.isEmpty()) {
            return templateCardDataRepository.getLatestCardDataForCards();
        } else {
            return templateCardDataRepository.getLatestCardDataForCards(tags);
        }
    }

    public void addNewCardDataAndNotify(Card card, CardData oldCardData) {
        sendToWebsocket(card);
        pushNotificationsService.checkAndPushNotification(card, oldCardData);
    }

    private void sendToWebsocket(Card card) {
        template.convertAndSend("/topic/card-data/" + card.getReference(), card.getLatestCardData());
    }


    public void removeOldCardData() {
        int removedRows = 1;
        int count = 0;
        while (removedRows > 0) {
            removedRows = templateCardDataRepository.removeOldCardData();
            count++;
            if(count%50==0) {
                log.info("Removed card-data: " + removedRows*10);
                if (LocalTime.now().getHour() > 1) {
                    break;
                }
            }
        }
    }
}