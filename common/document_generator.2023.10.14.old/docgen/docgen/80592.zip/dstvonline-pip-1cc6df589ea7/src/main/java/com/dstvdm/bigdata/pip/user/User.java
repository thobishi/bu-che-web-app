package com.dstvdm.bigdata.pip.user;


import lombok.Data;

@Data
public class User {

    private String username;

    private String role;


    public User(String name, String role) {
        this.username=name;
        this.role=role;
    }
}
