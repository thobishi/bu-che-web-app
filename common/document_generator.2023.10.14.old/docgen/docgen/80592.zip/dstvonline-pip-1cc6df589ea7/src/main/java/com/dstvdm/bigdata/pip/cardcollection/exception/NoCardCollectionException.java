package com.dstvdm.bigdata.pip.cardcollection.exception;

import com.dstvdm.bigdata.pip.common.exception.PipApiNotFoundException;

public class NoCardCollectionException extends PipApiNotFoundException {

    public NoCardCollectionException(String message) {
        super(message);
    }

}
