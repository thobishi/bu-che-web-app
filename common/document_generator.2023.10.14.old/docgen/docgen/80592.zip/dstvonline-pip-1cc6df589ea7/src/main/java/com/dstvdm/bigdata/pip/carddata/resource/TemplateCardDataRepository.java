package com.dstvdm.bigdata.pip.carddata.resource;

import com.dstvdm.bigdata.pip.card.entity.Card;
import com.dstvdm.bigdata.pip.carddata.entity.CardData;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Set;

public interface TemplateCardDataRepository {
    List<CardData> findByCardIds(String ids);

    List<CardData> findByCardIds(Collection<String> ids);

    List<CardData> findLatestByCardIds(Collection<String> ids);

    List<CardData> getLatestCardDataForCards();

    List<CardData> getLatestCardDataForCards(List<String> tags);

    List<CardData> getLatestCardDataForCards(Set<Card> cardsInCollection);

    List<CardData> getLatestCardDataForCards(Set<Card> cardsInCollection, List<String> tags);

    List<CardData> getLatestCardDataForCardsByIds(List<Long> cardIds);

    Integer removeOldCardData();
}