package com.dstvdm.bigdata.pip.common.exception;

public abstract class PipApiNotFoundException extends PipApiException {

    public PipApiNotFoundException() {
    }

    public PipApiNotFoundException(String message) {
        super(message);
    }

    public PipApiNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    public PipApiNotFoundException(Throwable cause) {
        super(cause);
    }

    public PipApiNotFoundException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
