import React from 'react';
import {BottomNavigation, BottomNavigationAction, Button, CircularProgress, Typography, Snackbar, withStyles} from "@material-ui/core";
import axios from "axios/index";
import Card from "../Card/Card";
import RestoreIcon from '@material-ui/icons/Restore';
import EditIcon from '@material-ui/icons/Edit';
import AspectRatioIcon from '@material-ui/icons/AspectRatio';
import FilterNoneIcon from '@material-ui/icons/FilterNone';
import NotificationsOffIcon from '@material-ui/icons/NotificationsOff';
import EditCard from "../../components/EditCard/EditCard";
import {connect} from "react-redux";
import ManageCollections from "./ManageCollections/ManageCollections";
import EnlargedCard from "./EnlargedCard/EnlargedCard";
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';

const styles = (theme) => ({
    title: {
        flex: 1
    },
    enhancedCardBody: {
        marginTop: '10px',
        marginBottom: '100px',
        marginLeft: '10px',
        marginRight: '10px',
    },
    cardList: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center'
    },
    stickToBottom: {
        width: '100%',
        position: 'fixed',
        bottom: 0,
    },
    fab: {
        position: 'fixed',
        bottom: theme.spacing.unit * 8,
        right: theme.spacing.unit * 2,
    },
    container: {
        display: 'flex',
        flexWrap: 'wrap',
    },
    textField: {
        marginLeft: theme.spacing.unit,
        marginRight: theme.spacing.unit,
        width: 200,
     },
});

class EnhancedCard extends React.Component {

    constructor(props)
    {
        super(props)

        let datetimenow = new Date()
        datetimenow = datetimenow.getFullYear()+'-'+('0' + (datetimenow.getMonth()+1)).slice(-2)
                                                                         +'-'+('0' + datetimenow.getDate()).slice(-2)+'T'
                                                                         +('0' + datetimenow.getHours()).slice(-2)+':'+('0' + datetimenow.getMinutes()).slice(-2)

        this.state = {
            cardData: [],
            cardTypes: [],
            card: null,
            bottomNav: 0,
            confirmEdit: false,
            confirmDelete: false,
            anchorEditMenu: null,
            titleNull: false,
            query: 'progress',
            subscribed: false,
            undoDeleteShow: false,
            snackbarMessage: 'Unsubscribed',
            currdate : datetimenow,
            currnumocc : 20
        }

            this.setState({currdate:datetimenow})
    }

    componentDidMount() {
        if (this.props.location.hash === "#edit") {
            this.setState({bottomNav: 1});
            this.getCardTypes();
        } else if (this.props.location.hash === "#collections") {
            this.setState({bottomNav: 2});
            this.getCardTypes();
        } else if (this.props.location.hash === "#enlarged") {
            this.setState({bottomNav: 3});
            this.getCardTypes();
        } else {
            this.getCardDataForDateNumOccur()
        }
        axios.get('/api/card/' + this.props.match.params.id)
            .then(response => {
                this.setState({card: response.data}, () => {
                    console.log("getting sub");
                    this.getSubscription()
                        .then((sub) => {
                            axios.get('/api/notifications/' + sub.toJSON().keys.p256dh + '/cards')
                                .then(response => {
                                    response.data.forEach(card => {
                                        if (card.reference === this.state.card.reference) {
                                            this.setState({
                                                subscribed: true
                                            })
                                        }
                                    });
                                })
                                .catch(error => {
                                    console.log("error getting cards for subscription", error);
                                });
                        })
                });
            })
            .catch(error => {
                console.log(error);
            });
    }

    getSubscription = () => {
        return navigator.serviceWorker.ready
            .then((swreg) => {
                return swreg.pushManager.getSubscription();
            })
            .then((sub) => {
                if (sub === null) {
                    // no subs, display message
                } else {
                    console.log('existing sub', sub);
                    return sub;
                }
            })
    };

    handleUnsubscribe = () => {
        this.getSubscription()
            .then((sub) => {
                axios.delete('/api/notifications/' + sub.toJSON().keys.p256dh + '/card/' + this.state.card.reference)
                    .then(response => {
                        this.setState({
                            subscribed: false,
                            snackbarMessage: 'Unsubscribed from ' + this.state.card.title,
                            undoDeleteShow: true,
                        });
                    })
                    .catch(error => {
                        console.log('Error: ', error);
                        this.props.onShowSnackbar("Failed to delete sub!")
                    });
            })
    };

    undoCardUnsubscribe = () => {
        this.getSubscription()
            .then((sub) => {
                    axios.post('/api/card/' + this.state.card.reference + '/subscribe',
                        sub,
                        {
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        })
                        .then(() => {
                            this.closeSnackbarHandler();
                            this.setState({
                                subscribed: true,
                            })
                        })
                        .catch(error => {
                            console.log('Error: ', error);
                        })
            })
    };

    closeSnackbarHandler = () => {
        this.setState({undoDeleteShow: false});
    };

    getCardTypes = () => {
        axios.get('/api/card-type')
            .then(response => {
                this.setState({cardTypes: response.data});
            })
            .catch(error => {
                console.log(error);
            });
    };

    onFieldChangeHandler = (event, field) => {
        let updatedCard = {
            ...this.state.card
        };
        updatedCard[field] = event.target.value;
        this.setState({card: updatedCard});
    };

    onTypeChangeHandler = event => {
        let updatedCard = {
            ...this.state.card
        };
        updatedCard.cardType.id = event.target.value;
        this.setState({card: updatedCard});
    };

    onTagsChangeHandler = tags => {
        let updatedCard = {
            ...this.state.card
        };
        updatedCard.tags = tags;
        this.setState({card: updatedCard});
    };

    updateCard = () => {
        if (this.state.card.title === '' || this.state.card.title === null) {
            this.setState({titleNull: true})
        } else {
            axios.put('/api/card',
                this.state.card,
                {
                    headers: {
                        'Content-Type': 'application/json',
                    }
                }
            )
                .then(() => {
                    this.props.onShowSnackbar("Card updated!");
                    this.props.history.goBack();
                })
                .catch(error => {
                    this.props.onShowSnackbar(error.response ? error.response.data.message : "Failed to update card!");
                });
            this.closeConfirmEditHandler();
        }
    };

    openConfirmEditHandler = () => {
        this.setState({confirmEdit: true})
    };

    closeConfirmEditHandler = () => {
        this.setState({confirmEdit: false})
    };

    deleteCard = () => {
        axios.delete('/api/card/' + this.state.card.reference)
            .then(() => {
                this.props.onShowSnackbar("Card deleted!");
                this.props.history.goBack();
            })
            .catch(error => {
                console.log(error.response);
                this.props.onShowSnackbar(error.response ? error.response.data : "Failed to delete card!");
            });
        this.closeConfirmDeleteHandler();
    };

    openConfirmDeleteHandler = () => {
        this.setState({confirmDelete: true})
    };

    closeConfirmDeleteHandler = () => {
        this.setState({confirmDelete: false})
    };

    setEditMenuAnchor = (event) => {
        this.setState({anchorEditMenu: event.currentTarget});
    };

    closeEditMenuHandler = () => {
        this.setState({anchorEditMenu: null});
    };

    bottomNavigationHandler = (event, value) => {
        let hashRoute = '';
        if (value === 1) {
            hashRoute = '#edit'
        } else if (value === 2) {
            hashRoute = '#collections'
        } else if (value === 3) {
            hashRoute = '#enlarged'
        } else {
            axios.get('/api/card/' + this.props.match.params.id + '/card-data')
                .then(response => {
                    this.setState({cardData: response.data});
                })
                .catch(error => {
                    console.log(error);
                });
        }
        this.props.history.replace({
            ...this.props.location,
            hash: hashRoute
        });
        this.setState({bottomNav: value});
    };

    timer = setTimeout(() => {
        this.setState({
            query: 'success',
        });
    }, 2e3);


     getCardDataForDateNumOccur()
      {
        axios.get('/api/card/findByReferencePriorTo/' + this.props.match.params.id + '/priorto/'+this.state.currdate+'/numoccur/'+this.state.currnumocc)
            .then(response => {
                this.setState({cardData: response.data});
            })
            .catch(error => {
                console.log(error);
            });
      }


    render() {
        const {classes} = this.props;

        let enhancedCardBody = '';
        let thedatepicker = null;


        if (this.state.bottomNav === 0) {

            thedatepicker =(<Grid container justify = "center">
                            <div>
                             <form noValidate>
                               <TextField
                                 id="datetime-local"
                                 label="Search prior to"
                                 type="datetime-local"
                                 value = {this.state.currdate}
                                 className={classes.textField}
                                 onChange={(event) => {this.setState({currdate:event.target.value}, () => { this.getCardDataForDateNumOccur()  })}}
                               />
                             </form>

                            <TextField
                              id="outlined-search"
                              label="Number of occurences"
                              type="search"
                              className={classes.textField}
                              margin="normal"
                              variant="outlined"
                              value = {this.state.currnumocc}
                              onChange={(event) => {this.setState({currnumocc:event.target.value}, () => { this.getCardDataForDateNumOccur() })}}
                            />
                            </div>
                           </Grid>)

            let cardList = [];
            let unsubscribe = null;
            if (this.state.subscribed) {
                unsubscribe = (<Button className={classes.fab} mini variant="fab" color="primary"
                                       onClick={this.handleUnsubscribe}>
                    <NotificationsOffIcon/>
                </Button>)
            }
            if (this.state.card !== null) {
                cardList =
                    this.state.cardData.map((cardData, key) => {
                        return (
                            <Card
                                card={this.state.card}
                                cardData={cardData}
                                detailedDateTime={true}
                                key={key}
                                removeTags={true}
                                removeMenu={true}
                            />
                        )
                    });
            }
            const noCardData = (
                <div>
                    {this.state.query === 'success' ? (
                        <Typography>No Card Data Found</Typography>
                    ) : (
                        <CircularProgress/>
                    )}
                </div>
            );
            enhancedCardBody = (
                <div>
                    {unsubscribe}
                <div className={classes.cardList}>
                    {cardList.length > 0 ? cardList : noCardData}
                </div>
                </div>
            )
        } else if (this.state.bottomNav === 1) {
            if (this.state.card !== null) {
                enhancedCardBody = (
                    <EditCard
                        card={this.state.card}
                        cardTypes={this.state.cardTypes}
                        setField={this.onFieldChangeHandler}
                        setType={this.onTypeChangeHandler}
                        setTags={this.onTagsChangeHandler}
                        openConfirmEdit={this.openConfirmEditHandler}
                        openConfirmDelete={this.openConfirmDeleteHandler}
                        confirmEdit={this.state.confirmEdit}
                        closeConfirmEdit={this.closeConfirmEditHandler}
                        updateCard={this.updateCard}
                        confirmDelete={this.state.confirmDelete}
                        closeConfirmDelete={this.closeConfirmDeleteHandler}
                        deleteCard={this.deleteCard}
                        editMenuAnchor={this.state.anchorEditMenu}
                        openEditMenu={this.setEditMenuAnchor}
                        closeEditMenu={this.closeEditMenuHandler}
                        titleNull={this.state.titleNull}
                    />
                );
            } else {
                enhancedCardBody = (
                    <CircularProgress/>
                )
            }
        } else if (this.state.bottomNav === 2) {
            enhancedCardBody = (
                <ManageCollections
                    userRole={this.props.userRole}
                    cardReference={this.props.match.params.id}
                />
            )

        } else if (this.state.bottomNav === 3) {
            if (this.state.card !== null) {
                enhancedCardBody = (
                    <EnlargedCard
                        card={this.state.card}
                    />

                )
            } else {
                enhancedCardBody = (
                    "loading..."
                )
            }
        }

        let editNav = null;
        if (this.props.userRole === "ADMIN") {
            editNav = (
                <BottomNavigationAction label="Edit" icon={<EditIcon/>} onClick={this.getCardTypes}/>
            )
        }

        return (
            <div>

                {thedatepicker}

                <div className={classes.enhancedCardBody}>
                    {enhancedCardBody}
                </div>

                <BottomNavigation
                    value={this.state.bottomNav}
                    onChange={this.bottomNavigationHandler}
                    showLabels
                    className={classes.stickToBottom}
                >
                    <BottomNavigationAction label="History" icon={<RestoreIcon/>}/>
                    {editNav}
                    <BottomNavigationAction label="Collections" icon={<FilterNoneIcon/>}/>
                    <BottomNavigationAction label="Enlarged" icon={<AspectRatioIcon/>}/>
                </BottomNavigation>
                <Snackbar
                    anchorOrigin={{
                        vertical: 'bottom',
                        horizontal: 'left',
                    }}
                    open={this.state.undoDeleteShow}
                    onClose={this.closeSnackbarHandler}
                    ContentProps={{
                        'aria-describedby': 'message-id',
                    }}
                    message={<span id="message-id">{this.state.snackbarMessage}</span>}
                    action={[
                        <Button key="undo" color="secondary" size="small" onClick={this.undoCardUnsubscribe}>
                            UNDO
                        </Button>,
                    ]}
                />
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        userRole: state.user.role,
    };
};

const mapDispatchToProps = dispatch => {
    return {
        onShowSnackbar: (snackbar) => dispatch({type: 'SHOW_SNACKBAR', value: snackbar})
    }
};


export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(EnhancedCard));