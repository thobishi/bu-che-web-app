package com.dstvdm.bigdata.pip.cardtype.controller;

import com.dstvdm.bigdata.pip.cardtype.entity.CardType;
import com.dstvdm.bigdata.pip.cardtype.service.CardTypeService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping(value="api/card-type")
public class CardTypeController {

    private CardTypeService cardTypeService;

    @RequestMapping
    public List<CardType> getCardTypes() {
        return cardTypeService.getCardTypes();
    }

}
