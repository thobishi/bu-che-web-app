import React from 'react';
import Card from "../../Card/Card";
import SockJS from "sockjs-client";
import Stomp from "stompjs";
import {Shake} from "reshake";
import {withStyles} from "@material-ui/core";


const styles = () => ({
    centerCard: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
    },
});

class EnlargedCard extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            scale: 1,
            stompClient: null,
            websocketConnected: false,
            shakeIterations: 0,
            cardData: null,
            cardAspectRatio: null,
        };
    }

    componentDidMount() {
        this.openSocket();
    }

    componentDidUpdate() {
        setTimeout(this.resizeCard, 30);
    }

    componentWillUnmount() {
        window.removeEventListener('resize', this.updateWindowDimensions);
        if (this.state.websocketConnected) {
            this.closeSocket();
        }
    }

    resizeCard = () => {
        const componentHeight = document.getElementById('largeCard').clientHeight;
        const componentWidth = 300;
        const windowHeight = window.innerHeight;
        const windowWidth = window.innerWidth;
        if (this.state.scale < ((windowWidth * 0.8)/componentWidth).toFixed(4) && this.state.scale < ((windowHeight*0.85)/componentHeight).toFixed(4)) {
            this.setState({scale: ((windowWidth * 0.8)/componentWidth).toFixed(4)})
        } else if (this.state.scale > ((windowHeight*0.85)/componentHeight).toFixed(4)){
            this.setState({scale: ((windowHeight*0.85)/componentHeight).toFixed(4)})
        }
    };

    openSocket = () => {
        console.log("Trying to connect to websocket...");
        if (!this.state.websocketConnected) {
            const socket = new SockJS('/gs-guide-websocket');
            const stompClient = Stomp.over(socket);
            this.disableWebSocketLogging(stompClient);
            this.setState({stompClient: stompClient}, () => {
                this.state.stompClient.connect({}, () => {
                    this.setState({websocketConnected: true});
                    console.log('Websocket open!!!');
                    this.subscribeToCard(this.state.stompClient);
                }, (error) => {
                    this.setState({websocketConnected: false});
                    console.log('[Failed to connect to websocket]', error);
                    setTimeout(() => {
                        this.openSocket()
                    }, 600000);
                })
            });
        }
    };

    closeSocket = () => {
        if (this.state.websocketConnected) {
            this.state.stompClient.disconnect();
            this.setState({websocketConnected: false});
        }
    };

    disableWebSocketLogging = (stompClient) => {
        stompClient.debug = null;
        this.setState({stompClient: stompClient});
    };

    subscribeToCard(stompClient) {
        stompClient.subscribe('/topic/card-data/' + this.props.card.reference, cardData => {
            this.cardUpdateAnimation();
            this.setState({cardData: JSON.parse(cardData.body)}
            );
        });
    };

    cardUpdateAnimation = () => {
        if (this.props.card.cardType.id !== 1 && this.props.card.cardType.id !== 4) {
            this.setState({shakeIterations: 1});
            setTimeout(() => {
                this.setState({shakeIterations: 0});
            }, 500);
        }
    };


    render() {
        const {classes} = this.props;
        let transform = 'scale(' + this.state.scale + ')';

        return (
            <div className={classes.centerCard}
                 style={{transformOrigin: 'top', transform: transform}}
                 id="largeCard"
            >
                <Shake
                    fixed={true}
                    h={2}
                    v={0.1}
                    r={0.1}
                    q={this.state.shakeIterations}
                >
                    <Card
                        card={this.props.card}
                        cardData={this.state.cardData ? this.state.cardData : this.props.card.latestCardData}
                        removeTags={true}
                        removeMenu={true}
                    />
                </Shake>
            </div>
        )
    }
}

export default withStyles(styles)(EnlargedCard);