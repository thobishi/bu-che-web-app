import React from 'react';
import {
    Avatar,
    CardHeader as MatCardHeader,
    Dialog,
    IconButton,
    Menu,
    MenuItem,
    Popover,
    SvgIcon,
    Typography,
    withStyles
} from "@material-ui/core";
import Moment from "react-moment";
import MoreVertIcon from "@material-ui/icons/MoreVert";
import NotificationsActiveIcon from "@material-ui/icons/NotificationsActive";
import {amber, blue, green, grey, red} from "@material-ui/core/colors";
import EnhancedCard from "../../EnhancedCard/EnhancedCard";
import {Link} from "react-router-dom";
import {connect} from "react-redux";

const styles = () => ({
    avatar: {
        backgroundColor: grey[500]
    },
    RED: {backgroundColor: red[500]},
    GREEN: {backgroundColor: green[500]},
    AMBER: {backgroundColor: amber[500]},
    BLUE: {backgroundColor: blue[500]},
    GRAY: {backgroundColor: grey[500]},
    inactive: {
        color: grey[500],
    }
});

class CardHeader extends React.Component {
    state = {
        anchorMenu: null,
        anchorDescription: null,
        showEnhancedCard: false
    };


    setMenuAnchor = (event) => {
        this.setState({anchorMenu: event.currentTarget});
    };

    closeHeaderMenuHandler = () => {
        this.setState({anchorMenu: null});
    };

    setDescriptionAnchor = (event) => {
        this.setState({anchorDescription: event.currentTarget});
    };

    pinCard = () => {
        if (this.props.priorityView === "pinned") {
            this.props.unPinCard(this.props.card.reference);
        } else {
            this.props.pinCard(this.props.card.reference);
        }
        this.closeHeaderMenuHandler();
    };

    hideCard = () => {
        if (this.props.priorityView === "hidden") {
            this.props.unHideCard(this.props.card.reference);
        } else {
            this.props.hideCard(this.props.card.reference);
        }
        this.closeHeaderMenuHandler();
    };

    subscribeToCard = () => {
        if (!this.props.subscribed) {
            this.props.addSubscription(this.props.card.reference, this.props.card.title);
        } else {
            this.props.removeSubscription(this.props.card.reference)
        }

        this.closeHeaderMenuHandler();
    };

    closeDescriptionHandler = () => {
        this.setState({anchorDescription: null});
        this.closeHeaderMenuHandler();
    };

    openEnhancedCard = () => {
        this.closeHeaderMenuHandler();
        this.setState({showEnhancedCard: true});
    };

    closeEnhancedCard = () => {
        this.setState({showEnhancedCard: false});
    };

    render() {
        const {classes} = this.props;
        classes.avatar = classes[this.props.statusColor];

        const pinnedMenuItem = (this.props.priorityView !== "hidden" ?
                <MenuItem key={3}
                          onClick={this.pinCard}>
                    {this.props.priorityView === "pinned" ? "Unpin" : "Pin to Top"}
                </MenuItem> : null
        );

        let editCardItem = null;
        if (this.props.userRole === "ADMIN") {
            editCardItem = (
                <Link style={{textDecoration: 'none'}} to={"/card/" + this.props.card.reference + "#edit"}>
                    <MenuItem>Edit Card</MenuItem>
                </Link>
            )
        }


        const
            menuItems = ([
                <MenuItem key={1} onClick={this.setDescriptionAnchor}>Description</MenuItem>,
                <Link key={2} style={{textDecoration: 'none'}} to={"/card/" + this.props.card.reference}>
                    <MenuItem>Card History</MenuItem>
                </Link>,
                <Link key={3} style={{textDecoration: 'none'}}
                      to={"/card/" + this.props.card.reference + "#collections"}>
                    <MenuItem>Manage Collections</MenuItem>
                </Link>,
                <div key={4}>
                    {editCardItem}
                </div>,
                <div key={5}>
                    {pinnedMenuItem}
                </div>,
                <MenuItem key={6}
                          onClick={this.hideCard}>{this.props.priorityView === "hidden" ? "Unhide/Show" : "Hide to Bottom"}</MenuItem>,
                <MenuItem key={7} onClick={this.subscribeToCard}>
                    {this.props.subscribed ? "Unsubscribe" : "Subscribe"}
                </MenuItem>,
                <Link key={8} style={{textDecoration: 'none'}}
                      to={"/card/" + this.props.card.reference + "#enlarged"}>
                    <MenuItem>Single Card View</MenuItem>
                </Link>,
            ]);

        let
            dateTime = (
                <Moment fromNow>{this.props.lastUpdate < new Date() ? this.props.lastUpdate : new Date()}</Moment>);

        if (

            this
                .props
                .detailedDateTime
        ) {
            dateTime = (
                <Moment
                    format="YYYY-MM-DD HH:mm:ss">{this.props.lastUpdate < new Date() ? this.props.lastUpdate : new Date()}</Moment>
            )
        }

        let pinned = null;
        let hidden = null;
        let subscribed = null;
        let action = null;

        if (!this.props.removeMenu) {
            if (this.props.priorityView === "pinned") {
                pinned = (
                    <IconButton onClick={this.pinCard}>
                        <SvgIcon color="primary">
                            <path fill="rgba(0, 0, 0, 0.52)"
                                  d="M16,12V4H17V2H7V4H8V12L6,14V16H11.2V22H12.8V16H18V14L16,12Z"/>
                        </SvgIcon>
                    </IconButton>
                )
            } else if (this.props.priorityView === "hidden") {
                hidden = (
                    <IconButton onClick={this.hideCard}>
                        <SvgIcon color="primary">
                            <path fill="rgba(0, 0, 0, 0.52)"
                                  d="M11.83,9L15,12.16C15,12.11 15,12.05 15,12A3,3 0 0,0 12,9C11.94,9 11.89,9 11.83,9M7.53,9.8L9.08,11.35C9.03,11.56 9,11.77 9,12A3,3 0 0,0 12,15C12.22,15 12.44,14.97 12.65,14.92L14.2,16.47C13.53,16.8 12.79,17 12,17A5,5 0 0,1 7,12C7,11.21 7.2,10.47 7.53,9.8M2,4.27L4.28,6.55L4.73,7C3.08,8.3 1.78,10 1,12C2.73,16.39 7,19.5 12,19.5C13.55,19.5 15.03,19.2 16.38,18.66L16.81,19.08L19.73,22L21,20.73L3.27,3M12,7A5,5 0 0,1 17,12C17,12.64 16.87,13.26 16.64,13.82L19.57,16.75C21.07,15.5 22.27,13.86 23,12C21.27,7.61 17,4.5 12,4.5C10.6,4.5 9.26,4.75 8,5.2L10.17,7.35C10.74,7.13 11.35,7 12,7Z"
                            />
                        </SvgIcon>
                    </IconButton>
                )
            }
            if (this.props.subscribed) {
                subscribed = (
                    <IconButton onClick={() => this.props.removeSubscription(this.props.card.reference)}>
                        <NotificationsActiveIcon/>
                    </IconButton>
                )
            }

            action = (
                <div>
                    {pinned}
                    {hidden}
                    {subscribed}
                    <IconButton
                        onClick={this.setMenuAnchor}
                        aria-owns={this.state.anchorMenu ? 'header-menu' : null}
                        aria-haspopup="true"
                    >
                        <MoreVertIcon/>
                    </IconButton>
                </div>
            )
        }

        return (
            <div>
                <MatCardHeader
                    classes={{title: this.props.headerFadeClass, subheader: this.props.headerFadeClass}}
                    avatar={
                        <Avatar aria-label="Status" className={classes.avatar}>
                            {this.props.children}
                        </Avatar>
                    }
                    action={action}
                    title={this.props.card.title}
                    subheader={dateTime}
                />
                <Menu
                    id="header-menu"
                    anchorEl={this.state.anchorMenu}
                    open={Boolean(this.state.anchorMenu)}
                    onClose={this.closeHeaderMenuHandler}
                >
                    {menuItems}
                </Menu>

                <Popover
                    disableEnforceFocus
                    open={Boolean(this.state.anchorDescription)}
                    anchorEl={this.state.anchorDescription}
                    onClose={this.closeDescriptionHandler}
                    anchorOrigin={{
                        vertical: 'center',
                        horizontal: 'left',
                    }}
                    transformOrigin={{
                        vertical: 'bottom',
                        horizontal: 'right',
                    }}
                >
                    <Typography
                        style={{margin: '20px'}}
                        variant='headline'
                    >
                        {this.props.card.description}
                    </Typography>
                </Popover>

                <Dialog
                    fullScreen
                    open={this.state.showEnhancedCard}
                    onClose={this.closeEnhancedCard}
                >
                    <EnhancedCard
                        close={this.closeEnhancedCard}
                        card={this.props.card}
                        reloadCard={this.props.reloadCards}
                    />
                </Dialog>
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        userRole: state.user.role,
    };
};

const mapDispatchToProps = dispatch => {
    return {
        onShowSnackbar: (snackbar) => dispatch({type: 'SHOW_SNACKBAR', value: snackbar})
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(CardHeader));