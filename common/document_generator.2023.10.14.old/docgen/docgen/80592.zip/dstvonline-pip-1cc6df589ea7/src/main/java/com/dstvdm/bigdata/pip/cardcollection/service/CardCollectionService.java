package com.dstvdm.bigdata.pip.cardcollection.service;

import com.dstvdm.bigdata.pip.card.entity.Card;
import com.dstvdm.bigdata.pip.cardcollection.entity.CardCollection;
import com.dstvdm.bigdata.pip.carddata.entity.CardData;

import javax.annotation.security.RolesAllowed;
import java.util.List;
import java.util.Set;

public interface CardCollectionService {

    @RolesAllowed("ROLE_ADMIN")
    String createNewCollection(CardCollection cardCollection);

    List<CardCollection> getAllCardCollections();

    CardCollection getCollectionByReference(String reference);

    @RolesAllowed("ROLE_ADMIN")
    void addCardToCollection(String reference, String cardReference);

    @RolesAllowed("ROLE_ADMIN")
    void updateCollection(CardCollection cardCollection);

    boolean removeCardFromCollection(String reference, String cardReference);

    Set<Card> getCardsInCollection(String reference);

    List<CardData> getCollectionCardData(String reference, List<String> tags);

    List<Card> getCollectionEmptyCard(String reference, List<String> tags);

    Set<CardCollection> getCollectionsForCard(String cardReference);

    List<Card> getCardsInCollection(String reference, List<String> tags);
}
