package com.dstvdm.bigdata.pip.common;

import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class DateUtility {
    public Date getCurrentDate() {
        return new Date();
    }
}
