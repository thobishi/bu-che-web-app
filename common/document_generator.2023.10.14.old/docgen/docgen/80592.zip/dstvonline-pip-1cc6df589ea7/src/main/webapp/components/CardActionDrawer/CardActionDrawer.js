import React from 'react';
import classNames from 'classnames';
import {
    Button,
    Chip,
    Divider,
    Drawer,
    IconButton,
    List,
    ListItem,
    ListItemIcon,
    ListItemText,
    Menu,
    MenuItem,
    Tooltip,
    withStyles
} from "@material-ui/core";
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import NotificationOffIcon from '@material-ui/icons/NotificationsOff';
import NotificationActiveIcon from '@material-ui/icons/NotificationsActive';
import FilterListIcon from '@material-ui/icons/FilterList';
import BookmarkIcon from '@material-ui/icons/Bookmark';
import * as randomMC from "random-material-color";

const drawerWidth = 240;
const ITEM_HEIGHT = 48;

const styles = theme => ({

    menuButton: {
        marginLeft: 12,
        marginRight: 36,
    },
    hide: {
        display: 'none',
    },
    drawerPaper: {
        height: '85%',
        top: '7%',
        borderRadius: '25px 0 0 25px',
        borderStyle: 'solid',
        borderWidth: '1px 0 1px 1px',
        borderColor: 'lightgrey',
        whiteSpace: 'nowrap',
        width: drawerWidth,
        transition: theme.transitions.create('width', {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen,
        }),
    },
    drawerPaperClose: {
        overflowX: 'hidden',
        transition: theme.transitions.create('width', {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
        }),
        width: theme.spacing.unit * 7,
    },
    content: {
        flexGrow: 1,
        backgroundColor: theme.palette.background.default,
        padding: theme.spacing.unit * 3,
    },
    chipMenu: {
        width: '100%',
        color: 'white'
    },
    label: {
        overflow: 'hidden',
        color: 'white'
    },
});

function cardActionDrawer(props) {
    const {classes} = props;
    let cardActionDrawer = (
        <Button style={{top: '7%', right: '5px', position: 'fixed', zIndex: '1100'}} mini
                variant="fab"
                onClick={props.handelOpen}
        >
            <ChevronLeftIcon/>
        </Button>
    );

    if (props.open) {
        cardActionDrawer = (
            <div>
                <Drawer
                    anchor="right"
                    variant="permanent"
                    position="fixed"
                    classes={{
                        paper: classNames(classes.drawerPaper, classes.drawerPaperClose),
                    }}
                >
                    <IconButton onClick={props.handelClose}>
                        <ChevronRightIcon/>
                    </IconButton>
                    <Divider/>
                    <Divider/>
                    <List>
                        <Tooltip title="Sort by Status">
                            <ListItem button onClick={props.toggleSortCards}>
                                <ListItemIcon style={{color: props.sortCards === 'status' ? 'red' : 'grey'}}>
                                    <FilterListIcon/>
                                </ListItemIcon>
                                <ListItemText primary="Sort Cards"/>
                            </ListItem>
                        </Tooltip>
                        <Tooltip title="Filter by Tags">
                            <ListItem button onClick={props.openTagsMenu}>
                                <ListItemIcon>
                                    <BookmarkIcon/>
                                </ListItemIcon>
                                <ListItemText primary="Filter by Tags"/>
                            </ListItem>
                        </Tooltip>
                        <Tooltip title="Sub to All Cards on Page">
                            <ListItem button onClick={props.subscribeToAllCards}>
                                <ListItemIcon>
                                    <NotificationActiveIcon/>
                                </ListItemIcon>
                                <ListItemText primary="Subscribe to cards on page"/>
                            </ListItem>
                        </Tooltip>
                        <Tooltip title="Unsub to All Cards on Page">
                            <ListItem button onClick={props.unsubscribeFromAllCards}>
                                <ListItemIcon>
                                    <NotificationOffIcon/>
                                </ListItemIcon>
                                <ListItemText primary="Unsubscribe to cards on page"/>
                            </ListItem>
                        </Tooltip>
                    </List>
                    <Divider/>
                </Drawer>
                <Menu
                    id="long-menu"
                    anchorEl={props.allTagsAnchor}
                    open={Boolean(props.allTagsAnchor)}
                    onClose={props.closeTagsMenu}
                    PaperProps={{
                        style: {
                            maxHeight: ITEM_HEIGHT * 9,
                            width: 200,
                        },
                    }}
                >
                    {props.allTags.map((tag, key) => (
                        <MenuItem
                            key={key}
                            onClick={() => props.addTagToFilter(tag)}>
                            <Chip
                                classes={{root: classes.chipMenu, label: classes.label}}
                                style={{backgroundColor: randomMC.getColor({text: tag})}}
                                label={tag.toLowerCase()}
                            />
                        </MenuItem>
                    ))}
                </Menu>
            </div>
        )
    }

    return (
        <div>
            {cardActionDrawer}
        </div>
    )
}

export default withStyles(styles)(cardActionDrawer);