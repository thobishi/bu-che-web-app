import React from "react";
import {Card as MatCard, CardContent} from "@material-ui/core";

function htmlCard(props) {
    let cardClass = 'MatCard';
    let htmlData = "No HTML Data Available";

    if (props.cardData !== null) {
        htmlData = props.cardData.data;
        cardClass = [cardClass, props.styles.cardActive].join(' ');
    } else {
        cardClass = [cardClass, props.styles.cardInactive].join(' ');
    }

    if (props.priorityView === "pinned") {
        cardClass = [cardClass, props.styles.cardPinned].join(' ');
    }

    return (
        <MatCard className={cardClass} style={{overflowY: 'auto'}}>
            {props.cardHeader}

                <CardContent style={{overflowX: 'auto'}}>
                    <p hidden>{props.card.reference}</p>
                    <div dangerouslySetInnerHTML={{__html: htmlData}}/>
                </CardContent>

            {props.cardActions}
        </MatCard>
    );
}


export default htmlCard;
