package com.dstvdm.bigdata.pip.card.resource;


import com.dstvdm.bigdata.pip.card.entity.Card;
import com.dstvdm.bigdata.pip.common.ViewableStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CardRepository extends JpaRepository<Card, Long>{

    List<Card> findAllByStatus(ViewableStatus status);

    Card findByReference(String reference);
}
