package com.dstvdm.bigdata.pip.carddata.controller;


import com.dstvdm.bigdata.pip.card.entity.Card;
import com.dstvdm.bigdata.pip.card.service.CardService;
import com.dstvdm.bigdata.pip.carddata.entity.CardData;
import com.dstvdm.bigdata.pip.carddata.exception.NoCardDataException;
import com.dstvdm.bigdata.pip.carddata.resource.TemplateCardDataRepository;
import com.dstvdm.bigdata.pip.carddata.service.CardDataService;
import lombok.AllArgsConstructor;
import lombok.extern.java.Log;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Date;

@RestController
@AllArgsConstructor
@Log
@RequestMapping(value = "api/card-data")
public class CardDataController {

    private CardDataService service;
    private CardService cardService;

    private TemplateCardDataRepository templateCardDataRepository;

    @GetMapping(value="/newest")
    public List<CardData> getTaggedCards(@RequestParam(required = false) List<String> tags) {
        return service.findLatestCardData(tags);
    }

    @GetMapping(value="/newestById")
    public List<CardData> getLatestCards(@RequestParam(required = false, defaultValue = "") List<Long> ids) {
        return service.findLatestCardDataByCardIds(ids);
    }

    @Deprecated
    @RequestMapping(method = RequestMethod.GET, value = "/findByReference/{ids}")
    @CrossOrigin
    public List<CardData> getNewestCardDataByReference( @PathVariable("ids") String ids ) {
        return templateCardDataRepository.findByCardIds(ids);
    }

    @Deprecated
    @RequestMapping(method = RequestMethod.GET, value = "/findByCardIds/{ids}")
    @CrossOrigin
    public List<CardData> getCardDataByIds( @PathVariable("ids") String ids ) {
        return templateCardDataRepository.findByCardIds(ids);
    }

    @Deprecated
    @RequestMapping(value = "/newest/{reference}")
    public CardData getNewestCardData( @PathVariable String reference) throws NoCardDataException {
        return cardService.getNewestCardData(reference);
    }

    @Deprecated
    @RequestMapping(value = "/find")
    public List<CardData> findLatest(
            @RequestParam(value = "tags", defaultValue = "") String tags,
            @RequestParam(value = "latest", defaultValue = "true") Boolean latest
    ) throws NoCardDataException {
        List<CardData> results = new ArrayList<>();
        if(StringUtils.hasText(tags)){
            List<Card> cards = cardService.getTaggedCardList(Arrays.asList(tags.split(",")))
                    .stream()
                    .sorted((card, t1) -> card.getId() < t1.getId() ? -1 : 1)
                    .collect(Collectors.toList());

            if(latest){
                results = templateCardDataRepository.findLatestByCardIds(cards.stream()
                        .map(card -> Long.toString(card.getId()))
                        .collect(Collectors.toSet()));
            }
            else{
                results = templateCardDataRepository.findByCardIds(cards.stream()
                        .map(card -> Long.toString(card.getId()))
                        .collect(Collectors.toSet()));
            }

            for(int i = 0; i < cards.size(); i++){
                results.get(i).setCard(cards.get(i));
            }
        }

        return results;
    }

    @Deprecated
    @RequestMapping(value = "/{reference}")
    public List<CardData> getCardData(@PathVariable String reference) {
        return cardService.getCardData(reference);
    }

    @Deprecated
    @RequestMapping(method = RequestMethod.POST, value = "/{reference}")
    @CrossOrigin
    public void addCardData(@RequestBody CardData cardData, @PathVariable String reference) {
        cardService.addCardData(cardData, reference);
    }


}