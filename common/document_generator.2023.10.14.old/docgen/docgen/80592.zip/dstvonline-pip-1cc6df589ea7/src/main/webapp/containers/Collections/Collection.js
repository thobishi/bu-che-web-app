import React, {Component} from 'react';
import NavigationBar from "../NavigationBar/NavigationBar";
import CardCollection from "./CardCollection";
import axios from "axios/index";
import * as qs from "qs";

class Collection extends Component {

    constructor(props) {
        super(props);
        let pipTags = null;

        // qs.stringify({ a: 'b', c: 'd' }, { addQueryPrefix: true })
        let sortCards = qs.parse(this.props.location.search, { ignoreQueryPrefix: true }).sort;
        if (sortCards) {
            localStorage.setItem('sortCards', sortCards);
        } else {
            sortCards = localStorage.getItem('sortCards') ? localStorage.getItem('sortCards') : "none";
            console.log('sortCards', sortCards);
            this.props.history.push({
                pathname: '/card-collection/' + this.props.match.params.id,
                search: '?sort=' + sortCards,
            });
        }

        const searchTags = qs.parse(this.props.location.search)['&tags'];
        if (searchTags) {
            pipTags = searchTags.split(',');
            localStorage.setItem('pipTags', JSON.stringify(pipTags));
        } else {
            pipTags = localStorage.getItem('pipTags') ? JSON.parse(localStorage.getItem('pipTags')) : [];
            if (pipTags.length) {
                this.props.history.push({
                    pathname: '/card-collection/' + this.props.match.params.id,
                    search: '?sort=' + sortCards + '&tags=' + pipTags,
                });
            }
        }

        this.state = {
            filterTags: pipTags,
            allTags: [],
            title: null,
            sortCards: sortCards,
        }
    }

    componentDidMount() {
        this.loadTags();
    }

    titleUpdateHandler = (title) => {
        this.setState({title: title})
    };

    loadTags = () => {
        axios.get('/api/card/tags')
            .then(response => {
                this.setState({allTags: response.data});
            })
            .catch(error => {
                console.log("error getting all card tags", error);
            });
    };

    addTagToFilter = (tag) => {
        const tagIndex = this.state.filterTags.indexOf(tag);
        if (tagIndex === -1) {
            const filterTags = this.state.filterTags;
            this.setState(
                {filterTags: [...filterTags, tag]},
                () => {
                    localStorage.setItem('pipTags', JSON.stringify(this.state.filterTags));
                    this.props.history.push({
                        pathname: '/card-collection/' + this.props.match.params.id,
                        search: '&tags=' + this.state.filterTags,
                    });
                });
        }
    };

    removeTagFromFilter = (tag) => {
        const tagIndex = this.state.filterTags.indexOf(tag);
        const newTagList = this.state.filterTags.slice(0);
        newTagList.splice(tagIndex, 1);
        this.setState({filterTags: newTagList},
            () => {
                localStorage.setItem('pipTags', JSON.stringify(this.state.filterTags));
                if (this.state.filterTags.length) {
                    this.props.history.push({
                        pathname: '/card-collection/' + this.props.match.params.id,
                        search: '&tags=' + this.state.filterTags,
                    });
                } else {
                    this.props.history.push({
                        pathname: '/card-collection/' + this.props.match.params.id,
                    });
                }
            });

    };

    sortCardsHandler = () => {
        console.log("sort handler");
        console.log(this.state.sortCards === "status");
        console.log(this.state.sortCards);
        if (this.state.sortCards === "status") {
            console.log("sort false");
            this.setState({sortCards: "none"}, () => {
                this.props.history.push({
                    pathname: '/card-collection/' + this.props.match.params.id,
                    search: '?sort=none',
                });
                localStorage.setItem('sortCards', "none");
            });
        } else {
            console.log("sort true");
            this.setState({sortCards: "status"}, () => {
                this.props.history.push({
                    pathname: '/card-collection/' + this.props.match.params.id,
                    search: '?sort=status',
                });
                localStorage.setItem('sortCards', "status");
            });
        }
    };

    render() {
        return (
            <div>
                <NavigationBar
                    {...this.props}
                    tags={this.state.filterTags}
                    removeTag={(tag) => this.removeTagFromFilter(tag)}
                    title={this.state.title}
                />

                <CardCollection
                    {...this.props}
                    addTagToFilter={this.addTagToFilter}
                    allTags={this.state.allTags}
                    updateTitle={(title) => this.titleUpdateHandler(title)}
                    sortCards={this.state.sortCards}
                    toggleSortCards={this.sortCardsHandler}
                />

            </div>
        )
    }
}

export default Collection;
