package com.dstvdm.bigdata.pip.scheduled;


import com.dstvdm.bigdata.pip.carddata.service.CardDataService;
import lombok.AllArgsConstructor;
import lombok.extern.java.Log;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Log
@AllArgsConstructor
@Component
@EnableScheduling
public class DatabaseMaintenance {

    CardDataService cardDataService;

    @Scheduled(cron="0 45 0 * * ?")
    public void clearOldCardData() {
        cardDataService.removeOldCardData();
    }

}
