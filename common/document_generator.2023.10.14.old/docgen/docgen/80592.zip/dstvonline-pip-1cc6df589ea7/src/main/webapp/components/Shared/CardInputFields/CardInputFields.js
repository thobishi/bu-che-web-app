import React from 'react';
import {TextField} from "@material-ui/core";
import Tags from '../../../containers/Tags/TagsInput';

const cardInputField = (props) => {

    const greyBoxStyle = {
        backgroundColor: 'lightgray',
        padding: '16px',
        border: '1px solid black',
        type: 'text'
    };


    var jsonexamplecontent = "";
    for (var i = 0; i < (props.types).length; i++) {
        // look for the entry with a matching `code` value
        if (props.types[i].id.toString() === props.card.cardType.id.toString()) {
            // we found it
            jsonexamplecontent = props.types[i].jsonexample;
            break;
        }
    }

    let cardThresholds = null
    if (props.card.cardType.id.toString() === "1") {
        cardThresholds = (
            <div>
                <h4> Notification Trigger </h4>
                <TextField
                    onChange={(event) => props.setField(event, 'lowerBound')}
                    value={props.card.lowerBound}
                    label='lowerBound'
                    margin='normal'
                    type='number'
                />
                <TextField
                    onChange={(event) => props.setField(event, 'upperBound')}
                    value={props.card.upperBound}
                    label='upperBound'
                    margin='normal'
                    type='number'
                />
            </div>
        )
    }


    return (
        <div>
            <TextField
                required
                error={props.titleNull}
                onChange={(event) => props.setField(event, 'title')}
                value={props.card.title}
                label='title'
                margin='normal'
            />
            <br/>
            <TextField
                multiline
                label='description'
                onChange={(event) => props.setField(event, 'description')}
                value={props.card.description}
                margin='normal'
            />
            <br/>
            <Tags
                value={props.card.tags}
                onChange={props.setTags}
            />
            <br/>
            <TextField
                select
                label='type'
                value={props.card.cardType.id}
                onChange={props.setType}
                margin='normal'
                SelectProps={{
                    native: true
                }}
            >
                {props.types.map(type => {
                    return <option value={type.id} key={type.id}>
                        {type.cardDisplayType}
                    </option>
                })}
            </TextField>
            {cardThresholds}
            <br/>
            <h4>Sample Json:</h4>
            <div style={greyBoxStyle} dangerouslySetInnerHTML={{__html: jsonexamplecontent}}/>
        </div>
    )
};

export default cardInputField;