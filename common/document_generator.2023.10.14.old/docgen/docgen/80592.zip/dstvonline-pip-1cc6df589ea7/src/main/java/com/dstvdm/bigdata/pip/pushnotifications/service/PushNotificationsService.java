package com.dstvdm.bigdata.pip.pushnotifications.service;

import com.dstvdm.bigdata.pip.card.entity.Card;
import com.dstvdm.bigdata.pip.carddata.entity.CardData;
import com.dstvdm.bigdata.pip.carddata.entity.CardDataStatus;
import com.dstvdm.bigdata.pip.pushnotifications.entity.PushNotification;
import com.dstvdm.bigdata.pip.pushnotifications.exceptions.NoSubscriptionException;
import com.dstvdm.bigdata.pip.pushnotifications.resource.PushNotificationRepository;
import lombok.AllArgsConstructor;
import lombok.extern.java.Log;
import nl.martijndwars.webpush.Notification;
import nl.martijndwars.webpush.PushService;
import nl.martijndwars.webpush.Subscription;
import org.apache.http.HttpResponse;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.jose4j.lang.JoseException;
import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Security;
import java.security.spec.InvalidKeySpecException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutionException;

@Service
@Log
@AllArgsConstructor
public class PushNotificationsService {

    private PushNotificationRepository repository;

    public void sendTestMessageToAllSubs() {
        List<PushNotification> allPushNotifications = repository.findAll();

        allPushNotifications.forEach((pushNotification -> {
            log.info(pushNotification.getAuth());
            Subscription subscription = new Subscription(pushNotification.getEndpoint(), (new Subscription().new Keys(pushNotification.getP256dh(), pushNotification.getAuth())));
            sendTestSub(subscription);
        }));
    }

    public HttpResponse sendTestSub(Subscription subscription) {
        Security.addProvider(new BouncyCastleProvider());

        PushService pushService;
        try {
            pushService = new PushService("BFg8Nkv_5K4CXT7_M8gmUR3nVjuHPgmhfTgES41abOP0v4gfxTrvlsQUVw8H1koIrmnRaFL3ORPES1vzRuVYwas",
                    "lTBHB0-yGKlk4hrLRS6dwnnf-TtRGUWUQpqpG9X9tmo", "samuel.vandeleur@dstvdm.com");
            Notification notification = null;
            try {
                notification = new Notification(subscription, "test push notification");
            } catch (NoSuchAlgorithmException | NoSuchProviderException | InvalidKeySpecException e) {
                e.printStackTrace();
            }
            return pushService.send(notification);
        } catch (GeneralSecurityException | IOException | JoseException | InterruptedException | ExecutionException e) {
            throw new RuntimeException(e);
        }
    }

    public PushNotification fetchPushNotification(String p256dh) {
        return repository.findByP256dh(p256dh);
    }

    public PushNotification fetchOrCreatePushNotification(Subscription subscription) {
        PushNotification pushNotification = fetchPushNotification(subscription.keys.p256dh);
        if (pushNotification == null) {
            pushNotification = new PushNotification(subscription.endpoint, subscription.keys.auth, subscription.keys.p256dh);
        }

        return pushNotification;
    }

    public void addCardToNotification(Card card, Subscription subscription) {
        PushNotification pushNotification = fetchOrCreatePushNotification(subscription);
        pushNotification.getCards().add(card);
        repository.save(pushNotification);

    }

    public void checkAndPushNotification(Card card, CardData oldCardData) {
        if (!(oldCardData.getStatus().equals(CardDataStatus.RED)) && card.getLatestCardData().getStatus().equals(CardDataStatus.RED)) {
            String message = card.getTitle() + " is RED";
            pushNotification(card, message);
        }
    }

    private void pushNotification(Card card, String message) {
        Security.addProvider(new BouncyCastleProvider());
        Set<PushNotification> pushNotifications = card.getPushNotifications();
        pushNotifications.forEach(pushNotification -> {
            Subscription subscription = new Subscription(pushNotification.getEndpoint(), (new Subscription().new Keys(pushNotification.getP256dh(), pushNotification.getAuth())));

            PushService pushService;
            try {
                pushService = new PushService("BFg8Nkv_5K4CXT7_M8gmUR3nVjuHPgmhfTgES41abOP0v4gfxTrvlsQUVw8H1koIrmnRaFL3ORPES1vzRuVYwas",
                        "lTBHB0-yGKlk4hrLRS6dwnnf-TtRGUWUQpqpG9X9tmo", "samuel.vandeleur@dstvdm.com");
                Notification notification = null;
                JSONObject payload = new JSONObject();
                payload.put("message", message);
                payload.put("reference", card.getReference());
                try {
                    notification = new Notification(subscription, payload.toJSONString());
                } catch (NoSuchAlgorithmException | NoSuchProviderException | InvalidKeySpecException e) {
                    e.printStackTrace();
                }
                pushService.sendAsync(notification);
            } catch (GeneralSecurityException | IOException | JoseException e) {
                throw new RuntimeException(e);
            }

        });
    }

    public Set<Card> getSubscribedCards(String p256dh) {
        PushNotification pushNotification = this.fetchPushNotification(p256dh);
        if (pushNotification != null) {
            return pushNotification.getCards();
        }
        throw new NoSubscriptionException("Could not find subscription for p256dh=" + p256dh);
    }

    public boolean removeCardFromSubscription(String p256dh, String cardReference) {
        PushNotification pushNotification = this.fetchPushNotification(p256dh);
        Set<Card> cards = pushNotification.getCards();
        boolean removedCard = cards.removeIf(card -> card.getReference().equals(cardReference));
        repository.save(pushNotification);
        return  removedCard;
    }

    public void removeAllCardsFromSubscription(String p256dh) {
        PushNotification pushNotification = this.fetchPushNotification(p256dh);
        pushNotification.setCards(new HashSet<>());
        repository.save(pushNotification);
    }
}
