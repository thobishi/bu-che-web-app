import React, {Component} from 'react';
import './NewCard.css';
import NewCardPopup from "../../components/NewCardPopup/NewCardPopup";
import SuccessNewCardPopup from "../../components/NewCardPopup/SuccessNewCardPopup/SuccessNewCardPopup";
import axios from "axios/index";

class NewCard extends Component {

    state = {
        showSuccessfullyCreatedCardPopup: false,
        postCardDataUrl: '',
        cardTypes: [],
        newCard: {
            title: '',
            description: '',
            cardType: {
                id: 1
            },
            lowerBound: null,
            upperBound: null,
            tags: []
        },
        titleNull: false,
        createdCardReference: ''
    };

    componentDidMount() {
        axios.get('/api/card-type')
            .then(response => {
                this.setState({cardTypes: response.data});
            })
            .catch(error => {
                console.log(error);
            });
    }

    onFieldChangeHandler = (event, field) => {
        let newCard = {
            ...this.state.newCard
        };
        newCard[field] = event.target.value;
        this.setState({newCard: newCard});
    };

    onTypeChangeHandler = event => {
        let newCard = {
            ...this.state.newCard
        };
        newCard.cardType.id = event.target.value;
        if (event.target.value !== 1) {
            newCard.lowerBound = null;
            newCard.upperBound = null;
        }
        this.setState({newCard: newCard});
    };

    onTagsChangeHandler = tags => {
        let newCard = {
            ...this.state.newCard
        };
        newCard.tags = tags;
        this.setState({newCard: newCard});
    };


    saveNewCard = () => {
        if(this.state.newCard.title === '' || this.state.newCard.title === null){
            this.setState({showSuccessfullyCreatedCardPopup: false});
        }else{
            axios.post('/api/card', this.state.newCard,
                {
                    headers: {
                        'Content-Type': 'application/json'
                    }
                }
            ).then(response => {
                console.log('Success: ', response);
                this.setState({
                    postCardDataUrl: window.location.origin + '/api/card/' + response.data + '/card-data',
                    createdCardReference: response.data
                }, () => {
                    this.setState({showSuccessfullyCreatedCardPopup: true});
                });
            })
            .catch(error => console.log('Error: ', error));
        }
    };

    goBackToPreviousPage = () => {
        this.props.history.push({
            pathname: '/card/' + this.state.createdCardReference,
            hash:"#collections"
        });
    };

    render() {

         let   createCardPopup = (
                <NewCardPopup
                    card={this.state.newCard}
                    types={this.state.cardTypes}
                    saveCard={this.saveNewCard}
                    setField={(event, field) => this.onFieldChangeHandler(event, field)}
                    setType={this.onTypeChangeHandler}
                    setTags={this.onTagsChangeHandler}
                    titleNull={this.state.titleNull}
                    cancelNewCard={this.goBackToPreviousPage}
                />
            );

        let successCreateCardPopup = null;

        if (this.state.showSuccessfullyCreatedCardPopup) {
            successCreateCardPopup = (
                <SuccessNewCardPopup
                    closePopup={this.goBackToPreviousPage}
                    card={this.state.newCard}
                    postCardDataUrl={this.state.postCardDataUrl}
                />
            );
        }

        return (
            <div>
                {createCardPopup}
                {successCreateCardPopup}
            </div>
        );
    }
}

export default NewCard;