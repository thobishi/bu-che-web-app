import React from 'react';
import axios from "axios/index";
import {Button, Chip, CircularProgress, Snackbar, Tooltip, Typography, withStyles} from "@material-ui/core";
import NotificationsOffIcon from '@material-ui/icons/NotificationsOff';
import * as randomMC from "random-material-color";
import {connect} from "react-redux";

const styles = theme => ({
    chip: {
        maxWidth: '200px',
        margin: theme.spacing.unit,
    },
    label: {
        overflow: 'hidden',
        color: 'white'
    },
});

class ManageSubscriptions extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            subscribedCards: [],
            lastDeletedCards: [],
            query: 'progress',
            undoDeleteShow: false,
            snackbarMessage: 'Unsubscribed'
        }
    }

    componentDidMount() {
        this.getSubscription()
            .then((sub) => {
                axios.get('/api/notifications/' + sub.toJSON().keys.p256dh + '/cards')
                    .then(response => {
                        let subscribedCards = [];
                        response.data.forEach(card => {
                            subscribedCards.push(card)
                        });
                        this.setState({subscribedCards: subscribedCards});
                    })
                    .catch(error => {
                        console.log("error getting cards for subscription", error);
                    });
            })
    }

    getSubscription = () => {
        return navigator.serviceWorker.ready
            .then((swreg) => {
                return swreg.pushManager.getSubscription();
            })
            .then((sub) => {
                if (sub === null) {
                    // no subs, display message
                } else {
                    console.log('existing sub', sub);
                    return sub;
                }
            })
    };

    unsubscribeAllCards = () => {
        this.getSubscription().then((sub) => {
            let subscribedCards = this.state.subscribedCards;
            axios.delete('/api/notifications/' + sub.toJSON().keys.p256dh + '/card')
                .then(response => {
                    this.setState({lastDeletedCards: subscribedCards}, () => {
                        subscribedCards = [];
                        this.setState({
                            subscribedCards: subscribedCards,
                            snackbarMessage: 'Unsubscribed from all cards',
                            undoDeleteShow: true,
                        });
                    });
                })
                .catch(error => {
                    console.log('Error: ', error);
                    this.props.onShowSnackbar("Failed to delete subs!")
                });
        })
    };

    handleDelete = (key) => {
        this.getSubscription()
            .then((sub) => {
                let subscribedCards = this.state.subscribedCards;
                axios.delete('/api/notifications/' + sub.toJSON().keys.p256dh + '/card/' + subscribedCards[key].reference)
                    .then(response => {
                        this.setState({lastDeletedCards: [subscribedCards[key]]}, () => {
                            subscribedCards.splice(key, 1);
                            this.setState({
                                subscribedCards: subscribedCards,
                                snackbarMessage: 'Unsubscribed from ' + this.state.lastDeletedCards[0].title,
                                undoDeleteShow: true,
                            });
                        });
                    })
                    .catch(error => {
                        console.log('Error: ', error);
                        this.props.onShowSnackbar("Failed to delete sub!")
                    });
            })
    };

    undoCardDelete = () => {
        this.getSubscription()
            .then((sub) => {
                this.state.lastDeletedCards.forEach((deletedCard) => {
                    axios.post('/api/card/' + deletedCard.reference + '/subscribe',
                        sub,
                        {
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        })
                        .then(() => {
                            this.closeSnackbarHandler();
                            let subscribedCards = this.state.subscribedCards;
                            subscribedCards.push(deletedCard);
                            this.setState({
                                subscribedCards: subscribedCards,
                            })
                        })
                        .catch(error => {
                            console.log('Error: ', error);
                        })
                });
                this.setState({
                    lastDeletedCards: [],
                })
            })
    };

    closeSnackbarHandler = () => {
        this.setState({undoDeleteShow: false});
    };

    timer = setTimeout(() => {
        this.setState({
            query: 'success',
        });
    }, 2e3);

    render() {
        const {classes} = this.props;
        const cardList =
            this.state.subscribedCards.map((card, key) => {
                return (
                    <Tooltip key={key} title={card.title} placement='top-end'>
                        <Chip
                            classes={{root: classes.chip, label: classes.label}}
                            style={{backgroundColor: randomMC.getColor({text: card.title})}}
                            label={card.title}
                            onDelete={() => this.handleDelete(key)}
                            deleteIcon={<NotificationsOffIcon/>}
                        />
                    </Tooltip>
                )
            });

        const noCardData = (
            <div>
                {this.state.query === 'success' ? (
                    <Typography>No Card Data Found</Typography>
                ) : (
                    <CircularProgress/>
                )}
            </div>
        );
        const subscriptionsBody = (
            <div>
                {cardList.length > 0 ? cardList : noCardData}
            </div>
        )

        return (
            <div>
                <Button size="small" style={{right: '5px', position: 'absolute'}} variant="outlined" color="primary"
                        onClick={this.unsubscribeAllCards}>
                    Unsubscribe All
                </Button>
                <h2>Manage Subscriptions</h2>
                {subscriptionsBody}

                <Snackbar
                    anchorOrigin={{
                        vertical: 'bottom',
                        horizontal: 'left',
                    }}
                    open={this.state.undoDeleteShow}
                    onClose={this.closeSnackbarHandler}
                    ContentProps={{
                        'aria-describedby': 'message-id',
                    }}
                    message={<span id="message-id">{this.state.snackbarMessage}</span>}
                    action={[
                        <Button key="undo" color="secondary" size="small" onClick={this.undoCardDelete}>
                            UNDO
                        </Button>,
                    ]}
                />
            </div>
        )
    }

}

const mapDispatchToProps = dispatch => {
    return {
        onShowSnackbar: (snackbar) => dispatch({type: 'SHOW_SNACKBAR', value: snackbar})
    }
};

export default connect(null, mapDispatchToProps)(withStyles(styles)(ManageSubscriptions));