import React, {Component} from 'react';
import Card from "../Card/Card";
import Masonry from 'react-masonry-component';

import PropTypes from 'prop-types';
import {
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
    Fade,
    withStyles
} from '@material-ui/core';
import red from '@material-ui/core/colors/red';
import SockJS from "sockjs-client";
import Stomp from "stompjs";
import * as qs from "qs";
import axios from "axios/index";
import {connect} from "react-redux";
import indexSearch from "../../util/search";
import CardActionDrawer from "../../components/CardActionDrawer/CardActionDrawer";


const styles = theme => ({
    card: {
        maxWidth: 400,
    },
    media: {
        height: 0,
        paddingTop: '56.25%', // 16:9
    },
    actions: {
        display: 'flex',
    },
    expand: {
        transform: 'rotate(0deg)',
        transition: theme.transitions.create('transform', {
            duration: theme.transitions.duration.shortest,
        }),
        marginLeft: 'auto',
    },
    expandOpen: {
        transform: 'rotate(180deg)',
    },
    avatar: {
        backgroundColor: red[500],
    },
    center: {
        left: '50%',
        position: 'absolute',
    },
});

class CardCollection extends Component {

    constructor(props) {
        super(props);
        this.masonryRef = React.createRef();
        this.state = {
            cards: [],
            cardPriorityMap: {
                "pinned": 0,
                "normal": 1,
                "hidden": 2,
            },
            cardStatusMap: {
                "RED": 0,
                "AMBER": 1,
                "GREEN": 2,
                "BLUE": 3,
                "GRAY": 4,
            },
            subscribedCards: [],
            pinnedCards: localStorage.getItem('pinnedCards') ? JSON.parse(localStorage.getItem('pinnedCards')) : [],
            hiddenCards: localStorage.getItem('hiddenCards') ? JSON.parse(localStorage.getItem('hiddenCards')) : [],
            cardElements: [],
            stompClient: null,
            websocketConnected: false,
            masonryRef: React.createRef(),
            loading: false,
            cardActionDrawerOpen: true,
            allTagsAnchor: null,
            openSubAllDialog: false,
            openUnsubAllDialog: false,
        };
    }

    componentDidMount() {
        if (this.props.match.params.id !== 'all') {
            this.loadCollection();
        }
        this.loadCards();
        this.loadSubscriptions();
        this.timerID = setTimeout(
            () => this.reloadMasonry(this.state.masonryRef),
            2000
        );
    }

    componentWillUnmount() {
        clearInterval(this.timerID);
        if (this.state.websocketConnected) {
            this.closeSocket();
        }
        clearInterval(this.reloadCardsTimer);
    }

    reloadMasonry(masonry) {
        masonry.current.performLayout();
    }

    loadCollection = () => {
        axios.get('/api/card-collection/' + this.props.match.params.id)
            .then(response => {
                this.setState({collection: response.data});
                this.props.updateTitle(response.data.collectionName)
            })
            .catch(error => {
                console.log("error loading collection " + this.state.reference, error);
            });
    };

    loadCards = () => {
        this.setState({loading: true});
        clearInterval(this.reloadCardsTimer);
        console.log('loading cards....');
        this.setState({cardElements: []});
        this.closeSocket();
        const searchTags = qs.parse(this.props.location.search, {ignoreQueryPrefix: true}).tags;
        axios.get('/api/card-collection/' + this.props.match.params.id + '/cards', {
            params: {
                tags: searchTags
            },
            paramsSerializer: params => {
                return (qs.stringify(params, {arrayFormat: 'repeat'}))
            }
        })
            .then(response => {
                this.setState({cards: []}, () => {
                    if (this.props.sortCards === "status") {
                        response.data.sort((a, b) => {
                            const aStatus = a.latestCardData ? a.latestCardData.status : "GRAY";
                            const bStatus = b.latestCardData ? b.latestCardData.status : "GRAY";
                            return this.state.cardStatusMap[aStatus] - this.state.cardStatusMap[bStatus];
                        });
                    }
                    this.setState({cards: response.data}, () => {
                        this.setState({loading: false});
                        this.openSocket();

                    });
                });
            })
            .catch(error => {
                this.setState({loading: false});
                console.log("error getting cards", error);
            });
        this.reloadCardsTimer = setTimeout(() => {
            this.loadCards();
        }, 2000000);
    };

    loadSubscriptions = () => {
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.ready
                .then((swreg) => {
                    return swreg.pushManager.getSubscription();
                })
                .then((sub) => {
                    if (!(sub === null)) {
                        this.setState({subscription: sub});
                        axios.get('/api/notifications/' + sub.toJSON().keys.p256dh + '/cards')
                            .then(response => {
                                let subscribedCards = [];
                                response.data.forEach(card => {
                                    subscribedCards.push(card)
                                });
                                this.setState({subscribedCards: subscribedCards});
                            })
                            .catch(error => {
                                console.log("error getting cards for subscription", error);
                            });
                    }
                })
        }
    };

    openSocket = () => {
        console.log("Trying to connect to websocket...");
        if (!this.state.websocketConnected) {
            const socket = new SockJS('/gs-guide-websocket');
            const stompClient = Stomp.over(socket);
            this.disableWebSocketLogging(stompClient);
            this.setState({stompClient: stompClient}, () => {
                this.state.stompClient.connect({}, () => {
                    this.setState({websocketConnected: true});
                    console.log('Websocket open!!!');
                    this.state.cardElements
                        .filter(cardEl => cardEl != null)
                        .forEach(cardEl => {
                            cardEl.subscribeToCard(this.state.stompClient);
                        });
                }, (error) => {
                    this.setState({websocketConnected: false});
                    console.log('[Failed to connect to websocket]', error);
                    setTimeout(() => {
                        this.openSocket()
                    }, 600000);
                })
            });
        }
    };

    closeSocket = () => {
        if (this.state.websocketConnected) {
            this.state.stompClient.disconnect();
            this.setState({websocketConnected: false});
        }
    };

    disableWebSocketLogging = (stompClient) => {
        stompClient.debug = null;
        this.setState({stompClient: stompClient});
    };

    setLatestCardDataHandler = (cardReference, latestCardData) => {
        if (this.props.sortCards === "status") {
            const cardIndex = this.state.cards.findIndex((card => card.reference === cardReference));
            if (cardIndex >= 0) {
                if (this.state.cards[cardIndex].latestCardData === null ||
                    this.state.cards[cardIndex].latestCardData.status !== latestCardData.status) {
                    let cards = this.state.cards.slice();
                    let card = cards[cardIndex];
                    card.latestCardData = latestCardData;
                    cards.splice(cardIndex, 1);
                    const newCardIndex = indexSearch(cards, latestCardData.status, this.state.cardStatusMap, "latestCardData.status");
                    if (newCardIndex === -1) {
                        cards.push(card);
                    } else {
                        cards.splice(newCardIndex, 0, card);
                    }
                    this.setState({cards: cards});
                }
            }
        }
    };

    pinCardHandler = (cardReference) => {
        const pinnedCards = this.state.pinnedCards;
        this.setState({pinnedCards: [...pinnedCards, cardReference]}, () => {
            localStorage.setItem('pinnedCards', JSON.stringify(this.state.pinnedCards));
        });
    };

    unPinCardHandler = (cardReference) => {
        const pinnedCards = this.state.pinnedCards;
        const index = pinnedCards.indexOf(cardReference);
        if (index > -1) {
            pinnedCards.splice(index, 1);
        }
        this.setState({pinnedCards: pinnedCards});
        localStorage.setItem('pinnedCards', JSON.stringify(pinnedCards));
    };

    hideCardHandler = (cardReference) => {
        const hiddenCards = this.state.hiddenCards;
        this.setState({hiddenCards: [...hiddenCards, cardReference]}, () => {
            localStorage.setItem('hiddenCards', JSON.stringify(this.state.hiddenCards));
        });
    };

    unHideCardHandler = (cardReference) => {
        const hiddenCards = this.state.hiddenCards;
        const index = hiddenCards.indexOf(cardReference);
        if (index > -1) {
            hiddenCards.splice(index, 1);
        }
        this.setState({hiddenCards: hiddenCards});
        localStorage.setItem('hiddenCards', JSON.stringify(hiddenCards));
    };

    subscribeToAllCards = () => {
        this.state.cards.forEach((card) => {
            let cardHasSub = false;
            let i = 0;
            while (!cardHasSub && (i < this.state.subscribedCards.length)) {
                if (this.state.subscribedCards[i].reference === card.reference) {
                    cardHasSub = true;
                }
                i++;
            }
            if (!cardHasSub) {
                this.configurePushSub(card.reference, card.title);
            }
        });
        this.handleCloseSubAllDialog();
    };

    unsubscribeFromAllCards = () => {
        this.state.cards.forEach((card) => {
            for (let i = 0; i < this.state.subscribedCards.length; i++) {
                if (this.state.subscribedCards[i].reference === card.reference) {
                    this.handleDeleteSub(card.reference);
                    break;
                }
            }
        });
        this.handleCloseUnsubAllDialog();
    };

    handleOpenSubAllDialog = () => {
        this.setState({openSubAllDialog: true});
    };

    handleCloseSubAllDialog = () => {
        this.setState({openSubAllDialog: false});
    };

    handleOpenUnsubAllDialog = () => {
        this.setState({openUnsubAllDialog: true});
    };

    handleCloseUnsubAllDialog = () => {
        this.setState({openUnsubAllDialog: false});
    };

    configurePushSub = (cardReference, cardTitle) => {
        Notification.requestPermission(result => {
            console.log('User choice', result);
            if (result !== 'granted') {
                this.props.onShowSnackbar("Notifications have been disabled. Please enable them to receive updates.");
            } else {
                if (!('serviceWorker' in navigator)) {
                    this.props.onShowSnackbar("Could not subscribe. This device may not be able to receive notifications");
                    return;
                }
                let reg;
                let newSub = false;
                navigator.serviceWorker.ready
                    .then((swreg) => {
                        reg = swreg;
                        return swreg.pushManager.getSubscription();
                    })
                    .then((sub) => {
                        if (sub === null) {
                            newSub = true;
                            console.log('creating new subscription');
                            // Create a new subscription
                            let vapidPublicKey = 'BFg8Nkv_5K4CXT7_M8gmUR3nVjuHPgmhfTgES41abOP0v4gfxTrvlsQUVw8H1koIrmnRaFL3ORPES1vzRuVYwas';
                            let convertedVapidPublicKey = this.urlBase64ToUint8Array(vapidPublicKey);
                            return reg.pushManager.subscribe({
                                userVisibleOnly: true,
                                applicationServerKey: convertedVapidPublicKey
                            });
                        } else {
                            console.log('existing sub');
                            return sub;
                        }
                    })
                    .then((sub) => {
                        console.log(sub);
                        return axios.post('/api/card/' + cardReference + '/subscribe',
                            sub,
                            {
                                headers: {
                                    'Content-Type': 'application/json'
                                }
                            }
                        )
                    })
                    .then(() => {
                        if (newSub) {
                            if ('serviceWorker' in navigator) {
                                const options = {
                                    body: "Cards you are subscribed to will notify like this when their status changes to red",
                                    icon: '/icon/favicon-192x192.png',
                                    badge: '/icon/badge-192x192.png',
                                    //many options (vibrate etc)
                                    //tag to stack or combine notifications
                                };
                                navigator.serviceWorker.ready
                                    .then(function (swreg) {
                                        swreg.showNotification("Successfully enabled notifications!", options)
                                    })
                            }
                        }
                        this.props.onShowSnackbar("Subscribed to " + cardTitle);

                        const newCardSubscription = {reference: cardReference};
                        let subscribedCards = this.state.subscribedCards;
                        subscribedCards.push(newCardSubscription);
                        this.setState({subscribedCards: subscribedCards});
                    })
                    .catch((err) => {
                        console.log(err);
                    });
            }
        });
    };

    handleDeleteSub = (cardReference) => {
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.ready
                .then((swreg) => {
                    return swreg.pushManager.getSubscription();
                })
                .then((sub) => {
                    if (sub === null) {
                        // no subs, display message
                    } else {
                        console.log('existing sub', sub);
                        return sub;
                    }
                })
                .then((sub) => {
                    axios.delete('/api/notifications/' + sub.toJSON().keys.p256dh + '/card/' + cardReference)
                        .then(response => {
                            console.log('deleted card sub');
                            let subscribedCards = this.state.subscribedCards.filter((card) => {
                                return card.reference !== cardReference
                            });
                            this.setState({subscribedCards: subscribedCards});
                        })
                        .catch(error => {
                            console.log('Error: ', error);
                            this.props.onShowSnackbar("Failed to delete sub!")
                        });
                })
        }
    };

    handleCardActionDrawerOpen = () => {
        console.log("open draw");
        this.setState({cardActionDrawerOpen: true});
    };

    handleCardActionDrawerClose = () => {
        console.log("close draw");
        this.setState({cardActionDrawerOpen: false});
    };

    openAllTagsHandler = event => {
        this.setState({allTagsAnchor: event.currentTarget});
    };

    closeTagsMenuHandler = () => {
        this.setState({allTagsAnchor: null});
    };

    urlBase64ToUint8Array = (base64String) => {
        let padding = '='.repeat((4 - base64String.length % 4) % 4);
        let base64 = (base64String + padding)
            .replace(/\-/g, '+')
            .replace(/_/g, '/');

        let rawData = window.atob(base64);
        let outputArray = new Uint8Array(rawData.length);

        for (let i = 0; i < rawData.length; ++i) {
            outputArray[i] = rawData.charCodeAt(i);
        }
        return outputArray;
    };

    render() {
        const {classes} = this.props;
        let noCardsMessage = null;
        let cardList = [];
        let pinnedCardList = [];
        let hiddenCardList = [];
        if (!this.state.loading) {
            this.state.cards.forEach((card) => {

                let subscribed = false;
                for (let i = 0; i < this.state.subscribedCards.length; i++) {
                    if (this.state.subscribedCards[i].reference === card.reference) {
                        subscribed = true;
                        break;
                    }
                }

                let priorityView = "normal";
                const hiddenIndex = this.state.hiddenCards.findIndex((hiddenCard => hiddenCard === card.reference));
                if (hiddenIndex === -1) {
                    const pinnedIndex = this.state.pinnedCards.findIndex((pinnedCard => pinnedCard === card.reference));
                    if (pinnedIndex === -1) {
                        cardList.push(
                            <Card className={classes.card}
                                  onRef={ref => this.state.cardElements.push(ref)}
                                  card={card}
                                  cardData={card.latestCardData ? card.latestCardData : null}
                                  setLatestCardData={this.setLatestCardDataHandler}
                                  key={card.reference}
                                  reloadCards={this.loadCards}
                                  addTagToFilter={this.props.addTagToFilter}
                                  priorityView={priorityView}
                                  pinCard={this.pinCardHandler}
                                  hideCard={this.hideCardHandler}
                                  unPinCard={this.unPinCardHandler}
                                  unHideCard={this.unHideCardHandler}
                                  masonryRef={this.state.masonryRef}
                                  reloadMasonry={this.reloadMasonry}
                                  subscribed={subscribed}
                                  addSubscription={this.configurePushSub}
                                  removeSubscription={this.handleDeleteSub}
                            />
                        )
                    } else {
                        priorityView = "pinned";
                        pinnedCardList.push(<Card className={classes.card}
                                                  onRef={ref => this.state.cardElements.push(ref)}
                                                  card={card}
                                                  cardData={card.latestCardData ? card.latestCardData : null}
                                                  setLatestCardData={this.setLatestCardDataHandler}
                                                  key={card.reference}
                                                  reloadCards={this.loadCards}
                                                  addTagToFilter={this.props.addTagToFilter}
                                                  priorityView={priorityView}
                                                  pinCard={this.pinCardHandler}
                                                  hideCard={this.hideCardHandler}
                                                  unPinCard={this.unPinCardHandler}
                                                  unHideCard={this.unHideCardHandler}
                                                  masonryRef={this.state.masonryRef}
                                                  reloadMasonry={this.reloadMasonry}
                                                  subscribed={subscribed}
                                                  addSubscription={this.configurePushSub}
                                                  removeSubscription={this.handleDeleteSub}
                        />)
                    }
                } else {
                    priorityView = "hidden";
                    hiddenCardList.push(<Card className={classes.card}
                                              onRef={ref => this.state.cardElements.push(ref)}
                                              card={card}
                                              cardData={card.latestCardData ? card.latestCardData : null}
                                              setLatestCardData={this.setLatestCardDataHandler}
                                              key={card.reference}
                                              reloadCards={this.loadCards}
                                              addTagToFilter={this.props.addTagToFilter}
                                              priorityView={priorityView}
                                              pinCard={this.pinCardHandler}
                                              hideCard={this.hideCardHandler}
                                              unPinCard={this.unPinCardHandler}
                                              unHideCard={this.unHideCardHandler}
                                              masonryRef={this.state.masonryRef}
                                              reloadMasonry={this.reloadMasonry}
                                              subscribed={subscribed}
                                              addSubscription={this.configurePushSub}
                                              removeSubscription={this.handleDeleteSub}
                    />)
                }
            });
            if (cardList.length === 0) {
                noCardsMessage = (
                    <p>No Cards</p>
                );

            } else {
                cardList = pinnedCardList.concat(cardList, hiddenCardList);
            }
        }

        return (
            <div>
                <CardActionDrawer
                    open={this.state.cardActionDrawerOpen}
                    handelOpen={this.handleCardActionDrawerOpen}
                    handelClose={this.handleCardActionDrawerClose}
                    sortCards={this.props.sortCards}
                    toggleSortCards={this.props.toggleSortCards}
                    addTagToFilter={this.props.addTagToFilter}
                    allTags={this.props.allTags}
                    openTagsMenu={this.openAllTagsHandler}
                    closeTagsMenu={this.closeTagsMenuHandler}
                    allTagsAnchor={this.state.allTagsAnchor}
                    subscribeToAllCards={this.handleOpenSubAllDialog}
                    unsubscribeFromAllCards={this.handleOpenUnsubAllDialog}
                />
                <Dialog
                    open={this.state.openSubAllDialog}
                    onClose={this.handleCloseSubAllDialog}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                >
                    <DialogTitle id="alert-dialog-title">{"Subscribe to all cards on page?"}</DialogTitle>
                    <DialogContent>
                        <DialogContentText id="alert-dialog-description">
                            This will subscribe you to all the cards on the page. You will receive a push notification
                            if
                            a threshold on the card is triggered.
                        </DialogContentText>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={this.handleCloseSubAllDialog} color="primary">
                            Cancel
                        </Button>
                        <Button onClick={this.subscribeToAllCards} color="primary" autoFocus>
                            Confirm
                        </Button>
                    </DialogActions>
                </Dialog>
                <Dialog
                    open={this.state.openUnsubAllDialog}
                    onClose={this.handleCloseUnsubAllDialog}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                >
                    <DialogTitle id="alert-dialog-title">{"Unsubscribe to all cards on page?"}</DialogTitle>
                    <DialogContent>
                        <DialogContentText id="alert-dialog-description">
                            This will unsubscribe you to all the cards on the page. You will no longer receive
                            notifications for the cards on this page.
                        </DialogContentText>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={this.handleCloseUnsubAllDialog} color="primary">
                            Cancel
                        </Button>
                        <Button onClick={this.unsubscribeFromAllCards} color="primary" autoFocus>
                            Confirm
                        </Button>
                    </DialogActions>
                </Dialog>

                {noCardsMessage}
                <Fade
                    in={this.state.loading}
                    style={{
                        transitionDelay: this.state.loading ? '800ms' : '0ms',
                    }}
                >
                    <p className={classes.center}>Loading...</p>
                </Fade>
                <Masonry updateOnEachImageLoad={true} ref={this.state.masonryRef}>
                    {cardList}
                </Masonry>
            </div>
        )
    }
}

CardCollection.propTypes = {
    classes: PropTypes.object.isRequired,
};

const mapDispatchToProps = dispatch => {
    return {
        onShowSnackbar: (snackbar) => dispatch({type: 'SHOW_SNACKBAR', value: snackbar})
    }
};

export default connect(null, mapDispatchToProps)(withStyles(styles)(CardCollection));