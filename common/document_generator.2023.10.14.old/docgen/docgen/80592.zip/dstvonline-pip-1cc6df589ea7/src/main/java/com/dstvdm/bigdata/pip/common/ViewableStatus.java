package com.dstvdm.bigdata.pip.common;

public enum ViewableStatus {

    ACTIVE,
    DELETED

}
