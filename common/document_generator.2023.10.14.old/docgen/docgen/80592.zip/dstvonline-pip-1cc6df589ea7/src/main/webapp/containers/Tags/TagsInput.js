import React, {Component} from 'react';
import TagsInput from 'react-tagsinput';

import 'react-tagsinput/react-tagsinput.css' // If using WebPack and style-loader.

class Tags extends Component {
    constructor(props) {
        super(props);
        this.onChange = props.onChange;
        this.state = {tags: props.value}
    }

    handleChange = tags => {
        let nTags = tags.map((tag) => tag.toLowerCase());
        this.setState({tags: nTags});
        this.onChange(nTags)
    }

    render() {
        return <TagsInput value={this.state.tags} onChange={(tags) => this.handleChange(tags)}/>
    }
}

export default Tags