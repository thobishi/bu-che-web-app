import React from 'react';
import {Dialog} from "@material-ui/core";
import CollectionGrid from "../../../components/CollectionGrid/CollectionGrid";
import axios from "axios/index";
import {connect} from "react-redux";


class CollectionListDialog extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            collections: [],
            homeCollection: localStorage.getItem('homeCollection') ? localStorage.getItem('homeCollection') : null,
        };

        axios.get('/api/card-collection')
            .then(response => {
                this.setState({collections: response.data})
            })
            .catch(error => {
                console.log("error getting cards", error);
            });

    }

    checkHomeCollection = (reference, event) => {
        if (event.target.attributes.getNamedItem('donotroute') === null)
        {
            if (this.state.homeCollection === null) {
                localStorage.setItem('homeCollection', reference);
            }

            this.props.history.push({
                pathname: '/card-collection/' + reference,
            });
        }
    };


    render(){

        return(
            <Dialog
                open={this.props.open}
                onClose={this.props.onClose}
            >
                <div style={{margin: '10px'}}>
                    <CollectionGrid
                        collections={this.state.collections}
                        homeCollection={this.state.homeCollection}
                        history={this.props.history}
                        setHomeCollection={(reference,event) => this.checkHomeCollection(reference,event)}
                    />
                </div>
            </Dialog>
        )
    }
}

const mapDispatchToProps = dispatch => {
    return {
        onShowSnackbar: (snackbar) => dispatch({type: 'SHOW_SNACKBAR', value: snackbar})
    }
};

export default connect(null, mapDispatchToProps)(CollectionListDialog);