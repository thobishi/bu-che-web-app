package com.dstvdm.bigdata.pip.cardcollection.resource;

import com.dstvdm.bigdata.pip.cardcollection.entity.CardCollection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CardCollectionRepository extends JpaRepository<CardCollection, Long>{

    CardCollection findByReference(String reference);

    @Query("select new com.dstvdm.bigdata.pip.cardcollection.entity.CardCollection(c.collectionName, c.reference, c.fontIcon, c.description) from CardCollection c where c.reference = ?1")
    CardCollection findCollectionExcludeCards(String reference);

    @Query("select new com.dstvdm.bigdata.pip.cardcollection.entity.CardCollection(c.collectionName, c.reference, c.fontIcon, c.description) from CardCollection c")
    List<CardCollection> findAllCollectionsExcludeCards();
}
