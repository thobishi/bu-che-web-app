package com.dstvdm.bigdata.pip.carddata.entity;

public enum CardDataStatus {
    RED, AMBER, GREEN, BLUE, GRAY
}
