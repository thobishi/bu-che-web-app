package com.dstvdm.bigdata.pip.pushnotifications.resource;

import com.dstvdm.bigdata.pip.pushnotifications.entity.PushNotification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PushNotificationRepository extends JpaRepository<PushNotification, Long> {

    PushNotification findByP256dh(String p256dh);

}
