import React from 'react';
import {Card as MatCard, CardContent, withStyles} from '@material-ui/core';
import PropTypes from 'prop-types';
import CardMedia from '@material-ui/core/CardMedia';
import NoImage from '../../../assets/no_image.svg';


const styles = () => ({
    media: {
        height: 0,
        paddingTop: '56.25%', // 16:9
        backgroundSize: 'contain'
    },
});

const imageCard = (props) => {
    const {classes} = props;
    let cardClass = 'MatCard';
    let htmlData = NoImage;

    if (props.cardData !== null) {
        try {
            htmlData = JSON.parse(props.cardData.data).src;
        } catch (e) {
            console.log(props.card.title + " data not in correct format", e);
        }
        cardClass = [cardClass, props.styles.cardActive].join(' ');
    } else {
        cardClass = [cardClass, props.styles.cardInactive].join(' ');
    }

    if (props.priorityView === "pinned") {
        cardClass = [cardClass, props.styles.cardPinned].join(' ');
    }

    return (
            <MatCard
                className={cardClass}>
                {props.cardHeader}
                <CardMedia
                    onClick={() => props.expandImage(htmlData)}
                    alt="no data"
                    className={classes.media}
                    image={htmlData}
                    title={props.card.description}
                />
                <CardContent>
                    <p hidden>{props.card.reference}</p>
                </CardContent>

                {props.cardActions}
            </MatCard>
    )
};

imageCard.propTypes = {
    classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(imageCard);
