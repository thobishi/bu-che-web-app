package com.dstvdm.bigdata.pip.cardcollection.controller;

import com.dstvdm.bigdata.pip.card.entity.Card;
import com.dstvdm.bigdata.pip.cardcollection.entity.CardCollection;
import com.dstvdm.bigdata.pip.cardcollection.service.CardCollectionService;
import com.dstvdm.bigdata.pip.carddata.entity.CardData;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.java.Log;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Set;

@RestController
@AllArgsConstructor
@Log
@RequestMapping(value="api/card-collection")
public class CardCollectionController {

    CardCollectionService service;

    @GetMapping
    public List<CardCollection> getAllCardCollections(){
        return service.getAllCardCollections();
    }

    @PostMapping
    public void createNewCollection(@Valid @RequestBody CardCollection cardCollection){
        service.createNewCollection(cardCollection);
    }

    @PutMapping
    public void updateCollection(@Valid @RequestBody CardCollection cardCollection) {
        service.updateCollection(cardCollection);
    }

    @GetMapping(value = "/{reference}")
    public CardCollection getCollection(@PathVariable String reference){
        return service.getCollectionByReference(reference);
    }

    @GetMapping(value = "/{reference}/card-data")
    public List<CardData> getCollectionCardData(@PathVariable String reference, @RequestParam(required = false) List<String> tags){
        return service.getCollectionCardData(reference, tags);
    }

    @GetMapping(value = "/{reference}/empty-cards")
    public List<Card> getCollectionEmptyCard(@PathVariable String reference, @RequestParam(required = false) List<String> tags){
        return service.getCollectionEmptyCard(reference, tags);
    }

    @PostMapping(value = "/{reference}/card")
    public void addCardToCollection(@PathVariable String reference, @RequestBody String cardReference){
        service.addCardToCollection(reference, cardReference);
    }

    @DeleteMapping(value="/{reference}/card/{cardReference}")
    public boolean removeCardFromCollection(@PathVariable String reference, @PathVariable String cardReference){
        return service.removeCardFromCollection(reference, cardReference);
    }

    @GetMapping(value = "/{reference}/cards")
    public List<Card> getCardsInCollection(@PathVariable String reference,  @RequestParam(required = false) List<String> tags){
        return service.getCardsInCollection(reference, tags);
    }

    @GetMapping(value = "/card/{cardReference}")
    public Set<CardCollection> getCollectionsForCard(@PathVariable String cardReference){
        return service.getCollectionsForCard(cardReference);
    }
}
