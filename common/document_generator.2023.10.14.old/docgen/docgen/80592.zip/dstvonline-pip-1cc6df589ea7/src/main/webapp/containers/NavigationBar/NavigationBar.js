import React from 'react';
import {
    AppBar,
    Button,
    Chip,
    Divider,
    Drawer,
    IconButton,
    List,
    ListItem,
    ListItemIcon,
    ListItemText,
    Paper,
    Toolbar,
    Typography,
    withStyles
} from "@material-ui/core";
import MenuIcon from '@material-ui/icons/Menu';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import AddBoxIcon from '@material-ui/icons/AddBox';
import ExpandLessIcon from '@material-ui/icons/ExpandLess';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import LibraryAddIcon from '@material-ui/icons/LibraryAdd';
import HomeIcon from '@material-ui/icons/Home';
import ViewComfyIcon from '@material-ui/icons/ViewComfy';
import ViewCarouselIcon from '@material-ui/icons/ViewCarousel';
import NotificationsActiveIcon from '@material-ui/icons/NotificationsActive';
import * as randomMC from "random-material-color";
import {Link} from "react-router-dom";
import {connect} from "react-redux";
import CollectionListDialog from "../Collections/CollectionListDialog/CollectionListDialog";

const styles = () => ({
    filterTags: {
        margin: '10px',
        padding: '3px',
        border: '1px solid #ccc!important',
        borderRadius: '15px',
    },
    chip: {
        maxWidth: '150px',
        height: '25px'
    },
    label: {
        overflow: 'hidden',
        color: 'white'
    },
});

class NavigationBar extends React.Component {

    state = {
        drawerOpen: false,
        collectionDialogOpen: false,
        expandedAppBar: localStorage.getItem('expandedAppBar') ? localStorage.getItem('expandedAppBar') : "true",
    };

    openCollectionDialogHandler = () => {
        this.setState({collectionDialogOpen: true});
    };

    closeCollectionDialogHandler = () => {
        this.setState({collectionDialogOpen: false});
    };

    drawerOpenHandler = () => {
        this.setState({drawerOpen: true});
    };

    drawerCloseHandler = () => {
        this.setState({drawerOpen: false});
    };

    expandAppBarLess = () => {
        this.setState({expandedAppBar: "false"});
        localStorage.setItem('expandedAppBar', "false");
    };

    expandAppBarMore = () => {
        this.setState({expandedAppBar: "true"});
        localStorage.setItem('expandedAppBar', "true");
    };

    logoutHandler = () => {
        fetch("/perform_logout", {
            method: "GET",
        })
            .then(v => {
                if(v.redirected) window.location = v.url
            })
            .catch(e => console.warn(e))
    };

    render() {
        const {classes} = this.props;

        let drawer = null;

        let adminLink = null;
        if (this.props.userRole === 'ADMIN') {
            adminLink = (
                <div>
                    <Link to="/card/add" style={{textDecoration: 'none'}}>
                        <ListItem button onClick={this.drawerCloseHandler}>
                            <ListItemIcon>
                                <AddBoxIcon/>
                            </ListItemIcon>
                            <ListItemText primary="Create Card"/>
                        </ListItem>
                    </Link>
                    <Link to="/card-collection/new" style={{textDecoration: 'none'}}>
                        <ListItem button onClick={this.drawerCloseHandler}>
                            <ListItemIcon>
                                <LibraryAddIcon/>
                            </ListItemIcon>
                            <ListItemText primary="Create Collection"/>
                        </ListItem>
                    </Link>
                </div>
            )
        }

        if (this.state.drawerOpen) {
            const homeLink = localStorage.getItem('homeCollection') ? localStorage.getItem('homeCollection') : '';
            drawer = (
                <Drawer
                    variant="persistent"
                    open={this.state.drawerOpen}
                >
                    <div>
                        <IconButton onClick={this.drawerCloseHandler}>
                            <ChevronLeftIcon/>
                        </IconButton>
                    </div>
                    <Divider/>
                    <List>
                        <Link to={"/card-collection/" + homeLink}
                              style={{textDecoration: 'none'}}>
                            <ListItem button onClick={this.drawerCloseHandler}>
                                <ListItemIcon>
                                    <HomeIcon/>
                                </ListItemIcon>
                                <ListItemText primary="Home"/>
                            </ListItem>
                        </Link>
                        <Link to="/card-collection" style={{textDecoration: 'none'}}>
                            <ListItem button onClick={this.drawerCloseHandler}>
                                <ListItemIcon>
                                    <ViewCarouselIcon/>
                                </ListItemIcon>
                                <ListItemText primary="Collections"/>
                            </ListItem>
                        </Link>
                        <Link to="/card-collection/all" style={{textDecoration: 'none'}}>
                            <ListItem button onClick={this.drawerCloseHandler}>
                                <ListItemIcon>
                                    <ViewComfyIcon/>
                                </ListItemIcon>
                                <ListItemText primary="All Cards"/>
                            </ListItem>
                        </Link>
                    </List>
                    <Divider/>
                    <List>
                        <Link to="/manage-subscriptions" style={{textDecoration: 'none'}}>
                            <ListItem button onClick={this.drawerCloseHandler}>
                                <ListItemIcon>
                                    <NotificationsActiveIcon/>
                                </ListItemIcon>
                                <ListItemText primary="Manage Subscriptions"/>
                            </ListItem>
                        </Link>
                        {adminLink}
                    </List>
                    <Divider/>
                    <List>
                        <ListItem button>
                            <ListItemText primary="Settings"/>
                        </ListItem>
                        <ListItem button onClick={this.logoutHandler}>
                            <ListItemText primary="Logout"/>
                        </ListItem>
                    </List>
                </Drawer>
            );
        }

        let expandAppBar = null;
        if (this.state.expandedAppBar === "true") {
            expandAppBar =
                (
                    <IconButton
                        style={{color: 'white'}}
                        aria-label="expand"
                        aria-haspopup="false"
                        onClick={this.expandAppBarLess}
                    >
                        <ExpandLessIcon/>
                    </IconButton>
                );
        } else {
            expandAppBar =
                (
                    <Button style={{right: '5px', position: 'absolute', zIndex: '1300'}} mini color="primary"
                            variant="fab"
                            onClick={this.expandAppBarMore}>
                        <ExpandMoreIcon/>
                    </Button>
                )
        }

        let collectionListDialog = null;
        if (this.state.collectionDialogOpen) {
            collectionListDialog = (<CollectionListDialog
                    {...this.props}
                    open={this.state.collectionDialogOpen}
                    onClose={this.closeCollectionDialogHandler}
                />
            )
        }
        const collectionList = (
            <div>
                <IconButton
                    style={{color: 'white'}}
                    aria-label="collectionList"
                    aria-haspopup="true"
                    onClick={this.openCollectionDialogHandler}
                >
                    <ViewCarouselIcon/>
                </IconButton>

                {collectionListDialog}
            </div>
        );


        let tags = null;
        if (this.props.tags && this.props.tags.length) {
            tags = (
                <Paper className={classes.filterTags} elevation={0}>
                    {
                        this.props.tags.sort().map((tag, key) => {
                            return <Chip
                                classes={{root: classes.chip, label: classes.label}}
                                style={{backgroundColor: randomMC.getColor({text: tag})}}
                                key={key}
                                label={tag}
                                onDelete={() => this.props.removeTag(tag)}
                            />
                        })
                    }
                </Paper>
            );
        }

        let appBar = null;
        if (this.state.expandedAppBar === "true") {
            appBar =
                (
                    <div>
                        <AppBar position="static">
                            <Toolbar>
                                <IconButton color="inherit" onClick={this.drawerOpenHandler}>
                                    <MenuIcon/>
                                </IconButton>
                                <Typography
                                    style={{flex: 1}}
                                    variant="title" color="inherit">
                                    <Link to='/' style={{textDecoration: 'none', color: 'white'}}>
                                        {this.props.title ? this.props.title : "Pip"}
                                    </Link>
                                </Typography>
                                {collectionList}

                                {expandAppBar}
                            </Toolbar>
                        </AppBar>
                        {drawer}
                        {tags}
                    </div>
                )
        } else {
            appBar = (
                expandAppBar
            );
        }

        return (
            appBar
        )
    }
}

const mapStateToProps = state => {
    return {
        userRole: state.user.role,
    };
};

export default connect(mapStateToProps)(withStyles(styles)(NavigationBar));