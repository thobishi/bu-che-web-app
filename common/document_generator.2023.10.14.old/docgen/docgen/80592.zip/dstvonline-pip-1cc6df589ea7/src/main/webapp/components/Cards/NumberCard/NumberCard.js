import React from "react";
import {Card as MatCard, CardContent} from "@material-ui/core";
import AnimatedNumber from 'react-animated-number';

function NumberCard(props) {
    let cardClass = 'MatCard';

    let htmlData = {number: 0};

    if (props.cardData !== null) {
        try {
            htmlData = JSON.parse(props.cardData.data);
        } catch (e) {
            console.log(props.card.title + " data not in correct format", props.cardData.data, e);
        }
        cardClass = [cardClass, props.styles.cardActive].join(' ');
    } else {
        cardClass = [cardClass, props.styles.cardInactive].join(' ');
    }

    if (props.priorityView === "pinned") {
        cardClass = [cardClass, props.styles.cardPinned].join(' ');
    }

    let lowerBoundText = "";
    let upperBoundText = "";
    if (props.card.lowerBound !== undefined && props.card.lowerBound !== null) {
        lowerBoundText = "lower: " + props.card.lowerBound + "; ";
    }
    if (props.card.upperBound !== undefined && props.card.upperBound !== null) {
        upperBoundText = "upper: " + props.card.upperBound;
    }

    let boundTextColor = "grey";
    if (props.card.upperBound < htmlData.number || props.card.lowerBound > htmlData.number) {
        boundTextColor = "red";
    }

    return (
        <MatCard className={cardClass}>
            {props.cardHeader}

                <CardContent style={{textAlign: 'center', paddingTop: '0', paddingBottom: '0'}}>
                    <p hidden>{props.card.reference}</p>
                    <AnimatedNumber value={htmlData.number}
                                    style={{
                                        transition: '0.8s ease-out',
                                        fontSize: 48,
                                        transitionProperty:
                                            'background-color, color, opacity'
                                    }}
                                    frameStyle={perc => (
                                        perc === 100 ? {} : {backgroundColor: '#ffeb3b'}
                                    )}
                                    duration={300}
                                    formatValue={n => (htmlData.prefix===undefined?"":htmlData.prefix)
                                        + n.toLocaleString()
                                        + (htmlData.suffix===undefined?"":htmlData.suffix)
                                    }
                    />
                    <p style={{textAlign: "right", margin: '0', color: boundTextColor}}>{lowerBoundText}{upperBoundText}</p>
                </CardContent>

            {props.cardActions}
        </MatCard>
    );
}


export default NumberCard;
