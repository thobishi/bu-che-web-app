package com.dstvdm.bigdata.pip.cardtype.exception;

import com.dstvdm.bigdata.pip.common.exception.PipApiNotFoundException;

public class CardTypeDoesNotExistException extends PipApiNotFoundException {

    public CardTypeDoesNotExistException(String message) {
        super(message);
    }
}
