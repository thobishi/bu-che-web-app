package com.dstvdm.bigdata.pip.card.controller;

import com.dstvdm.bigdata.pip.card.entity.Card;
import com.dstvdm.bigdata.pip.card.service.CardService;
import com.dstvdm.bigdata.pip.carddata.entity.CardData;
import com.dstvdm.bigdata.pip.pushnotifications.exceptions.NoSubscriptionException;
import lombok.AllArgsConstructor;
import lombok.extern.java.Log;
import nl.martijndwars.webpush.Subscription;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.util.Collection;
import java.util.List;

@RestController
@AllArgsConstructor
@Log
@RequestMapping(value = "api/card")
public class CardController {

    private CardService cardService;

    @GetMapping
    public List<Card> getTaggedCards(@RequestParam(required = false) List<String> tags) {
        return cardService.getTaggedCardList(tags);
    }

    @PostMapping
    public String addCard(@Valid @RequestBody Card card) {
        return cardService.createCard(card);
    }

    @PutMapping
    public void updateCard(@Valid @RequestBody Card card) {
        cardService.updateCard(card);
    }

    @DeleteMapping(value = "/{reference}")
    public void deleteCard(@PathVariable String reference) {
        cardService.deleteCard(reference);
    }

    @GetMapping(value = "/empty")
    public List<Card> getEmptyCards(@RequestParam(required = false) List<String> tags) {
        return cardService.getEmptyCards(tags);
    }

    @GetMapping(value = "/{reference}")
    public Card getCard(@PathVariable String reference) {
        return cardService.getCard(reference);
    }

    @GetMapping(value = "/tags")
    public Collection<String> getAllTags() {
        return cardService.getAllTags();
    }

    @GetMapping(value = "/{reference}/card-data/newest")
    public CardData getNewestCardData(@PathVariable String reference) {
        return cardService.getNewestCardData(reference);
    }

    @GetMapping(value = "/{reference}/card-data")
    public List<CardData> getCardData(@PathVariable String reference) {
        return cardService.getCardData(reference);
    }

    @PostMapping(value = "/{reference}/card-data")
    @CrossOrigin
    public void addCardData(@RequestBody CardData cardData, @PathVariable String reference) {
        cardService.addCardData(cardData, reference);
    }

    @PostMapping(value = "/{reference}/subscribe")
    public void subscribeToPushNotifications(@NotBlank @RequestBody Subscription subscription, @PathVariable String reference) {
        if (subscription.endpoint != null) {
            cardService.subscribeToCard(subscription, reference);
        } else {
            throw new NoSubscriptionException("Subscription endpoint was null");
        }
    }

    @RequestMapping(method = RequestMethod.GET, value = "/findByReferencePriorTo/{card_ref}/priorto/{priortodate}/numoccur/{numocc}")
    public List<CardData> getCardData( @PathVariable("card_ref") String card_ref, @PathVariable("priortodate") String priortodate, @PathVariable("numocc") String numocc) {
        log.info("Test!");
        return cardService.getCardData(card_ref, priortodate, numocc);
    }


}
