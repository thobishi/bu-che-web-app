package com.dstvdm.bigdata.pip.common.exception;

public abstract class PipApiBadRequestException extends PipApiException {

    public PipApiBadRequestException() {
    }

    public PipApiBadRequestException(String message) {
        super(message);
    }

    public PipApiBadRequestException(String message, Throwable cause) {
        super(message, cause);
    }

    public PipApiBadRequestException(Throwable cause) {
        super(cause);
    }

    public PipApiBadRequestException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
