package com.dstvdm.bigdata.pip.carddata.resource;

import com.dstvdm.bigdata.pip.card.entity.Card;
import com.dstvdm.bigdata.pip.carddata.entity.CardData;
import lombok.Data;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import java.util.List;

@Repository
public interface CardDataRepository extends JpaRepository<CardData, Long>{
    CardData findFirstByCardOrderByCreatedDesc(Card card);

    List<CardData> findTop20ByCardOrderByCreatedDesc(Card card);
}
