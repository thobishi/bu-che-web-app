package com.dstvdm.bigdata.pip.pushnotifications.controller;

import com.dstvdm.bigdata.pip.card.entity.Card;
import com.dstvdm.bigdata.pip.pushnotifications.entity.PushNotification;
import com.dstvdm.bigdata.pip.pushnotifications.service.PushNotificationsService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@AllArgsConstructor
@RequestMapping(value = "api/notifications")
public class PushNotificationsController {

    private PushNotificationsService pushNotificationsService;

    @PostMapping
    public void sendTestSub() {
        pushNotificationsService.sendTestMessageToAllSubs();
    }

    @GetMapping(value = "/{p256dh}")
    public PushNotification getPushNotification(@PathVariable String p256dh) {
        return pushNotificationsService.fetchPushNotification(p256dh);
    }

    @GetMapping(value = "/{p256dh}/cards")
    public Set<Card> getSubscribedCards(@PathVariable String p256dh) {
        return pushNotificationsService.getSubscribedCards(p256dh);
    }

    @DeleteMapping(value = "/{p256dh}/card/{cardReference}")
    public boolean removeCardFromSubscription(@PathVariable String p256dh, @PathVariable String cardReference) {
        return pushNotificationsService.removeCardFromSubscription(p256dh, cardReference);
    }

    @DeleteMapping(value = "/{p256dh}/card")
    public void removeAllCardsFromSubscription(@PathVariable String p256dh) {
        pushNotificationsService.removeAllCardsFromSubscription(p256dh);
    }

}
