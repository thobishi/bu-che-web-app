package com.dstvdm.bigdata.pip.cardcollection.service;

import com.dstvdm.bigdata.pip.card.entity.Card;
import com.dstvdm.bigdata.pip.card.service.CardService;
import com.dstvdm.bigdata.pip.cardcollection.entity.CardCollection;
import com.dstvdm.bigdata.pip.cardcollection.exception.CollectionDuplicateException;
import com.dstvdm.bigdata.pip.cardcollection.exception.NoCardCollectionException;
import com.dstvdm.bigdata.pip.cardcollection.resource.CardCollectionRepository;
import com.dstvdm.bigdata.pip.carddata.entity.CardData;
import com.dstvdm.bigdata.pip.carddata.service.CardDataService;
import lombok.AllArgsConstructor;
import lombok.extern.java.Log;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.lang.System.*;

@Service
@AllArgsConstructor
@Log
public class CardCollectionServiceImpl implements CardCollectionService {

    CardCollectionRepository repository;
    CardService cardService;
    CardDataService cardDataService;

    @Override
    public String createNewCollection(CardCollection cardCollection) {
        try {
            return repository.save(cardCollection).getReference();
        } catch (DataIntegrityViolationException ex) {
            throw new CollectionDuplicateException(ex.getRootCause().getMessage());
        }
    }

    @Override
    public List<CardCollection> getAllCardCollections() {
        return repository.findAllCollectionsExcludeCards();
    }


    @Override
    public void updateCollection(CardCollection updatedcollection) {
        CardCollection cardCollection = repository.findByReference(updatedcollection.getReference());

        if (cardCollection != null){

            cardCollection.setCollectionName(updatedcollection.getCollectionName());
            cardCollection.setDescription(updatedcollection.getDescription());
            cardCollection.setFontIcon(updatedcollection.getFontIcon());

            try {
                repository.save(cardCollection).getReference();
            } catch (DataIntegrityViolationException ex) {
                throw new CollectionDuplicateException(ex.getRootCause().getMessage());
            }

        } else {
            throw new NoCardCollectionException("no card collection found for reference:");
        }
    }

    @Override
    public CardCollection getCollectionByReference(String reference) {
        return repository.findCollectionExcludeCards(reference);
    }

    @Override
    public void addCardToCollection(String reference, String cardReference) {
        CardCollection cardCollection = repository.findByReference(reference);
        Card card = cardService.getCard(cardReference);
        cardCollection.getCards().add(card);
        repository.save(cardCollection);
    }

    @Override
    public boolean removeCardFromCollection(String reference, String cardReference) {
        CardCollection cardCollection = repository.findByReference(reference);
        Card card = cardService.getCard(cardReference);
        Set<Card> cards = cardCollection.getCards();
        boolean removed = cards.remove(card);
        repository.save(cardCollection);
        return removed;
    }

    @Override
    public Set<Card> getCardsInCollection(String reference) {
        CardCollection cardCollection = repository.findByReference(reference);
        if (cardCollection != null) {
            return cardCollection.getCards();
        } else {
            throw new NoCardCollectionException("no card collection found for reference:" + reference);
        }
    }

    @Override
    public List<Card> getCardsInCollection(String reference, List<String> tags) {
        if (reference.equals("all")) {
            return cardService.getTaggedCardList(tags);
        } else {
            if (tags == null || tags.isEmpty()) {
                ArrayList<Card> cards = new ArrayList<>();
                cards.addAll(getCardsInCollection(reference));
                return cards;
            } else {
                return cardService.getCardListForCollection(reference, tags);
            }
        }
    }

    @Override
    public List<CardData> getCollectionCardData(String reference, List<String> tags) {
        if (reference.equals("all")) {
            return cardDataService.findLatestCardData(tags);
        } else {
            Set<Card> cardsInCollection = getCardsInCollection(reference);
            if (tags == null || tags.isEmpty()) {
                return cardDataService.findLatestCardData(cardsInCollection);
            } else {
                return cardDataService.findLatestCardData(cardsInCollection, tags);
            }
        }
    }

    @Override
    public List<Card> getCollectionEmptyCard(String reference, List<String> tags) {
        if (reference.equals("all")) {
            return cardService.getEmptyCards(tags);
        } else {
            Set<Card> cardsInCollection = getCardsInCollection(reference);
            if (tags == null || tags.isEmpty()) {
                return cardService.getEmptyCards(cardsInCollection);
            } else {
                return cardService.getEmptyCards(cardsInCollection, tags);
            }
        }

    }

    @Override
    public Set<CardCollection> getCollectionsForCard(String cardReference) {
        return cardService.getCollectionForCard(cardReference);
    }


}
