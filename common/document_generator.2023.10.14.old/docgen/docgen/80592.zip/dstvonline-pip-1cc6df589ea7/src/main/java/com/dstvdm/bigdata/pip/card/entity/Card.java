package com.dstvdm.bigdata.pip.card.entity;

import com.dstvdm.bigdata.pip.cardcollection.entity.CardCollection;
import com.dstvdm.bigdata.pip.carddata.entity.CardData;
import com.dstvdm.bigdata.pip.cardtype.entity.CardType;
import com.dstvdm.bigdata.pip.common.ViewableStatus;
import com.dstvdm.bigdata.pip.common.entity.AuditingEntity;
import com.dstvdm.bigdata.pip.pushnotifications.entity.PushNotification;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import javax.persistence.*;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Entity
@Table(name = "card")
@Data
@EqualsAndHashCode(callSuper = true)
public class Card extends AuditingEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @NotBlank(message = "unique title is required")
    @Column(nullable = false, unique = true)
    private String title;
    @NotBlank(message = "description is required")
    @Column(nullable = false)
    private String description;
    @Column(nullable = false, unique = true)
    private String reference;
    @Enumerated(EnumType.ORDINAL)
    @Column(nullable = false)
    private ViewableStatus status;
    @Column
    private String tags;
    @Column
    private Double upperBound;
    @Column
    private Double lowerBound;


    @OneToOne(cascade = CascadeType.ALL)
    @NotFound(action = NotFoundAction.IGNORE)
    @JsonManagedReference
    private CardData latestCardData;

    @Valid
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name="card_type_id", nullable = false)
    private CardType cardType;

    @ManyToMany(fetch = FetchType.LAZY, mappedBy = "cards", cascade=CascadeType.ALL)
    @JsonIgnore
    private Set<CardCollection> cardCollection;

    @ManyToMany(fetch = FetchType.LAZY, mappedBy = "cards", cascade=CascadeType.ALL)
    private Set<PushNotification> pushNotifications;

    protected Card() {
    }

    public Card(@NotBlank(message = "unique title is required") String title,
                @NotBlank(message = "description is required") String description, String reference,
                @Valid CardType cardType, String tags) {
        this.title = title;
        this.description = description;
        this.reference = reference;
        this.cardType = cardType;
        this.tags = tags;
    }

    @PrePersist
    public void onCreate(){
        reference = UUID.randomUUID().toString();
        status = ViewableStatus.ACTIVE;
    }

    public void setTags(Set<String> tags){
        if(tags.isEmpty()){
            this.tags = null;
        }else{
            Set<String> nTags = new HashSet<>();
            for (String tag: tags) {
                nTags.add(tag.toLowerCase());
            }
            this.tags = String.join(",", tags);
        }
    }

    public Set<String> getTags(){
        if(tags == null){
            return new HashSet<>();
        }
        return new HashSet<>(Arrays.asList(this.tags.split(",")));
    }

    @JsonIgnore
    public void setLatestCardData(CardData latestCardData) {
        this.latestCardData = latestCardData;
    }

    @JsonIgnore
    public Set<PushNotification> getPushNotifications() {
        return pushNotifications;
    }
}
