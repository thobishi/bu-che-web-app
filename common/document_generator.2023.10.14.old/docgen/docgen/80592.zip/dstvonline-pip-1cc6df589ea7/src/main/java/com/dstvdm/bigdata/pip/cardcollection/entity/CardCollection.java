package com.dstvdm.bigdata.pip.cardcollection.entity;

import com.dstvdm.bigdata.pip.card.entity.Card;
import com.dstvdm.bigdata.pip.common.entity.AuditingEntity;
import com.fasterxml.jackson.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Entity
@Table(name = "cardcollection")
@Data
@ToString(exclude = "cards")
@EqualsAndHashCode(exclude = "cards", callSuper = true)
public class CardCollection extends AuditingEntity{

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @NotBlank(message = "unique collection name is required")
    @Column(nullable = false, unique = true)
    private String collectionName;
    @Column(nullable = false, unique = true)
    private String reference;
    @Column
    private String description;
    @Column
    private String fontIcon;

    @ManyToMany(fetch = FetchType.LAZY, cascade = { CascadeType.ALL })
    @JoinTable(
            name = "Collection_Card",
            joinColumns = { @JoinColumn(name="collection_id")},
            inverseJoinColumns = { @JoinColumn(name = "card_id")}
    )
    private Set<Card> cards;

    protected CardCollection(){
        this.cards = new HashSet<>();
    }

    public CardCollection(@NotBlank(message = "unique collection name is required")String collectionName, String reference, String fontIcon, String description){
        this.collectionName = collectionName;
        this.reference = reference;
        this.fontIcon = fontIcon;
        this.description = description;
        this.cards = new HashSet<>();
    }

    @PrePersist
    public void onCreate(){
        reference = UUID.randomUUID().toString();
    }

}
