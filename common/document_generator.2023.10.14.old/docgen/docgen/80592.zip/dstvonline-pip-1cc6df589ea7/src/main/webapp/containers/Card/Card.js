import React, {Component} from 'react';
import './Card.css';
import HtmlCard from "../../components/Cards/HtmlCard/HtmlCard";
import ImageCard from "../../components/Cards/ImageCard/ImageCard";
import NumberCard from "../../components/Cards/NumberCard/NumberCard";
import {
    AppBar,
    Card as MatCard,
    CardContent,
    Chip,
    Dialog,
    IconButton,
    Toolbar,
    Typography,
    withStyles
} from "@material-ui/core";
import CloseIcon from '@material-ui/icons/Close';
import CardHeader from "./CardHeader/CardHeader";
import * as randomMC from "random-material-color";
import {Shake} from "reshake";
import GraphCard from "../../components/Cards/GraphCard/GraphCard";

const styles = () => ({
    cardPinned: {
        boxShadow: "0 1px 5px 0 #000000FF"
    },
    cardActive: {
        background: 'white',
    },
    cardInactive: {
        background: 'rgba(0, 0, 0, 0.1)',
        color: 'rgba(0, 0, 0, 0.3)',
        boxShadow: "0 0 0 0 #000000FF",
    },
    textInactive: {
        color: 'rgba(0, 0, 0, 0.3)',
    },
    chip: {
        maxWidth: '150px',
        height: '25px'
    },
    chipInactive: {
        backgroundColor: 'red',
    },
    label: {
        overflow: 'hidden',
        color: 'white'
    },
});


class Card extends Component {

    constructor(props) {
        super(props);
        this.state = {
            cardData: null,
            openImage: false,
            enlargedImage: null,
            stompClient: null,
            shakeIterations: 0,
            visibilityDetection: true,
            loading: true,
        };
    }

    componentDidMount() {
        if (this.props.onRef) {
            this.props.onRef(this);
        }
        if (this.props.cardData) {
            this.setState({cardData: this.props.cardData});
            this.setState({loading: false});
        }
    }

    componentDidUpdate() {
        if (this.props.cardData && this.state.cardData) {
            if (this.state.cardData.created < this.props.cardData.created) {
                this.setState({cardData: this.props.cardData});
            }
        }
    }

    componentWillUnmount() {
        if (this.state.stompClient !== null) {
            this.state.stompClient.unsubscribe('/topic/card-data/' + this.props.card.reference);
        }
    }

    subscribeToCard(stompClient) {
        stompClient.subscribe('/topic/card-data/' + this.props.card.reference, cardData => {
            this.cardUpdateAnimation();
            this.props.setLatestCardData(this.props.card.reference, JSON.parse(cardData.body));
            this.setState({cardData: JSON.parse(cardData.body)}, () => {
                    if (this.props.card.cardType.id !== 1 && this.props.card.cardType.id !== 5) {
                        if (this.props.reloadMasonry && this.props.masonryRef) {
                            this.props.reloadMasonry(this.props.masonryRef);
                        }
                    }
                }
            );
        });
    };

    cardUpdateAnimation = () => {
        if (this.props.card.cardType.id !== 1 && this.props.card.cardType.id !== 4) {
            this.setState({shakeIterations: 1});
            setTimeout(() => {
                this.setState({shakeIterations: 0});
            }, 500);
        }
    };

    expandImage = (image) => {
        this.setState({openImage: true});
        this.setState({enlargedImage: image});
    };

    closeImageHandler = () => {
        this.setState({openImage: false});
        this.setState({enlargedImage: null});
    };

    render() {
        const {classes} = this.props;
        const imgStyle = {
            display: 'block',
            margin: 'auto',
            marginTop: '80px',
            maxHeight: "100%",
            maxWidth: "100%"
        };

        let headerFadeClass = true;
        if (this.props.priorityView === 'hidden' || !this.state.cardData) {
            headerFadeClass = false;
        }
        const cardHeader = (
            <CardHeader
                card={this.props.card}
                lastUpdate={this.state.cardData ? new Date(this.state.cardData.created) : null}
                detailedDateTime={this.props.detailedDateTime}
                statusColor={this.state.cardData ? this.state.cardData.status : "GRAY"}
                reloadCards={this.props.reloadCards}
                pinCard={this.props.pinCard}
                hideCard={this.props.hideCard}
                unPinCard={this.props.unPinCard}
                unHideCard={this.props.unHideCard}
                priorityView={this.props.priorityView}
                removeMenu={this.props.removeMenu}
                headerFadeClass={headerFadeClass ? '' : classes.textInactive}
                subscribed={this.props.subscribed}
                addSubscription={this.props.addSubscription}
                removeSubscription={this.props.removeSubscription}
            >
            </CardHeader>
        );

        let cardActions = null;
        if (!this.props.removeTags) {
            cardActions = (
                <CardContent>
                    {
                        this.props.card.tags.map((tag, i) => {
                            return (
                                <Chip
                                    key={i}
                                    classes={{root: classes.chip, label: classes.label}}
                                    style={headerFadeClass ? {backgroundColor: randomMC.getColor({text: tag})} : {backgroundColor: 'lightgrey'}}
                                    label={tag.toLowerCase()}
                                    onClick={() => this.props.addTagToFilter(tag.toLowerCase())}
                                />
                            )
                        })
                    }
                </CardContent>
            );
        }

        let card = '';
        if (this.props.priorityView === "hidden") {
            card = (
                <MatCard
                    className={['MatCard', classes.cardInactive].join(' ')}
                >
                    {cardHeader}
                </MatCard>
            )
        } else {
            if (this.props.card.cardType.id === 5) {
                card = (<ImageCard
                    styles={classes}
                    card={this.props.card}
                    cardData={this.state.cardData}
                    cardHeader={cardHeader}
                    cardActions={cardActions}
                    priorityView={this.props.priorityView}
                    expandImage={this.expandImage}/>)
            } else if (this.props.card.cardType.id === 1) {
                card = (<NumberCard
                    styles={classes}
                    card={this.props.card}
                    cardData={this.state.cardData}
                    cardHeader={cardHeader}
                    cardActions={cardActions}
                    priorityView={this.props.priorityView}
                />)
            } else if (this.props.card.cardType.id === 4) {
                card = (<GraphCard
                    styles={classes}
                    card={this.props.card}
                    cardData={this.state.cardData}
                    cardHeader={cardHeader}
                    cardActions={cardActions}
                    priorityView={this.props.priorityView}
                />)
            } else {
                card = (<HtmlCard
                    styles={classes}
                    card={this.props.card}
                    cardData={this.state.cardData}
                    cardHeader={cardHeader}
                    cardActions={cardActions}
                    priorityView={this.props.priorityView}
                />)
            }
        }

        return (
            <div>
                <Shake
                    fixed={true}
                    q={this.state.shakeIterations}
                >
                    <div style={{marginTop: '10px'}}>
                        {card}
                    </div>
                </Shake>

                <Dialog
                    fullScreen
                    open={this.state.openImage}
                    onClose={this.closeImageHandler}
                >
                    <AppBar>
                        <Toolbar>
                            <IconButton color="inherit" onClick={this.closeImageHandler} aria-label="Close">
                                <CloseIcon/>
                            </IconButton>
                            <Typography variant="title" color="inherit">
                                Image
                            </Typography>
                        </Toolbar>
                    </AppBar>

                    <img
                        style={imgStyle}
                        src={this.state.enlargedImage} alt="no data"/>
                </Dialog>
            </div>
        )
    }
}

export default withStyles(styles)(Card);