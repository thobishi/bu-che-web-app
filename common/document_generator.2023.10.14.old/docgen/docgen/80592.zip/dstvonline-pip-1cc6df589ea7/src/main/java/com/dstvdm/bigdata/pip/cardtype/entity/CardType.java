package com.dstvdm.bigdata.pip.cardtype.entity;

import com.dstvdm.bigdata.pip.common.entity.AuditingEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
@Data
@EqualsAndHashCode(callSuper = true)
public class CardType extends AuditingEntity {

    @NotNull(message = "card type is required")
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column(nullable = false)
    private String cardDisplayType;
    @Column(length = 1000)
    private String jsonexample;

    public CardType() {
    }

    public CardType(String cardDisplayType) {
        this.cardDisplayType = cardDisplayType;
    }

}
