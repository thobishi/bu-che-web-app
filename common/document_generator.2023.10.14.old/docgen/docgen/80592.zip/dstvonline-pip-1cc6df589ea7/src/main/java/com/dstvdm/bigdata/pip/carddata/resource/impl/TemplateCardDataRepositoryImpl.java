package com.dstvdm.bigdata.pip.carddata.resource.impl;

import com.dstvdm.bigdata.pip.card.entity.Card;
import com.dstvdm.bigdata.pip.carddata.entity.CardData;
import com.dstvdm.bigdata.pip.carddata.resource.TemplateCardDataRepository;
import com.dstvdm.bigdata.pip.cardtype.entity.CardType;
import lombok.Data;
import lombok.extern.java.Log;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import java.util.Date;
@Log
@Data
@Repository
public class TemplateCardDataRepositoryImpl implements TemplateCardDataRepository {

    private final JdbcTemplate jdbcTemplate;

    private static final String SQL_CARD_DATA_BY_CARD_IDS = "SELECT * FROM card_data WHERE card_id in ({ids});";

    private static final String SQL_LATEST_CARD_DATA_BY_CARD_IDS =
            "SELECT * FROM pip.card_data t1 inner join (\n" +
                "\tSELECT MAX(created) as created, card_id FROM (\n" +
                    "\t\tSELECT * FROM pip.card_data t3 WHERE card_id in ({ids})\n" +
                "\t) t3 GROUP BY card_id\n" +
            ") t2 on t1.card_id = t2.card_id and t1.created = t2.created;\n";

    @Override
    public List<CardData> findByCardIds(String ids) {
        return jdbcTemplate.query(SQL_CARD_DATA_BY_CARD_IDS.replace("{ids}", ids),
                new BeanPropertyRowMapper(CardData.class));
    }

    @Override
    public List<CardData> findByCardIds(Collection<String> ids) {
        return jdbcTemplate.query(SQL_CARD_DATA_BY_CARD_IDS.replace("{ids}", String.join(",", ids)),
                new BeanPropertyRowMapper(CardData.class));
    }

    @Override
    public List<CardData> findLatestByCardIds(Collection<String> ids) {
        String query = SQL_LATEST_CARD_DATA_BY_CARD_IDS.replace("{ids}", String.join(",", ids));

        System.out.println(query);

        return jdbcTemplate.query(query, new BeanPropertyRowMapper(CardData.class));
    }

    @Override
    public List<CardData> getLatestCardDataForCards() {
        return jdbcTemplate.query("SELECT card.*, card_data.data, card_data.status AS card_data_status, card_data.card_id, card_data.created FROM card INNER JOIN " +
                        "card_data ON card.id=card_data.card_id INNER JOIN " +
                        "(SELECT card_id, MAX(created) AS TopDate FROM card_data GROUP BY card_id)" +
                        "AS EachItem ON EachItem.TopDate = card_data.created AND EachItem.card_id=card_data.card_id WHERE card.status=0",
                (rs, rowNum) -> mapCardData(rs)
        );

    }

    @Override
    public List<CardData> getLatestCardDataForCards(List<String> tags) {
        return jdbcTemplate.query("SELECT card.*, card_data.data, card_data.status AS card_data_status, card_data.card_id, card_data.created FROM card INNER JOIN " +
                        "card_data ON card.id=card_data.card_id INNER JOIN " +
                        "(SELECT card_id, MAX(created) AS TopDate FROM card_data GROUP BY card_id)" +
                        "AS EachItem ON EachItem.TopDate = card_data.created AND EachItem.card_id=card_data.card_id WHERE card.status=0 AND (" + buildSqlGetCards(tags) + ")",
                (rs, rowNum) -> mapCardData(rs)
        );
    }

    @Override
    public List<CardData> getLatestCardDataForCards(Set<Card> cardsInCollection) {
        return jdbcTemplate.query("SELECT card.*, card_data.data, card_data.status AS card_data_status, card_data.card_id, card_data.created FROM card INNER JOIN " +
                        "card_data ON card.id=card_data.card_id INNER JOIN " +
                        "(SELECT card_id, MAX(created) AS TopDate FROM card_data GROUP BY card_id)" +
                        "AS EachItem ON EachItem.TopDate = card_data.created AND EachItem.card_id=card_data.card_id " +
                        "WHERE card.status=0 AND card_data.card_id IN (" +buildCardIds(cardsInCollection)+")",
                (rs, rowNum) -> mapCardData(rs)
        );
    }

    @Override
    public List<CardData> getLatestCardDataForCards(Set<Card> cardsInCollection, List<String> tags) {
        return jdbcTemplate.query("SELECT card.*, card_data.data, card_data.status AS card_data_status, card_data.card_id, card_data.created FROM card INNER JOIN " +
                        "card_data ON card.id=card_data.card_id INNER JOIN " +
                        "(SELECT card_id, MAX(created) AS TopDate FROM card_data GROUP BY card_id)" +
                        "AS EachItem ON EachItem.TopDate = card_data.created AND EachItem.card_id=card_data.card_id " +
                        "WHERE card.status=0 AND card_data.card_id IN (" +buildCardIds(cardsInCollection)+") AND (" + buildSqlGetCards(tags) + ")",
                (rs, rowNum) -> mapCardData(rs)
        );
    }

    @Override
    public List<CardData> getLatestCardDataForCardsByIds(List<Long> cardIds) {
        if (cardIds.size() > 0) {
            return jdbcTemplate.query("SELECT card.*, card_data.data, card_data.status AS card_data_status, card_data.card_id, card_data.created FROM card INNER JOIN " +
                            "card_data ON card.id=card_data.card_id INNER JOIN " +
                            "(SELECT card_id, MAX(created) AS TopDate FROM card_data GROUP BY card_id)" +
                            "AS EachItem ON EachItem.TopDate = card_data.created AND EachItem.card_id=card_data.card_id " +
                            "WHERE card.status=0 AND card_data.card_id IN (" + cardIds.stream().map(Object::toString).collect(Collectors.joining(",")) + ")",
                    (rs, rowNum) -> mapCardData(rs)
            );
        } else {
            return new ArrayList<>();
        }
    }

    @Override
    public Integer removeOldCardData() {
        return jdbcTemplate.update("DELETE from card_data WHERE created <= CURDATE() - INTERVAL 7 DAY limit 1000");
    }

    private CardData mapCardData(ResultSet rs) throws SQLException {
        CardType cardType = new CardType();
        cardType.setId(rs.getLong("card_type_id"));
        Card card = new Card(rs.getString("title"), rs.getString("description"),
                rs.getString("reference"), cardType, rs.getString("tags"));
        CardData cardData = new CardData(rs.getString("data"), rs.getTimestamp("created"),
                rs.getString("card_data_status"));
        cardData.setCard(card);
        return cardData;
    }

    private String buildSqlGetCards(List<String> tags) {
        List<String> tagsList = new ArrayList<>();
        for (String tag : tags) {
            tagsList.add("LOWER(tags) LIKE '%" + tag.toLowerCase() + "%'");
        }
        return String.join(" or ", tagsList);
    }

    private String buildCardIds(Set<Card> cards) {
        List<String> cardIdList = new ArrayList<>();
        for (Card card: cards) {
            cardIdList.add(card.getId().toString());
        }
        return String.join(",", cardIdList);
    }
}
