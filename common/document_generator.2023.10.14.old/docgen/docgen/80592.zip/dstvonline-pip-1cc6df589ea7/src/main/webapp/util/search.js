const indexSearch = (array, element, compareMap, compareField) => {

    let foundIndex = -1;
    array.some((el, index) => {
        if (compareMap[getFieldValue(el, compareField)] >= compareMap[element]) {
            foundIndex = index;
            return true;
        } else {
            return false;
        }
    });
    return foundIndex;

};

function getFieldValue(obj,path) {
    path=path.split('.');
    var res=obj;
    for (var i=0;i<path.length;i++) res=res[path[i]];
    return res;
}

export default indexSearch;