package com.dstvdm.bigdata.pip.card.service;

import com.dstvdm.bigdata.pip.card.entity.Card;
import com.dstvdm.bigdata.pip.card.exception.CardDuplicateException;
import com.dstvdm.bigdata.pip.card.exception.NoCardException;
import com.dstvdm.bigdata.pip.card.resource.CardRepository;
import com.dstvdm.bigdata.pip.card.resource.TemplateCardRepository;
import com.dstvdm.bigdata.pip.cardcollection.entity.CardCollection;
import com.dstvdm.bigdata.pip.carddata.entity.CardData;
import com.dstvdm.bigdata.pip.carddata.entity.CardDataStatus;
import com.dstvdm.bigdata.pip.carddata.exception.NoCardDataException;
import com.dstvdm.bigdata.pip.carddata.service.CardDataService;
import com.dstvdm.bigdata.pip.cardtype.entity.CardType;
import com.dstvdm.bigdata.pip.cardtype.exception.CardTypeDoesNotExistException;
import com.dstvdm.bigdata.pip.cardtype.service.CardTypeService;
import com.dstvdm.bigdata.pip.common.DateUtility;
import com.dstvdm.bigdata.pip.common.ViewableStatus;
import com.dstvdm.bigdata.pip.pushnotifications.service.PushNotificationsService;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import lombok.AllArgsConstructor;
import lombok.extern.java.Log;
import nl.martijndwars.webpush.Subscription;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@Log
@AllArgsConstructor
public class CardServiceImpl implements CardService {

    private CardDataService cardDataService;
    private CardTypeService cardTypeService;
    private PushNotificationsService pushNotificationsService;

    private CardRepository repository;
    private TemplateCardRepository templateCardRepository;

    private DateUtility dateUtility;

    @Override
    public String createCard(Card card) {
        Optional<CardType> cardType = cardTypeService.getCardType(card.getCardType().getId());
        if (cardType.isPresent()) {
            try {
                return repository.save(card).getReference();
            } catch (DataIntegrityViolationException ex) {
                throw new CardDuplicateException(ex.getRootCause().getMessage());
            }
        }
        throw new CardTypeDoesNotExistException("Could not find a card type");
    }

    @Override
    public void updateCard(Card card) {
        Optional<Card> cardFromDb = repository.findById(card.getId());
        if (cardFromDb.isPresent() && cardFromDb.get().getReference().equals(card.getReference())) {
            try {
                repository.save(card);
            } catch (DataIntegrityViolationException ex) {
                throw new CardDuplicateException(ex.getRootCause().getMessage());
            }
            return;
        }
        throw new NoCardException("Card you are trying to update does not exist: " + card.getTitle());
    }

    @Override
    public void deleteCard(String reference) {
        Card card = getCard(reference);
        card.setStatus(ViewableStatus.DELETED);
        repository.save(card);
    }

    @Override
    public List<Card> getCardList() {
        return repository.findAllByStatus(ViewableStatus.ACTIVE);
    }

    @Override
    public List<Card> getTaggedCardList(List<String> tags) {
        if (tags == null || tags.isEmpty()) {
            return getCardList();
        } else {
            List<Card> taggedCardList = templateCardRepository.getTaggedCardList(tags);
            taggedCardList.addAll(templateCardRepository.findEmptyCards(tags));
            return taggedCardList;
        }
    }

    @Override
    public Card getCard(String reference) {
        Card card = repository.findByReference(reference);
        if (card == null) {
            throw new NoCardException("Could not find card for " + reference);
        }
        return card;
    }

    @Override
    public CardData getNewestCardData(String reference) {
        Card card = getCard(reference);
        if (card.getLatestCardData() == null) {
            return cardDataService.getNewestCardData(card);
        } else {
            return card.getLatestCardData();
        }
    }

    @Override
    public List<CardData> getCardData(String reference) {
        Card card = getCard(reference);
        return cardDataService.getCardData(card);
    }

    @Override
    public void addCardData(CardData cardData, String reference) {
        Card card = getCard(reference);
        CardData oldCardData;
        try {
            oldCardData = cardDataService.getNewestCardData(card);
        } catch (NoCardDataException ex) {
            oldCardData = new CardData("", null);
        }
        if (cardData.getCreated() == null) {
            cardData.setCreated(dateUtility.getCurrentDate());
        }

        if (card.getCardType().getId()==1 && (card.getLowerBound() != null || card.getUpperBound() != null)) {
            JsonParser jsonParser = new JsonParser();
            JsonObject jsonObject = jsonParser.parse(cardData.getData()).getAsJsonObject();
            Integer number = jsonObject.get("number").getAsInt();
            if ((card.getLowerBound() != null && card.getLowerBound() > number) || (card.getUpperBound() != null && card.getUpperBound() < number))  {
                cardData.setStatus(CardDataStatus.RED);
            }
        }

        cardData.setCard(card);
        card.setLatestCardData(cardData);
        repository.save(card);
        cardDataService.addNewCardDataAndNotify(card, oldCardData);
    }

    @Override
    public Collection<String> getAllTags() {
        return templateCardRepository.findAllTags();
    }

    @Override
    public List<Card> getEmptyCards(List<String> tags) {
        if (tags == null || tags.isEmpty()) {
            return templateCardRepository.findEmptyCards();
        } else {
            return templateCardRepository.findEmptyCards(tags);
        }
    }

    @Override
    public List<Card> getEmptyCards(Set<Card> cards) {
        if (cards == null || cards.isEmpty()) {
            return new ArrayList<>();
        } else {
            return templateCardRepository.findEmptyCards(cards);
        }
    }

    @Override
    public List<Card> getEmptyCards(Set<Card> cards, List<String> tags) {
        if (cards == null || cards.isEmpty()) {
            return new ArrayList<>();
        } else if (tags == null || tags.isEmpty()) {
            return templateCardRepository.findEmptyCards(cards);
        } else {
            return templateCardRepository.findEmptyCards(cards, tags);
        }
    }

    @Override
    public Set<CardCollection> getCollectionForCard(String reference) {
        Card card = repository.findByReference(reference);
        return card.getCardCollection();
    }

    @Override
    public List<Card> getCardListForCollection(String collectionReference, List<String> tags) {
        if (tags == null || tags.isEmpty()) {
            return templateCardRepository.getCardListForCollection(collectionReference);
        } else {
            return templateCardRepository.getTaggedCardListForCollection(collectionReference, tags);
        }
    }

    @Override
    public void subscribeToCard(Subscription subscription, String reference) {
        Card card = repository.findByReference(reference);
        pushNotificationsService.addCardToNotification(card, subscription);

    }

    @Override
    public Set<Card> getCardsByReferences(Set<String> references) {
        Set<Card> cards = new HashSet<>();
        for (String reference : references) {
            cards.add(repository.findByReference(reference));
        }
        return cards;
    }

    @Override
    public List<CardData> getCardData(String card_ref, String datepriorto, String numocc) {
        return templateCardRepository.getCardData(card_ref, datepriorto, numocc);
    }

}