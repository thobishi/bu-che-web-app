package com.dstvdm.bigdata.pip.pushnotifications.exceptions;

import com.dstvdm.bigdata.pip.common.exception.PipApiNotFoundException;

public class NoSubscriptionException extends PipApiNotFoundException {

    public NoSubscriptionException(String message) {
        super(message);
    }
}
