import React from 'react';
import {Button} from "@material-ui/core";
import CardInputFields from "../Shared/CardInputFields/CardInputFields";

const newCardPopup = (props) => {

    return (
        <div style={{margin: '10px'}}>
            <h1>Create New Card</h1>
            <CardInputFields
                card={props.card}
                setField={props.setField}
                types={props.types}
                setType={props.setType}
                setTags={props.setTags}
                titleNull={props.titleNull}
            />
            <Button style={{float: 'right'}} color='primary' variant='outlined'
                    onClick={props.saveCard}>Submit</Button>
            <Button style={{float: 'right'}} color='primary' variant='outlined'
                onClick={props.cancelNewCard}>Cancel</Button>
        </div>
    )
};

export default newCardPopup;