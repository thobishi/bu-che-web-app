import React from 'react';
import {Card as MatCard, CardContent, withStyles} from '@material-ui/core';
import {VictoryAxis, VictoryLine, VictoryBar, VictoryChart, VictoryLabel, VictoryPie, VictoryPortal, VictoryTheme} from 'victory';

const styles = () => ({
    cardBody: {
        overflow: 'auto'
    },
});

function graphCard(props) {
    const {classes} = props;

    let cardData = {
        graphData: null,
        columns: [],
        rows: [],
        type: "TABLE",
    };

    if (props.cardData !== null) {
        try {
            const parsedCardData = JSON.parse(props.cardData.data);
            cardData.columns = parsedCardData.variables ? parsedCardData.variables : [];
            cardData.graphData = parsedCardData.rows.map((row) => row.values.concat(row.status));
            cardData.rows = parsedCardData.rows;
            cardData.type = parsedCardData.type ? parsedCardData.type : "TABLE";
        } catch (e) {
            console.log(props.card.title + " data not in correct format", e);
        }
    }


    let cardClass = 'MatCard';
    if (cardData.graphData !== null) {
        cardClass = [cardClass, props.styles.cardActive].join(' ');
    } else {
        cardClass = [cardClass, props.styles.cardInactive].join(' ');
    }

    if (props.priorityView === "pinned") {
        cardClass = [cardClass, props.styles.cardPinned].join(' ');
    }


    let graph = "";
    if (cardData.type.toUpperCase() === "LINE") {

    let linedata = cardData.graphData.map((dataPoint) => dataPoint[1]).map(coords => ({'x':coords[0], 'y':coords[1]}))

        graph = (<VictoryChart
                theme={VictoryTheme.material}
            >
                <VictoryLine

                    labels={cardData.graphData.map((dataPoint) => dataPoint[1]).map(coords => coords[1])}
                    data={linedata}
                />

                <VictoryAxis
                    tickLabelComponent={<VictoryPortal><VictoryLabel/></VictoryPortal>}
                    style={{
                        tickLabels: {padding: 15, angle: 45, verticalAnchor: "middle", textAnchor: 'start', fontSize: 10},
                    }}
                    tickValues={cardData.graphData.map((dataPoint) => dataPoint[1]).map(coords => coords[0])}
                    label={cardData.columns[0]}
                />

                <VictoryAxis
                    dependentAxis
                    tickLabelComponent={<VictoryPortal><VictoryLabel/></VictoryPortal>}
                    style={{
                        tickLabels: {padding: 15},
                    }}
                    label={cardData.columns[1]}
                />
            </VictoryChart>
        );

    } else if (cardData.type.toUpperCase() === "BAR") {
        graph = (<VictoryChart
                animate={{duration: 500}}
                domainPadding={20}
                theme={VictoryTheme.material}
            >
                <VictoryBar
                    style={{
                        data: {
                            fill: (d) => d[2] ? d[2] : "blue"
                        }
                    }}
                    data={cardData.graphData}
                    x={0}
                    y={1}
                    labels={cardData.graphData.map((dataPoint) => dataPoint[1])}
                    animate={{
                        duration: 200
                    }}
                />
                <VictoryAxis
                    tickLabelComponent={<VictoryPortal><VictoryLabel/></VictoryPortal>}
                    style={{
                        tickLabels: {padding: 15, angle: 45, verticalAnchor: "middle", textAnchor: 'start'},
                    }}
                    tickValues={cardData.graphData.map((dataPoint) => dataPoint[1])}
                    label={cardData.columns[0]}
                />
                <VictoryAxis
                    dependentAxis
                    tickLabelComponent={<VictoryPortal><VictoryLabel/></VictoryPortal>}
                    style={{
                        tickLabels: {padding: 15},
                    }}
                    label={cardData.columns[1]}
                />
            </VictoryChart>
        );
    } else if (cardData.type.toUpperCase() === "PIE") {
        graph = (<VictoryPie
                style={{labels: {angle: 30}}}
                labelComponent={<VictoryPortal><VictoryLabel/></VictoryPortal>}
                labelRadius={90}
                data={cardData.graphData}
                x={0}
                y={1}
                animate={{
                    duration: 200
                }}
                labels={cardData.graphData.map((dataPoint) => `${dataPoint[0]} (${dataPoint[1]})`)}
                theme={VictoryTheme.material}
            />
        )
    } else {
        const tableColumns = cardData.columns.map((column, key) => <th key={key}>{column}</th>);
        const tableRows = cardData.rows.map((row, key) => {
            let rowArray = [];
            if (row.values) {
                rowArray.push(row.values.map((datapoint, key) => <td key={key}>{datapoint}</td>));
            }
            if (row.status === "RED") {
                return <tr style={{color: "RED"}} key={key}>{rowArray}</tr>;
            }
            return <tr key={key}>{rowArray}</tr>;
        });

        graph = (
            <table
                style={{width: '100%', textAlign: 'left'}}
            >
                <thead>
                <tr>
                    {tableColumns}
                </tr>
                </thead>

                <tbody>
                {tableRows}
                </tbody>
            </table>
        );
    }


    return (
        <MatCard
            className={cardClass}>
            {props.cardHeader}
            <CardContent className={classes.cardBody}>
                <p hidden>{props.card.reference}</p>
                {graph}
            </CardContent>

            {props.cardActions}
        </MatCard>
    )

};

export default withStyles(styles)(graphCard);
