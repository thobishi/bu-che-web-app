import React from 'react';
import {Button, DialogActions, DialogContent, DialogTitle, Dialog} from "@material-ui/core";

const successNewCardPopup = (props) => {


    const greyBoxStyle = {
        backgroundColor: 'lightgray',
        padding: '16px',
        border: '1px solid black',
    };
    const darkGreyBoxStyle = {
        backgroundColor: 'gray',
        padding: '16px',
        border: '1px solid black',
        margin: '5px'
    };

    return (
        <div>
            <Dialog
                open={true}
                onClose={props.closePopup}
                // title="Successfully Created New Card"
                // actions={actions}
                // modal={false}
            >
                <DialogTitle>Successfully Created New Card</DialogTitle>
                <DialogContent>
                    <div style={greyBoxStyle}>
                        <h3>{props.card.title}</h3>
                        <p>{props.card.description}</p>
                        <h4>Use the below url to POST data to your card:</h4>
                        <p>{props.postCardDataUrl}</p>
                        <h4>Sample Json:</h4>
                        <div style={darkGreyBoxStyle}>
                            <p>{'{'}</p>
                                <p> "data": "date test" </p>
                                <p>}</p>
                        </div>
                    </div>
                </DialogContent>
                <DialogActions>
                    <Button onClick={props.closePopup}>OK</Button>
                </DialogActions>
            </Dialog>
        </div>
    )
};

export default successNewCardPopup;