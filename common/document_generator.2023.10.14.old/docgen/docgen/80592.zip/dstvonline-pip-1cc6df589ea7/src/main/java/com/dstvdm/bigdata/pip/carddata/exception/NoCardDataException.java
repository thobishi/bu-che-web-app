package com.dstvdm.bigdata.pip.carddata.exception;

import com.dstvdm.bigdata.pip.common.exception.PipApiNotFoundException;

public class NoCardDataException extends PipApiNotFoundException {

    public NoCardDataException(String message) {
        super(message);
    }
}
