package com.dstvdm.bigdata.pip.common;

import com.dstvdm.bigdata.pip.common.exception.PipApiBadRequestException;
import com.dstvdm.bigdata.pip.common.exception.PipApiNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ApiExceptionRestController {

    @ExceptionHandler(PipApiNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public String apiNotFoundException(Exception ex) {
        return ex.getMessage();
    }

    @ExceptionHandler(PipApiBadRequestException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public String apiBadRequestException(Exception ex) {
        return ex.getMessage();
    }

}
