package com.dstvdm.bigdata.pip.card.service;

import com.dstvdm.bigdata.pip.card.entity.Card;
import com.dstvdm.bigdata.pip.cardcollection.entity.CardCollection;
import com.dstvdm.bigdata.pip.carddata.entity.CardData;
import nl.martijndwars.webpush.Subscription;

import javax.annotation.security.RolesAllowed;
import java.util.Collection;
import java.util.List;
import java.util.Set;

public interface CardService {

    @RolesAllowed("ROLE_ADMIN")
    String createCard(Card card);

    @RolesAllowed("ROLE_ADMIN")
    void updateCard(Card card);

    @RolesAllowed("ROLE_ADMIN")
    void deleteCard(String reference);

    List<Card> getCardList();

    List<Card> getTaggedCardList(List<String> tags);

    Card getCard(String reference);

    CardData getNewestCardData(String reference);

    List<CardData> getCardData(String reference);

    void addCardData(CardData cardData, String reference);

    Collection<String> getAllTags();

    List<Card> getEmptyCards(List<String> tags);

    List<Card> getEmptyCards(Set<Card> cards);

    List<Card> getEmptyCards(Set<Card> cards, List<String> tags);

    Set<Card> getCardsByReferences(Set<String> references);

    Set<CardCollection> getCollectionForCard(String reference);

    List<Card> getCardListForCollection(String collectionReference, List<String> tags);

    void subscribeToCard(Subscription subscription, String cardReference);

    List<CardData> getCardData(String card_ref, String datepriorto, String numocc);
}
