package com.dstvdm.bigdata.pip.user.controller;


import com.dstvdm.bigdata.pip.user.User;
import lombok.extern.java.Log;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.NotBlank;
import java.security.Principal;

@RestController
@RequestMapping(value="api/user")
@Log
public class UserController {

    @GetMapping(value="/current")
    public User getCurrentRole(@NotBlank Principal principal, Authentication authentication) {
        User user = new User(principal.getName(), "USER");
        authentication.getAuthorities().forEach((auth) -> {
            if (auth.getAuthority().equals("ROLE_ADMIN")) {
                user.setRole("ADMIN");
            }
        });
        return user;
    }

}
