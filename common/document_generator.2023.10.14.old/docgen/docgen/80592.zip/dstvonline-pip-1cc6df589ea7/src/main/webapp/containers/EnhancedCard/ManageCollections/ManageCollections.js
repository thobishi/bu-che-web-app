import React from 'react';
import axios from "axios/index";
import {Button, Checkbox, Fade, FormControlLabel, Grid, Icon, withStyles} from "@material-ui/core";
import {connect} from "react-redux";

const styles = theme => ({
    label: {
        color: theme.palette.secondary.main,
        border: '2px solid ' + theme.palette.secondary.main,
        borderRadius: '5px',
    },
    center: {
        left: '50%',
        position: 'absolute',
    },
});

class ManageCollections extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            collectionChecklist: [],
            loading: true,
        }
    }

    componentDidMount() {
        axios.get('/api/card-collection')
            .then(responseAll => {
                axios.get('/api/card-collection/card/' + this.props.cardReference)
                    .then(responseSubscribe => {
                        responseAll.data.forEach((collection) => {
                            let addedToCollection = false;
                            responseSubscribe.data.forEach(subscribed => {
                                if (collection.reference === subscribed.reference) {
                                    this.addToCollectionChecklist(collection, true);
                                    addedToCollection = true;
                                    return true;
                                }
                            });
                            if (!addedToCollection) {
                                this.addToCollectionChecklist(collection, false);
                            }
                        });
                        this.sortCollectionChecklistByName();
                        this.setState({loading: false})
                    })
                    .catch(error => {
                        console.log("error getting subscribed collections", error);
                        this.setState({loading: false})
                    });
            })
            .catch(error => {
                console.log("error getting all collections", error);
                this.setState({loading: false})
            });


    }

    addToCollectionChecklist = (collection, subscribed) => {
        this.setState(prevState => ({
            collectionChecklist: [...prevState.collectionChecklist, {
                "collection": collection,
                "subscribed": subscribed,
                "update": false
            }]
        }))
    };

    sortCollectionChecklistByName = () => {
        let collectionChecklist = this.state.collectionChecklist;
        collectionChecklist.sort((a, b) => (a.collection.collectionName.toUpperCase() < b.collection.collectionName.toUpperCase()) ? -1 : 1);
        this.setState({
            collectionChecklist: collectionChecklist,
        })
    }

    collectionSubscriptionHandler = index => event => {
        let collectionChecklist = this.state.collectionChecklist;
        collectionChecklist[index].subscribed = event.target.checked;
        collectionChecklist[index].update = true;
        this.setState({
            collectionChecklist: collectionChecklist,
        })
    };

    updateCollectionSubscriptions = () => {
        this.state.collectionChecklist.forEach(collection => {
            if (collection.update) {
                if (collection.subscribed) {
                    axios.post('/api/card-collection/' + collection.collection.reference + '/card',
                        this.props.cardReference,
                        {
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        }
                    ).then(response => {
                        console.log('Success: ', response);
                        this.props.onShowSnackbar("Updated Collection")
                    })
                        .catch(error => {
                            console.log('Error: ', error);
                            this.props.onShowSnackbar("Failed to update collection!")
                        });
                } else {
                    axios.delete('/api/card-collection/' + collection.collection.reference + '/card/' + this.props.cardReference)
                        .then(response => {
                            console.log('Success: ', response);
                            this.props.onShowSnackbar("Updated Collection")
                        })
                        .catch(error => {
                            console.log('Error: ', error);
                            this.props.onShowSnackbar("Failed to update collection!")
                        });
                }
            }
        })
    };

    render() {
        const {classes} = this.props;

        const collectionChecklist = this.state.collectionChecklist.map((collection, index) => {
            return (
                <Grid item xs={6} sm={4} md={3} lg={2}
                      key={index}
                >
                    <FormControlLabel
                        classes={{label: collection.subscribed ? classes.label : null}}
                        control={
                            <Checkbox
                                checked={collection.subscribed}
                                onChange={this.props.userRole === "ADMIN" ? this.collectionSubscriptionHandler(index) : null}
                                value={collection.collection.reference}
                                icon={collection.collection.fontIcon ? <Icon>{collection.collection.fontIcon}</Icon> :
                                    <Icon>check_box_outline_blank</Icon>}
                                checkedIcon={collection.collection.fontIcon ?
                                    <Icon>{collection.collection.fontIcon}</Icon> : <Icon>check_box</Icon>}
                            />
                        }
                        label={collection.collection.collectionName}
                    />
                </Grid>
            )
        });

        let submitButton = null;
        if (this.props.userRole === "ADMIN") {
            submitButton = (
                <Button style={{float: 'right'}} variant="outlined" color="primary"
                        onClick={this.updateCollectionSubscriptions}>
                    Submit
                </Button>
            )
        }

        return (
            <div>
                {submitButton}
                <Fade
                    in={this.state.loading}
                    style={{
                        transitionDelay: this.state.loading ? '800ms' : '0ms',
                    }}
                >
                    <p className={classes.center}>Loading...</p>
                </Fade>
                <Grid container spacing={24}>
                    {collectionChecklist}
                </Grid>
            </div>
        )
    }

}

const mapDispatchToProps = dispatch => {
    return {
        onShowSnackbar: (snackbar) => dispatch({type: 'SHOW_SNACKBAR', value: snackbar})
    }
};

export default connect(null, mapDispatchToProps)(withStyles(styles)(ManageCollections));