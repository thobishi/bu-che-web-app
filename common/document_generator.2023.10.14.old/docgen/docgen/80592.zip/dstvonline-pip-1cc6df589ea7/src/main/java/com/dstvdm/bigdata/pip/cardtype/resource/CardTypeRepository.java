package com.dstvdm.bigdata.pip.cardtype.resource;

import com.dstvdm.bigdata.pip.cardtype.entity.CardType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;


public interface CardTypeRepository extends JpaRepository<CardType, Long> {

}
