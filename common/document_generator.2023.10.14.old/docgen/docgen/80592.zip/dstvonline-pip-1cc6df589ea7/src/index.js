import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import { createStore } from 'redux';
import { Provider } from 'react-redux';

import Routing from "./main/webapp/containers/Routing";
import reducer from './main/webapp/store/reducer'
import registerServiceWorker from './registerServiceWorker';

const store = createStore(reducer);
// const params = new URLSearchParams(window.location.search)


ReactDOM.render(<Provider store={store} ><Routing /></Provider>, document.getElementById('root'));
registerServiceWorker();
