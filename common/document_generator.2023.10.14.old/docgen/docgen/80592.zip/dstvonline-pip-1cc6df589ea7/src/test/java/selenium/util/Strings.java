package selenium.util;

public class Strings {

    public String image = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wgARCAACAAIDAREAAhEBAxEB/8QAFAABAAAAAAAAAAAAAAAAAAAAB//EABQBAQAAAAAAAAAAAAAAAAAAAAL/2gAMAwEAAhADEAAAARpD/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABBQJ//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwF//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwF//8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQAGPwJ//8QAFRABAQAAAAAAAAAAAAAAAAAAAQD/2gAIAQEAAT8hW//aAAwDAQACAAMAAAAQ/wD/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/EH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/EH//xAAYEAACAwAAAAAAAAAAAAAAAAAAAREhkf/aAAgBAQABPxBku3p//9k=";
    public String html = "<bold>Bold</bold><table style=\"width:100%;text-align:left;\"><tbody><tr><th>Table</th><th>Count</th></tr><tr><td>Row</td><td>11</td></tr><tr><td>Music</td><td>10</td></tr><tr><td>Parties</td><td>8</td></tr><tr><td>SAMA2018</td><td>7</td></tr><tr><td>henry danger</td><td>7</td></tr><tr><td>being bonang</td><td>6</td></tr><tr><td>movie</td><td>5</td></tr><tr><td>the queen</td><td>5</td></tr><tr><td>movies</td><td>4</td></tr><tr><td>Remember That Time with Judah and Lee</td><td>4</td></tr><tr><td>other</td><td>589</td></tr></tbody></table>";
}
