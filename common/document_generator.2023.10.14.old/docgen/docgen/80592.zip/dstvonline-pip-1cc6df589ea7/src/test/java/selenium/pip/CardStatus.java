package selenium.pip;

import org.json.JSONException;
import org.junit.Test;
import org.openqa.selenium.WebElement;
import selenium.util.TestBase;

import java.util.ArrayList;

public class CardStatus extends TestBase {

    @Test
    public void checkCardStatus() throws InterruptedException, JSONException {

        ArrayList<String> colors = new ArrayList<String>(){{
            add("GREEN");
            add("RED");
            add("AMBER");
            add("GRAY");
            add("BLUE");
        }};

        for(int i = 0; i < colors.size(); i++){
            String title = "Status check card " + colors.get(i) + " " + random();
            rest.deleteCardByTitle(title);
            String cardId = rest.postCard(title,"This is a status test card " + colors.get(i),1, new ArrayList<>());

            rest.postCardData(cardId, colors.get(i), "This is a " + colors.get(i) + " card");

            goTo(driver, "/card-collection/all");
            shortWait();

            WebElement status = getCardStatusByTitle(driver, title);
            waitForElementToAppear(driver, status);
            if(!status.getCssValue("background-color").equals(getRGBA(colors.get(i)))){
                assert false;
            }
            rest.deleteCardByTitle(title);
        }
    }
}
