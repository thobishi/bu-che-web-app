package integration.util;

import java.io.FileInputStream;
import java.io.IOException;

public class JsonFileReader {
    private static final String basePath = "src/test/resources/queries/";

    public static String readJSON(String jsonFile) throws IOException {
        FileInputStream fileInputStream = new FileInputStream(basePath + jsonFile);
        StringBuilder builder = new StringBuilder();

        int reader;
        while((reader = fileInputStream.read()) != -1){
            builder.append((char) reader);
        }

        return builder.toString();
    }
}
