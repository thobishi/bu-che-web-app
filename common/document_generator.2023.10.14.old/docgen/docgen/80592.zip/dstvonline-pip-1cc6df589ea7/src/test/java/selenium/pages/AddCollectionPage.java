package selenium.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class AddCollectionPage {
    @FindBy(xpath = "//*[@id=\"root\"]/div/div/div/div[1]/div/div/ul[2]/a[2]/div/div/h3")
    @CacheLookup
    public WebElement addCollectionButton;

    @FindBy(xpath = "//*[@id=\"root\"]/div/div/div[2]/div[1]/div/input")
    @CacheLookup
    public WebElement title;

    @FindBy(xpath = "//*[@id=\"root\"]/div/div/div[2]/div[2]/div/input")
    @CacheLookup
    public WebElement description;

    @FindBy(xpath = "//*[@id=\"root\"]/div/div/div[2]/div[3]/button[179]/span[1]/span")
    @CacheLookup
    public WebElement icon;

    @FindBy(xpath = "//*[@id=\"root\"]/div/div/div[2]/button[1]/span[1]")
    @CacheLookup
    public WebElement submit;

    @FindBy(xpath = "//*[@id=\"root\"]/div/div/div[2]/h1")
    @CacheLookup
    public WebElement collectionsHeading;

    @FindBy(xpath = "//*[@id=\"root\"]/div/div/div[1]/header/div/div/button/span[1]")
    @CacheLookup
    public WebElement collectionsShortcut;

    @FindBy(xpath = "/html/body/div[2]")
    @CacheLookup
    public WebElement collectionsModal;

    @FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[1]/a/div")
    @CacheLookup
    public WebElement firstCollectionModal;

    //Add constructor to initialize elements in class using PageFactory
    public AddCollectionPage(WebDriver driver) { PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20), this); }
}
