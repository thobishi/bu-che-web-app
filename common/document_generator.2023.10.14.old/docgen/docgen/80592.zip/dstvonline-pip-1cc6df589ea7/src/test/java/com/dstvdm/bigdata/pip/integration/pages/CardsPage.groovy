package com.dstvdm.bigdata.pip.integration.pages

import geb.Page
import org.openqa.selenium.By

class CardsPage extends Page {

    static url = "/card-collection/bdc9d869-82f5-4354-afc4-65eeff31d420"
    static at = { $("h2").find("a", 0).text() == "Test Automation" }
    static content = {
        cardStatus(wait: true) { $("span", text: "status test").parent().parent().find("div", 0).find("div", 0) }

        dataDom(wait: true){ $(By.xpath("//*[@id=\"root\"]/div/div/div/div[2]/div[2]/div/div/div/div[2]/div[2]")) }

        menuButton(wait: true) { $(By.xpath("//*[@id=\"root\"]/div/div/div/div[1]/header/div/button")) }
        createCard(wait: true, to: spock.pages.CreateCardPage) { $(By.xpath("//*[@id=\"root\"]/div/div/div/div[1]/div/div/ul[2]/div/a[1]/div")) }
    }
}