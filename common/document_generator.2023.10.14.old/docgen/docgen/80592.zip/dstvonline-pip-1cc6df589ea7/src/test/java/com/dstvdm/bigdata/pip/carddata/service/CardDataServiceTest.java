package com.dstvdm.bigdata.pip.carddata.service;

import com.dstvdm.bigdata.pip.card.entity.Card;
import com.dstvdm.bigdata.pip.card.service.CardService;
import com.dstvdm.bigdata.pip.carddata.entity.CardData;
import com.dstvdm.bigdata.pip.carddata.resource.CardDataRepository;
import com.dstvdm.bigdata.pip.common.DateUtility;
import org.hamcrest.Matchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.messaging.simp.SimpMessagingTemplate;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CardDataServiceTest {

    @InjectMocks
    private CardDataService service;

    @Mock
    private CardDataRepository cardDataRepository;
    @Mock
    private CardService cardService;
    @Mock
    private DateUtility dateUtility;
    @Mock
    private SimpMessagingTemplate template;

    @Test
    public void getNewestCardData() {

        CardData expected = mock(CardData.class);
        Card card = mock(Card.class);
        when(cardDataRepository.findFirstByCardOrderByCreatedDesc(card)).thenReturn(expected);
        when(card.getReference()).thenReturn("testUuid");
        when(cardService.getCard("testUuid")).thenReturn(card);

        CardData result = service.getNewestCardData(card);

        assertThat(result, Matchers.is(expected));
    }

    @Test
    public void getCardData() {
        Card card = mock(Card.class);
        CardData cardData1 = mock(CardData.class);
        CardData cardData2 = mock(CardData.class);
        CardData cardData3 = mock(CardData.class);

        List<CardData> cardDataList = new ArrayList<>();
        cardDataList.add(cardData1);
        cardDataList.add(cardData2);
        cardDataList.add(cardData3);


        when(card.getReference()).thenReturn("testUuid");
        when(cardService.getCard("testUuid")).thenReturn(card);
        when(cardDataRepository.findTop20ByCardOrderByCreatedDesc(card)).thenReturn(cardDataList);

        List<CardData> result = service.getCardData(card);

        assertThat(result, Matchers.hasItems(
                cardData1,
                cardData2,
                cardData3
        ));
    }

//    @Test
//    public void addCardData() {
//        CardData cardData = mock(CardData.class);
//        Card card = mock(Card.class);
//
//        service.addCardData(card, cardData);
//        verify(cardDataRepository).save(cardData);
//    }
//
//    // This
//    @Test
//    public void addCardDataWithNoDate() {
//        Date now = new Date();
//        CardData cardData = new CardData("Hello", null);
//        Card card = mock(Card.class);
//        when(dateUtility.getCurrentDate()).thenReturn(now);
//        service.addCardData(card, cardData);
//        assertEquals(now, cardData.getCreated());
//        verify(cardDataRepository).save(cardData);
//    }
//
//    @Test
//    public void addCardDataWithRedStatus(){
//        CardData cardData = new CardData("Hello", null, "red");
//        Card card = mock(Card.class);
//        service.addCardData(card, cardData);
//        assertEquals(CardDataStatus.RED, cardData.getStatus());
//        verify(cardDataRepository).save(cardData);
//    }
//
//    @Test
//    public void addCardDataWithNoStatus(){
//        CardData cardData = new CardData("Hello", null);
//        Card card = mock(Card.class);
//        service.addCardData(card, cardData);
//        assertEquals(null, cardData.getStatus());
//        verify(cardDataRepository).save(cardData);
//    }
}