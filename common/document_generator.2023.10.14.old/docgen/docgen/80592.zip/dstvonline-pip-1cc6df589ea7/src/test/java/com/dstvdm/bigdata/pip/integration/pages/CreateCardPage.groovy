package spock.pages

import geb.Page

class CreateCardPage extends Page {
    static url = "/card/add"
    static at = { $("h1").text() == "Create New Card" }
    static content = {

    }
}