package com.dstvdm.bigdata.pip.card.service;


import com.dstvdm.bigdata.pip.card.entity.Card;

import com.dstvdm.bigdata.pip.card.resource.CardRepository;

import com.dstvdm.bigdata.pip.card.resource.TemplateCardRepository;

import com.dstvdm.bigdata.pip.cardtype.entity.CardType;

import com.dstvdm.bigdata.pip.cardtype.service.CardTypeService;

import com.dstvdm.bigdata.pip.common.ViewableStatus;

import org.junit.Test;

import org.junit.runner.RunWith;

import org.mockito.InjectMocks;

import org.mockito.Mock;

import org.mockito.junit.MockitoJUnitRunner;


import java.util.ArrayList;

import java.util.Arrays;

import java.util.List;

import java.util.Optional;


import static org.hamcrest.Matchers.is;

import static org.junit.Assert.assertThat;

import static org.mockito.Mockito.mock;

import static org.mockito.Mockito.verify;

import static org.mockito.Mockito.when;


@RunWith(MockitoJUnitRunner.class)
public class CardServiceTest {


    @InjectMocks
    private CardServiceImpl service;

    @Mock
    private CardRepository cardRepository;

    @Mock
    private TemplateCardRepository templateCardRepository;

    @Mock
    private CardTypeService cardTypeService;


    @Test
    public void createCard() {


        Card card = mock(Card.class);

        CardType cardType = mock(CardType.class);

        when(card.getCardType()).thenReturn(cardType);

        when(cardTypeService.getCardType(card.getCardType().getId())).thenReturn(Optional.of(cardType));

        when(cardRepository.save(card)).thenReturn(card);


        String result = service.createCard(card);


        assertThat(result, is(card.getReference()));

    }


    @Test
    public void updateCard() {
        Card card = mock(Card.class);
        Optional<Card> cardFromDb = Optional.of(card);
        when(cardRepository.findById(card.getId())).thenReturn(cardFromDb);
        when(card.getReference()).thenReturn("testreference");
        when(cardFromDb.get().getReference()).thenReturn("testreference");
        service.updateCard(card);
        verify(cardRepository).save(card);

    }


    @Test
    public void deleteCard() {

        Card card = mock(Card.class);

        when(card.getReference()).thenReturn("testreference");

        when(cardRepository.findByReference("testreference")).thenReturn(card);


        card.setStatus(ViewableStatus.ACTIVE);

        service.deleteCard(card.getReference());


        verify(card).setStatus(ViewableStatus.DELETED);

        verify(cardRepository).save(card);

    }


    @Test
    public void getCardList() {

        List<Card> expected = new ArrayList<>();

        Card card1 = mock(Card.class);

        Card card2 = mock(Card.class);

        Card card3 = mock(Card.class);

        expected.add(card1);

        expected.add(card2);

        expected.add(card3);

        when(cardRepository.findAllByStatus(ViewableStatus.ACTIVE)).thenReturn(expected);


        List<Card> result = service.getCardList();


        assertThat(result, is(expected));

    }


    @Test
    public void getTaggedCardList() {

        List<Card> expected = new ArrayList<>();

        Card card1 = mock(Card.class);

        Card card2 = mock(Card.class);

        Card card3 = mock(Card.class);

        expected.add(card1);

        expected.add(card2);

        expected.add(card3);

        ArrayList<String> tags = new ArrayList<>(Arrays.asList("test", "local"));

        when(templateCardRepository.getTaggedCardList(tags)).thenReturn(expected);


        List<Card> result = service.getTaggedCardList(tags);

        assertThat(result, is(expected));

    }


    @Test
    public void getCard() {
        Card expected = mock(Card.class);
        when(cardRepository.findByReference("testUuid")).thenReturn(expected);


        Card result = service.getCard("testUuid");

        assertThat(result, is(expected));

    }


}