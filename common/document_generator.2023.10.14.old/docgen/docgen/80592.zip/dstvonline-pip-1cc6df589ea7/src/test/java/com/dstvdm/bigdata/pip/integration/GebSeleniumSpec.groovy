package com.dstvdm.bigdata.pip.integration

import com.dstvdm.bigdata.pip.integration.pages.*
import com.dstvdm.bigdata.pip.integration.resources.AuthCredentials
import static com.dstvdm.bigdata.pip.integration.resources.Strings.image

import geb.driver.CachingDriverFactory
import geb.spock.GebSpec
import spock.lang.Unroll

import com.jayway.restassured.RestAssured;
import static com.jayway.restassured.RestAssured.given;
import com.jayway.restassured.parsing.Parser

class GebSeleniumSpec extends GebSpec {
    def setup(){
        RestAssured.baseURI = baseUrl
        RestAssured.basePath = "/api"
        RestAssured
                .registerParser(
                "text/csv",
                Parser.TEXT
        )
    }

    def cleanup() {
        CachingDriverFactory.clearCache()
    }

    @Unroll
    def "Card Status: #status"() {
        given: "change card status"
        given().contentType("application/json")
                .body(""" {
                    "status":"${status}", 
                    "data":"{\\"number\\": 3}"
                 }  """)
                .header("Authorization", AuthCredentials.base36.admin)
                .post("/card/47a784a3-3f10-4998-aaed-c38224a42da1/card-data")

        when: "Go to all Cards page"
        to CardsPage

        then: "Check Card Status"
        assert cardStatus.css("background-color") == expectedColor

        cleanup:
        driver.close()

        where:
        status   || expectedColor            | expectedStatusCode
        "GREEN"  || "rgba(76, 175, 80, 1)"   | 200
        "RED"    || "rgba(244, 67, 54, 1)"   | 200
        "AMBER"  || "rgba(255, 193, 7, 1)"   | 200
        "BLUE"   || "rgba(33, 150, 243, 1)"  | 200
        "GRAY"   || "rgba(158, 158, 158, 1)" | 200
    }

    @Unroll
    def "Card Type: #type"(){
        given: "Clear card data and Post new card data"
        // post data
        given().contentType("application/json")
            .body(""" { "data": "${data}", "status": "GREEN"} """)
            .header("Authorization", AuthCredentials.base36.admin)
            .post("/card/${cardId}/card-data")

        when: "Go to all Cards page and filter by tag #type"
        to CardsPage
        sleep(500)
        $("div", role: "button").find("span", text: type.toString().toLowerCase()).click()

        then: "Check card data"
        sleep(1000)
        switch(type.toLowerCase()){
            case "text": assert dataDom.find("div", 0).text() == expectedData
                break
            case "html": assert dataDom.find("div", 0).text() == expectedData
                break
            case "number": assert dataDom.find("text", 0).text() == expectedData
                break
            case "image": assert dataDom.css("background-image").indexOf(expectedData) != -1
                break
        }

        cleanup:
        driver.close()

        where:
        cardId                                 | type     | data                                || expectedData           | expectedStatusCode
        "dfd99112-cfc5-41ba-8a2c-b03e44c674a3" | "Number" | "{\\\"number\\\": 100}"             || "100"                  | 200
        "8d59a58f-40d4-4e4a-874d-a83f76ce78c3" | "Image"  | "{\\\"src\\\": \\\"${image}\\\"}"   || image                  | 200
        "efb42a09-7bc9-4844-a395-a86d9b4aff3f" | "Text"   | "This is a text"                    || "This is a text"       | 200
        "35b267b1-f61e-4138-9d64-31788c641de2" | "Html"   | "This is an <b>Html</b> card"       || "This is an Html card" | 200
    }

    def "Create Card flow"(){
        when:
        to CardsPage
        menuButton.click()
        sleep(1000)
        createCardButton.click()

        then:
        true
    }
}