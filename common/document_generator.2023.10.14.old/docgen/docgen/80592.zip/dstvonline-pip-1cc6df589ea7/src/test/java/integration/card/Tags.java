package integration.card;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.parsing.Parser;
import integration.util.ConfigUtil;
import org.json.JSONException;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;

import static integration.util.PipHelper.*;

public class Tags {

    @BeforeClass
    public static void initialize() throws InterruptedException, IOException {
        Properties properties = ConfigUtil.getConfig();
        RestAssured.port = Integer.parseInt(properties.getProperty("server.port"));
        RestAssured.baseURI = properties.getProperty("server.address");
        RestAssured.basePath = "/api";
        RestAssured
                .registerParser(
                        "text/csv",
                        Parser.TEXT
                );
    }

    @Test
    public void tags() throws JSONException {
        ArrayList<String> tags = new ArrayList<String>(){{
            add("tag1");
            add("tag2");
            add("tag3");
        }};

        String title = "title_" + randomString();
        String desc = "description_" + randomString();

        String cardId = postCard(title, desc, 1, tags);

        ArrayList<String> tags_ = getCardTags(cardId);

        boolean tag1 = false;
        boolean tag2 = false;
        boolean tag3 = false;

        for(int i = 0; i < tags_.size(); i++){
            if(tags_.get(i).equals("tag1")){ tag1 = true; }
            if(tags_.get(i).equals("tag2")){ tag2 = true; }
            if(tags_.get(i).equals("tag3")){ tag3 = true; }
        }

        if(!tag1 || !tag2 || !tag3){
            assert false;
        }

        tags.remove(0);
        int cardIdDb = getCardIdDb(cardId);
        updateCard(cardId, cardIdDb, title, desc, 1, tags);

        tags_ = getCardTags(cardId);

        tag1 = false;
        tag2 = false;
        tag3 = false;

        for(int i = 0; i < tags_.size(); i++){
            if(tags_.get(i).equals("tag1")){ tag1 = true; }
            if(tags_.get(i).equals("tag2")){ tag2 = true; }
            if(tags_.get(i).equals("tag3")){ tag3 = true; }
        }

        if(tag1 || !tag2 || !tag3){
            assert false;
        }
    }

    @Test
    public void getCardsByTag() throws JSONException {
        ArrayList<String> tags = new ArrayList<String>(){{
            add("tag1");
        }};

        String title = "title_" + randomString();
        String desc = "description_" + randomString();

        String cardId1 = postCard(title, desc, 1, tags);

        tags = new ArrayList<String>(){{
            add("tag2");
        }};

        title = "title_" + randomString();
        desc = "description_" + randomString();

        String cardId2 = postCard(title, desc, 1, tags);

        if(!checkCard(cardId1) && !checkCard(cardId1)){ assert false; }

        if(!checkCardFiltered(cardId1, "tag1") && checkCardFiltered(cardId2, "tag1")){ assert false; }

        if(checkCardFiltered(cardId1, "tag2") && !checkCardFiltered(cardId2, "tag2")){ assert false; }

        if(!checkCardFiltered(cardId1, "tag1,tag2") && !checkCardFiltered(cardId2, "tag1,tag2")){ assert false; }
    }
}
