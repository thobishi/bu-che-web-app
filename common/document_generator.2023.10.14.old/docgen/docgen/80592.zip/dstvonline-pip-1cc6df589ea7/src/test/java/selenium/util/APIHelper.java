package selenium.util;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import static com.jayway.restassured.RestAssured.given;

public class APIHelper {

    static String basicAuth = "Basic YWRtaW46YXN5bHVtMTRtaW5pNTN0YWxlbnRlZCM=";

    public static String postCard(String title, String description, int type, ArrayList<String> tags) {
        HashMap card = new HashMap() {{
            put("title", title);
            put("description", description);
            put("cardType", new HashMap() {{
                put("id", type);
            }});
            put("tags", tags);
        }};

        return given()
                .when()
                .contentType("application/json")
                .header("Authorization", basicAuth)
                .body(card)
                .post("/card")
                .asString();
    }

    public static void updateCard(String cardId, int cardIdDb, String title, String description, int type, ArrayList<String> tags) {
        HashMap card = new HashMap() {{
            put("id", cardIdDb);
            put("reference", cardId);
            put("title", title);
            put("description", description);
            put("status", "ACTIVE");
            put("cardType", new HashMap() {{
                put("id", type);
            }});
            put("tags", tags);
        }};

        given()
                .when()
                .contentType("application/json")
                .header("Authorization", basicAuth)
                .body(card)
                .put("/card")
                .then()
                .statusCode(200);
    }

    public static String postCardData(String cardId, String status, String data) {
        HashMap card = new HashMap() {{
            put("status", status);
            put("data", data);
        }};

        return given()
                .when()
                .contentType("application/json")
                .header("Authorization", basicAuth)
                .body(card)
                .post("/card/" + cardId + "/card-data")
                .asString();
    }

    public static int getCardIdDb(String cardId) throws JSONException {
        int cardIdDB = 0;
        JSONArray cards = new JSONArray(given().contentType("application/json").header("Authorization", basicAuth).get("/card").asString());
        for (int i = 0; i < cards.length(); i++) {
            JSONObject card = cards.getJSONObject(i);
            if (card.getString("reference").equals(cardId)) {
                cardIdDB = card.getInt("id");
            }
        }
        return cardIdDB;
    }

    public static ArrayList<String> getCardTags(String cardId) throws JSONException {
        ArrayList<String> tags = new ArrayList<>();

        JSONArray cards = new JSONArray(given().contentType("application/json").header("Authorization", basicAuth).get("/card").asString());
        for (int i = 0; i < cards.length(); i++) {
            JSONObject card = cards.getJSONObject(i);
            if(card.getString("reference").equals(cardId)){
                JSONArray tags_ = card.getJSONArray("tags");
                for (int j = 0; j < tags_.length(); j++) {
                    tags.add(tags_.getString(j));
                }
            }
        }

        return tags;
    }

    public static boolean checkCard(String cardId) throws JSONException {
        JSONArray cards = new JSONArray(given().contentType("application/json").header("Authorization", basicAuth).get("/card").asString());
        boolean found = false;
        for (int i = 0; i < cards.length(); i++) {
            JSONObject card = cards.getJSONObject(i);
            if (card.getString("reference").equals(cardId)) {
                found = true;
            }
        }
        return found;
    }

    public static boolean checkCardFiltered(String cardId, String tags) throws JSONException {
        JSONArray cards = new JSONArray(given().contentType("application/json").header("Authorization", basicAuth).get("/card?tags="+tags).asString());
        boolean found = false;
        for (int i = 0; i < cards.length(); i++) {
            JSONObject card = cards.getJSONObject(i);
            if (card.getString("reference").equals(cardId)) {
                found = true;
            }
        }
        return found;
    }

    public static boolean checkCardData(String cardId, String status, String data) throws JSONException {
        JSONObject cardData = new JSONObject(given().contentType("application/json").header("Authorization", basicAuth).get("/card/" + cardId + "/card-data/newest").asString());
        boolean found = false;
        if (cardData.getString("status").equals(status) && cardData.getString("data").equals(data)) {
            found = true;
        }
        return found;
    }

    public static boolean checkAllCardData(String cardId, String status, String data) throws JSONException {
        JSONArray cardDatas = new JSONArray(given().contentType("application/json").header("Authorization", basicAuth).get("/card/" + cardId + "/card-data").asString());
        boolean found = false;
        for (int i = 0; i < cardDatas.length(); i++) {
            JSONObject cardData = cardDatas.getJSONObject(i);
            if (cardData.getString("status").equals(status) && cardData.getString("data").equals(data)) {
                found = true;
            }
        }
        return found;
    }

    public static void deleteCard(String cardId) throws JSONException {
        given()
                .when()
                .contentType("application/json")
                .header("Authorization", basicAuth)
                .delete("/card/" + cardId)
                .then()
                .statusCode(200);
    }

    public static void deleteCardByTitle(String title) throws JSONException {
        JSONArray cards = new JSONArray(given().contentType("application/json").header("Authorization", basicAuth).get("/card").asString());

        for(int i = 0; i < cards.length(); i++) {
            JSONObject card = cards.getJSONObject(i);

            if(card.getString("title").equals(title)){
                given()
                        .when()
                        .header("Authorization", basicAuth)
                        .delete("/card/" + card.getString("reference"))
                        .then()
                        .statusCode(200);
            }
        }
    }

    public static String randomString() {
        Random random = new Random();
        return "" + random.nextInt(99999);
    }

    public static void waitFor(int time) throws InterruptedException {
        Thread.sleep(time);
    }
}
