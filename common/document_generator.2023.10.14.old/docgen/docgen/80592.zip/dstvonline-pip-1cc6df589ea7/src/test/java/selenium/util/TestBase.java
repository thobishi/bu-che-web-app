package selenium.util;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.parsing.Parser;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import selenium.pages.CardsPage;

import java.util.Properties;
import java.util.Random;

public class TestBase extends Selenium {
    public static WebDriver driver;
    public static APIHelper rest;

    public static CardsPage  cardsPage;

    @BeforeClass
    public static void before() throws Exception {
        //setup REST api
        Properties properties = ConfigUtil.getConfig();
        RestAssured.port = 8094;
        RestAssured.baseURI = "http://10.10.54.187";
        RestAssured.basePath = "/api";
        RestAssured
                .registerParser(
                        "text/csv",
                        Parser.TEXT
                );

        // setup selenium
        System.setProperty("webdriver.chrome.driver", "chromedriver");
        driver = new ChromeDriver();
        driver.get(baseUrl);
        rest = new APIHelper();
        cardsPage = new CardsPage(driver);
    }

    @AfterClass
    public static void after() {
        if (driver != null) {
            driver.quit();
        }
    }

    public String getRGBA(String color){

        String colorHex = "rgba(76, 175, 80, 1)";

        switch (color.toLowerCase()) {
            case "green": colorHex = "rgba(76, 175, 80, 1)";
                break;
            case "red": colorHex = "rgba(244, 67, 54, 1)";
                break;
            case "amber": colorHex = "rgba(255, 193, 7, 1)";
                break;
            case "blue": colorHex = "rgba(33, 150, 243, 1)";
                break;
            case "gray": colorHex = "rgba(158, 158, 158, 1)";
                break;
        }
        return colorHex;
    }


    public String random(){
        Random rand = new Random();
        return ""+rand.nextInt(999999999);
    }
}