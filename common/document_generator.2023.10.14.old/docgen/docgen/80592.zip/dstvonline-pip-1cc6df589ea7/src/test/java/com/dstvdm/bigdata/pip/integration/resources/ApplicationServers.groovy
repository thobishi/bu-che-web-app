package com.dstvdm.bigdata.pip.integration.resources

class ApplicationServers {
    static addressOf = [
            EventsServers: [
                    SVD: "10.10.54.232:7071",
                    UR: "10.11.21.141:7070"
            ],
            PredictionServers:[
                    RecoUR: "10.11.21.121:8000",
                    TrendingUR: "10.11.21.131:8003",
                    TryThisUR: "10.10.54.232:7999"
            ],
            TrainingJobs: [
                    TrandingUR: "10.11.21.121:4041",
                    NowUR: "10.11.21.141:4040"
            ],
            Reco: [
                    Prod: "cs-reco.dstvo.internal:8080",
                    QA: "rnd-csreco-q1.dstvo.local:8080"
            ]
    ]
}