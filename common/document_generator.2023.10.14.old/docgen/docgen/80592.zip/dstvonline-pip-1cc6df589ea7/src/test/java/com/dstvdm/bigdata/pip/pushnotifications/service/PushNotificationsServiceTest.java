package com.dstvdm.bigdata.pip.pushnotifications.service;

import com.dstvdm.bigdata.pip.card.entity.Card;
import com.dstvdm.bigdata.pip.pushnotifications.entity.PushNotification;
import com.dstvdm.bigdata.pip.pushnotifications.resource.PushNotificationRepository;
import org.hamcrest.collection.IsEmptyCollection;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.HashSet;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class PushNotificationsServiceTest {

    @InjectMocks
    private PushNotificationsService service;
    @Mock
    private PushNotificationRepository repository;


    @Test
    public void removeAllCardsFromSubscription() throws Exception {
        String p256dh = "test-key";
        PushNotification pushNotification = new PushNotification("endpoint", "auth", p256dh);
        Card card1  = mock(Card.class);
        Card card2  = mock(Card.class);
        HashSet<Card> cards = new HashSet<>();
        cards.add(card1);
        cards.add(card2);
        pushNotification.setCards(cards);

        when(service.fetchPushNotification(p256dh)).thenReturn(pushNotification);
        service.removeAllCardsFromSubscription(p256dh);

        verify(repository).save(pushNotification);
        assertThat(pushNotification.getCards(), is(IsEmptyCollection.empty()));

    }

}