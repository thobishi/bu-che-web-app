package com.dstvdm.bigdata.pip.cardtype.service;

import com.dstvdm.bigdata.pip.cardtype.entity.CardType;
import com.dstvdm.bigdata.pip.cardtype.resource.CardTypeRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CardTypeServiceTest {

    @InjectMocks
    private CardTypeService service;

    @Mock
    private CardTypeRepository cardTypeRepository;

    @Test
    public void getCardTypes() {
        List<CardType> expected = new ArrayList<>();
        CardType cardType1 = mock(CardType.class);
        CardType cardType2 = mock(CardType.class);
        CardType cardType3 = mock(CardType.class);
        expected.add(cardType1);
        expected.add(cardType2);
        expected.add(cardType3);
        when(cardTypeRepository.findAll()).thenReturn(expected);

        List<CardType> result = service.getCardTypes();

        assertThat(result, is(expected));
    }
}