

import org.openqa.selenium.chrome.ChromeDriver

System.setProperty("webdriver.chrome.driver", "chromedriver");
driver = { new ChromeDriver() }
baseUrl = "http://admin:asylum14mini53talented%23@10.10.54.187:8094/"
reportsDir = new File("target/geb-reports")
reportOnTestFailureOnly = true

waiting {
    timeout = 10
    retryInterval = 1.0
}