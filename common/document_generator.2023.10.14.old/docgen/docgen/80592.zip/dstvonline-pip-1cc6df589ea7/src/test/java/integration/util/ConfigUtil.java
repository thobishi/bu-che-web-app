package integration.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ConfigUtil {
    public static Properties getConfig() throws IOException {
        InputStream resource = getResource();

        Properties properties = new Properties();
        properties.load(resource);

        return properties;
    }

    private static InputStream getResource() {
        String profile = System.getProperty("test.profile");

        return ConfigUtil
                .class
                .getClassLoader()
                .getResourceAsStream("application-" + profile + ".properties");
    }
}
