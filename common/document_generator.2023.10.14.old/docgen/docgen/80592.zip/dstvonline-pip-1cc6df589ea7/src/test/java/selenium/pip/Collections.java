package selenium.pip;

import org.json.JSONException;
import org.junit.Test;
import selenium.pages.AddCollectionPage;
import selenium.pages.CollectionsPage;
import selenium.pages.CardsPage;
import selenium.util.TestBase;

public class Collections extends TestBase {

    CollectionsPage collectionsPage = new CollectionsPage(driver);
    AddCollectionPage addCollectionPage = new AddCollectionPage(driver);
    CardsPage cardsPage = new CardsPage(driver);

    @Test
    public void addCollection() throws InterruptedException, JSONException {
        clickOnElementWhenClickable(driver, collectionsPage.menuButton);
        clickOnElementWhenClickable(driver, collectionsPage.addCollectionButton);

        String title = "New Collection Test " + random();
        enterTextBoxValue(addCollectionPage.title, title);
        enterTextBoxValue(addCollectionPage.description, title + " Description");
        clickOnElementWhenClickable(driver, addCollectionPage.icon);
        clickOnElementWhenClickable(driver, addCollectionPage.submit);

        waitForElementToAppear(driver, collectionsPage.collectionsHeading);
        getCollectionByTitle(driver, title);
    }

    @Test
    public void defaultView() throws InterruptedException, JSONException {
        waitForElementToAppear(driver, collectionsPage.collectionsHeading);
    }

    @Test
    public void collectionsShortcut() throws InterruptedException, JSONException {
        waitForElementToAppear(driver, collectionsPage.collectionsHeading);
        clickOnElementWhenClickable(driver, collectionsPage.collectionsShortcut);

        waitForElementToAppear(driver, collectionsPage.collectionsModal);
        clickOnElementWhenClickable(driver, collectionsPage.firstCollectionModal);

        waitForElementToAppear(driver, cardsPage.collectionTitle);
    }
}
