package integration.card;

import com.jayway.restassured.RestAssured;
import static com.jayway.restassured.RestAssured.given;
import static integration.util.PipHelper.*;

import com.jayway.restassured.parsing.Parser;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;

import integration.util.ConfigUtil;

public class Card {

    static String basicAuth = "Basic YWRtaW46YXN5bHVtMTRtaW5pNTN0YWxlbnRlZCM=";

    @BeforeClass
    public static void initialize() throws InterruptedException, IOException {
        Properties properties = ConfigUtil.getConfig();
        RestAssured.port = Integer.parseInt(properties.getProperty("server.port"));
        RestAssured.baseURI = properties.getProperty("server.address");
        RestAssured.basePath = "/api";
        RestAssured
                .registerParser(
                        "text/csv",
                        Parser.TEXT
                );
    }

    @Test
    public void createNewCard() throws JSONException {
        JSONArray cardTypes = new JSONArray(given().contentType("application/json").header("Authorization", basicAuth).get("/card-type").asString());

        for (int i = 0; i < cardTypes.length(); i++) {
            JSONObject cardType = cardTypes.getJSONObject(i);

            String cardId = postCard("title_" + randomString(), "description_" + randomString(), cardType.getInt("id"), new ArrayList<>());

            if(!checkCard(cardId)){
                assert(false);
            }

            deleteCard(cardId);

            if(checkCard(cardId)){
                assert(false);
            }
        }
    }
}
