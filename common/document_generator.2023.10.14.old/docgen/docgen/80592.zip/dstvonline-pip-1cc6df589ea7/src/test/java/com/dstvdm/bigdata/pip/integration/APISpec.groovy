

class APISpec {
}
