package selenium.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class CardsPage {
    @FindBy(xpath = "//*[@id=\"root\"]/div/div/div/div[1]/header/div/button")
    @CacheLookup
    public WebElement menuButton;

    @FindBy(xpath = "//*[@id=\"root\"]/div/div/div/div[1]/div/div/ul[2]/a[1]/div/div/h3")
    @CacheLookup
    public WebElement addNewCardButton;

    @FindBy(xpath = "//*[@id=\"root\"]/div/div/div/div[1]/div/div/*[local-name() = 'svg']")
    @CacheLookup
    public WebElement deleteTagFilter;

    @FindBy(xpath = "//*[@id=\"root\"]/div/div/div/div[1]/header/div/h2/a")
    @CacheLookup
    public WebElement collectionTitle;

    @FindBy(xpath = "//*span[text()='Description']")
    @CacheLookup
    public WebElement descriptionButton;

    //Add constructor to initialize elements in class using PageFactory
    public CardsPage(WebDriver driver) {
        PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20), this);
    }
}
