package com.dstvdm.bigdata.pip.integration.resources

import com.github.dzieciou.testing.curl.CurlLoggingRestAssuredConfigFactory
import io.restassured.config.RestAssuredConfig
import io.restassured.specification.RequestSpecification

import static io.restassured.RestAssured.given

class Requests {
    static private RestAssuredConfig curlLoggingConfig = CurlLoggingRestAssuredConfigFactory.createConfig()

    static RequestSpecification aRequest(@DelegatesTo(RequestSpecification) Closure closure) {
        def requestSpecification = given()
                .config(curlLoggingConfig)
                .contentType("application/json")
                .urlEncodingEnabled(false)
        closure.delegate = requestSpecification
        closure.run()
        requestSpecification
    }

    static RequestSpecification aRequest() {
        aRequest({})
    }
}