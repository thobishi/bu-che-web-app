package com.dstvdm.bigdata.pip.integration.resources

class AuthCredentials {
    static base36 = [
            admin: "Basic YWRtaW46YXN5bHVtMTRtaW5pNTN0YWxlbnRlZCM=",
            operator: "Basic b3BlcmF0aW9uczphc3lsdW0xNG1pbmk1M3RhbGVudGVk",
    ]
}
