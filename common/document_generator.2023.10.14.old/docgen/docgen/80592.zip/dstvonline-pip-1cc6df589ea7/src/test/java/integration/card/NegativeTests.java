package integration.card;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.parsing.Parser;
import integration.util.ConfigUtil;

import org.junit.BeforeClass;
import org.junit.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.containsString;

public class NegativeTests {

    static String basicAuth = "Basic YWRtaW46YXN5bHVtMTRtaW5pNTN0YWxlbnRlZCM=";

    @BeforeClass
    public static void initialize() throws InterruptedException, IOException {
        Properties properties = ConfigUtil.getConfig();
        RestAssured.port = Integer.parseInt(properties.getProperty("server.port"));
        RestAssured.baseURI = properties.getProperty("server.address");
        RestAssured.basePath = "/api";
        RestAssured
                .registerParser(
                        "text/csv",
                        Parser.TEXT
                );
    }

    @Test
    public void invalidCardType() {
        HashMap card = new HashMap() {{
            put("title", "negative test title");
            put("description", "negative test description");
            put("cardType", new HashMap() {{
                put("id", -9);
            }});
        }};

        given()
                .when()
                    .contentType("application/json")
                    .header("Authorization", basicAuth)
                    .body(card)
                    .post("/card")
                .then()
                    .statusCode(404);
    }

    @Test
    public void noCardTitle() {
        HashMap card = new HashMap() {{
            put("title", "");
            put("description", "negative test description");
            put("cardType", new HashMap() {{
                put("id", 1);
            }});
        }};

        given()
                .when()
                .contentType("application/json")
                .header("Authorization", basicAuth)
                .body(card)
                .post("/card")
                .then()
                .body(containsString("Bad Request"))
                .statusCode(400);
    }

    @Test
    public void noCardDescription() {
        HashMap card = new HashMap() {{
            put("title", "negative test title");
            put("description", "");
            put("cardType", new HashMap() {{
                put("id", 1);
            }});
        }};

        given()
                .when()
                .contentType("application/json")
                .header("Authorization", basicAuth)
                .body(card)
                .post("/card")
                .then()
                .body(containsString("Bad Request"))
                .statusCode(400);
    }
}
