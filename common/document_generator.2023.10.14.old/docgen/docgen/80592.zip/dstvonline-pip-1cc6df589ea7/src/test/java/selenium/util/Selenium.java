package selenium.util;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;

public class Selenium {

    static String baseUrl = "http://admin:asylum14mini53talented%23@10.10.54.187:8094";

    public static void selectAnItemFromDropdown(WebElement element, String value) {
        new Select(element).selectByVisibleText(value);
    }

    public static void enterTextBoxValue(WebElement element, String value) {
        element.sendKeys(value);
    }

    public static void click(WebElement element) {
        if (element.isEnabled())
            element.click();
        else {
            assert(false);
        }
    }

    public static void waitForElementToAppear(WebDriver driver, WebElement element) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(ExpectedConditions.visibilityOf(element));
        } catch (org.openqa.selenium.NoSuchElementException e) {
        }
    }

    public static boolean isWebElementDisplayOnAPage(WebElement element) {
        return element.isDisplayed();
    }

    public static void waitForElementToBeClickable(WebDriver driver, WebElement element) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(ExpectedConditions.elementToBeClickable(element));
        } catch (org.openqa.selenium.NoSuchElementException e) {
        }
    }

    public static void clickOnElementWhenClickable(WebDriver driver, WebElement element) {

        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(
                elementToBeClickable
                        (element));

        if (element.isEnabled())
            element.click();
        else {
            assert(false);
        }
    }

    public static void clickOnScreen(WebDriver driver){
        driver.findElement(By.xpath("//body")).click();
    }

    public static void waitForTextVisible(WebDriver driver, String text) {
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("//*"), text));
    }

    public static void waitForTextNotVisible(WebDriver driver, String text) {
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.invisibilityOfElementWithText(By.xpath("//*"), text));
    }

    public static void shortWait() {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void wait(int time) {
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void refrestPage(WebDriver driver){ driver.navigate().refresh(); }

    public WebElement getCardMenuButtonByTitle(WebDriver driver, String title){
        return driver.findElement(By.xpath("//div[./div[./span[text()='"+title+"']]]/div[3]/div/button/span"));
    }

    public WebElement getCardImageViewByTitle(WebDriver driver, String title){
        return driver.findElement(By.xpath("//div[./div[./div[./div[./span[text()='"+title+"']]]]]/div[2]"));
    }

    public WebElement getCardStatusByTitle(WebDriver driver, String title){
        return driver.findElement(By.xpath("//div[./div[./span[text()='"+title+"']]]/div[1]/div"));
    }

    public WebElement getCardTagByTitle(WebDriver driver, String title){
        return driver.findElement(By.xpath("//div[./div[./div[./div[./span[text()='"+title+"']]]]]/div[3]/div/span"));
    }

    public WebElement getCollectionByTitle(WebDriver driver, String title){
        return driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[2]/div/div/div[./a/div/div[2]/span[text()='"+title+"']]/a/div/div[2]/span"));
    }

    public void goTo(WebDriver driver, String url){
        driver.get(baseUrl + url);
    }

}
