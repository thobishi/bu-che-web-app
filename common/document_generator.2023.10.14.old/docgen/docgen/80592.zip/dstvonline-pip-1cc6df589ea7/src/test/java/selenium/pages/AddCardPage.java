package selenium.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class AddCardPage {

    @FindBy(xpath = "//*[@id=\"root\"]/div/div/div[2]/div/div/div[1]/div/input")
    @CacheLookup
    public WebElement title;

    @FindBy(xpath = "//*[@id=\"root\"]/div/div/div[2]/div/div/div[2]/div/div/textarea[3]")
    @CacheLookup
    public WebElement description;

    @FindBy(xpath = "//*[@id=\"root\"]/div/div/div[2]/div/div/div[3]/span/input")
    @CacheLookup
    public WebElement tags;


    @FindBy(xpath = "//*[@id=\"root\"]/div/div/div[2]/div/button[1]")
    @CacheLookup
    public WebElement submitButton;

    @FindBy(xpath = "/html/body/div[2]/div[2]/div[3]/button")
    @CacheLookup
    public WebElement dismissCardCreatedButton;

    //Add constructor to initialize elements in class using PageFactory
    public AddCardPage(WebDriver driver) { PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20), this); }
}
