package selenium.pip;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Test;
import selenium.util.TestBase;
import selenium.util.Strings;

import java.util.ArrayList;

import static com.jayway.restassured.RestAssured.given;

public class CardTypes extends TestBase {

    static String basicAuth = "Basic YWRtaW46YXN5bHVtMTRtaW5pNTN0YWxlbnRlZCM=";
    Strings strings = new Strings();

    @Test
    public void checkCardTypes() throws InterruptedException, JSONException {

        JSONArray cardTypes = new JSONArray(given()
                .contentType("application/json")
                .header("Authorization", basicAuth)
                .get("/card-type").asString());

        for(int i = 0; i < cardTypes.length(); i++) {

            JSONObject cardType = cardTypes.getJSONObject(i);

            double num = 304.99;
            String data = "";
            switch (cardType.getString("cardDisplayType").toLowerCase()) {
                case "image": data = "{\"src\":\"" + strings.image + "\"}";
                    break;
                case "text": data = "This is a text test";
                    break;
                case "number": data = "{\"number\" : " + num + "}";
                    break;
                case "html": data = strings.html;
                    break;
            }

            String title = cardType.getString("cardDisplayType") + " card type title " + random();
            rest.deleteCardByTitle(title);
            String cardId = rest.postCard(title, cardType.getString("cardDisplayType") + " card type description", cardType.getInt("id"), new ArrayList<>());
            rest.postCardData(cardId,"GREEN", data);

            goTo(driver, "/card-collection/all");
            shortWait();
            switch (cardType.getString("cardDisplayType").toLowerCase()) {
                case "image":
                    waitForElementToAppear(driver, getCardImageViewByTitle(driver, title));
                    break;
                case "text":
                    waitForTextVisible(driver, data);
                    break;
                case "number":
                    waitForTextVisible(driver, "" + num);
                    break;
                case "html":
                    waitForTextNotVisible(driver, "<th>Table</th>");
                    waitForTextVisible(driver, "Table");
                    break;
            }
            rest.deleteCardByTitle(title);
        }
    }
}
