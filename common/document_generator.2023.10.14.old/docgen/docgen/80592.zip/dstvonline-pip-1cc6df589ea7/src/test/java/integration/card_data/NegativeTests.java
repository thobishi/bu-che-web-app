package integration.card_data;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.parsing.Parser;
import integration.util.ConfigUtil;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

import static com.jayway.restassured.RestAssured.given;
import static integration.util.PipHelper.postCard;
import static integration.util.PipHelper.randomString;
import static org.hamcrest.CoreMatchers.containsString;

public class NegativeTests {

    static String basicAuth = "Basic b3BlcmF0aW9uczphc3lsdW0xNG1pbmk1M3RhbGVudGVk";

    @BeforeClass
    public static void initialize() throws InterruptedException, IOException {
        Properties properties = ConfigUtil.getConfig();
        RestAssured.port = Integer.parseInt(properties.getProperty("server.port"));
        RestAssured.baseURI = properties.getProperty("server.address");
        RestAssured.basePath = "/api";
        RestAssured
                .registerParser(
                        "text/csv",
                        Parser.TEXT
                );
    }

    @Test
    public void invalidCardId() {
        HashMap cardData = new HashMap() {{
            put("status", "RED");
            put("data", "Twitter PR disaster resolved");
        }};

        String cardId = "invalidCardId";

        given()
            .when()
                .contentType("application/json")
                .header("Authorization", basicAuth)
                .body(cardData)
                .post("/card/" + cardId + "/card-data")
            .then()
                .statusCode(404);
    }

    @Test
    public void noCardDataStatus() {

        String cardId = postCard("title_" + randomString(), "description_" + randomString(), 1, new ArrayList<>());

        HashMap cardData = new HashMap() {{
            put("status", "");
            put("data", "Twitter PR disaster resolved");
        }};

        given()
                .when()
                .contentType("application/json")
                .header("Authorization", basicAuth)
                .body(cardData)
                .post("/card/" + cardId + "/card-data")
                .then()
                .statusCode(400)
                .body(containsString("Bad Request"));
    }
}
