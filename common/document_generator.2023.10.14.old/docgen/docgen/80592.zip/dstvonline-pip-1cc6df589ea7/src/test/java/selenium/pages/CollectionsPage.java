package selenium.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class CollectionsPage {
    @FindBy(xpath = "//*[@id=\"root\"]/div/div[1]/div[1]/header/div/button/span[1]")
    @CacheLookup
    public WebElement menuButton;

    @FindBy(xpath = "//*[@id=\"root\"]/div/div/div[1]/div/div/ul[2]/a[2]/div/div/h3")
    @CacheLookup
    public WebElement addCollectionButton;

    @FindBy(xpath = "//*[@id=\"root\"]/div/div/div[2]/h1")
    @CacheLookup
    public WebElement collectionsHeading;

    @FindBy(xpath = "//*[@id=\"root\"]/div/div/div[1]/header/div/div/button/span[1]")
    @CacheLookup
    public WebElement collectionsShortcut;

    @FindBy(xpath = "/html/body/div[2]")
    @CacheLookup
    public WebElement collectionsModal;

    @FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[1]/a/div")
    @CacheLookup
    public WebElement firstCollectionModal;

    //Add constructor to initialize elements in class using PageFactory
    public CollectionsPage(WebDriver driver) { PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20), this); }
}
