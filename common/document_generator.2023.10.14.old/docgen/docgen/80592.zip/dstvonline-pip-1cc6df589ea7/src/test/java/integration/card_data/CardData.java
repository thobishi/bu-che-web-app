package integration.card_data;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.parsing.Parser;
import integration.util.ConfigUtil;
import org.json.JSONException;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;

import static integration.util.PipHelper.*;

public class CardData {

    @BeforeClass
    public static void initialize() throws InterruptedException, IOException {
        Properties properties = ConfigUtil.getConfig();
        RestAssured.port = Integer.parseInt(properties.getProperty("server.port"));
        RestAssured.baseURI = properties.getProperty("server.address");
        RestAssured.basePath = "/api";
        RestAssured
                .registerParser(
                        "text/csv",
                        Parser.TEXT
                );
    }

    @Test
    public void addCardData() throws JSONException, InterruptedException {
        String cardId = postCard("title_" + randomString(), "description_" + randomString(), 1, new ArrayList<>());

        String status = "RED";
        String data = "Twitter PR disaster";
        postCardData(cardId, status, data);

        if(!checkCardData(cardId, status, data)){
            assert(false);
        }

        waitFor(1000);

        status = "GREEN";
        String data_ = "Twitter PR disaster resolved";
        postCardData(cardId, status, data_);

        if(!checkCardData(cardId, status, data_)){
            assert(false);
        }

        if(!checkAllCardData(cardId, status, data) && !checkAllCardData(cardId, status, data_)){
            assert(false);
        }

        deleteCard(cardId);
    }
}
