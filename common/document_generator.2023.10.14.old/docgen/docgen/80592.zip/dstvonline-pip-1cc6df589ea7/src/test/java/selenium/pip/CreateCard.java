package selenium.pip;

import org.json.JSONException;

import org.junit.Test;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import selenium.pages.AddCardPage;
import selenium.pages.CardsPage;
import selenium.util.TestBase;

import java.util.ArrayList;

public class CreateCard extends TestBase {

    CardsPage cardsPage = new CardsPage(driver);
    AddCardPage addCardPage = new AddCardPage(driver);

    @Test
    public void createCard() throws InterruptedException, JSONException {

        String title = "New Card Test " + random();
        rest.deleteCardByTitle(title);
        String description = "New Card Description Test";

        goTo(driver, "/card-collection/all");
        clickOnElementWhenClickable(driver, cardsPage.menuButton);
        clickOnElementWhenClickable(driver, cardsPage.addNewCardButton);

        waitForElementToAppear(driver, addCardPage.title);
        enterTextBoxValue(addCardPage.title, title);
        enterTextBoxValue(addCardPage.description, description);
        clickOnElementWhenClickable(driver, addCardPage.submitButton);

        shortWait();
        clickOnElementWhenClickable(driver, addCardPage.dismissCardCreatedButton);

        goTo(driver, "/card-collection/all");

        shortWait();
        waitForTextVisible(driver, title);

        shortWait();
        WebElement menuButton = getCardMenuButtonByTitle(driver, title);

        clickOnElementWhenClickable(driver, menuButton);
        clickOnElementWhenClickable(driver, cardsPage.descriptionButton);
        waitForTextVisible(driver, description);

        rest.deleteCardByTitle(title);
    }

    @Test
    public void createCardWithNoTitle() throws InterruptedException, JSONException {

        String title = "New Card Test " + random();
        rest.deleteCardByTitle(title);
        refrestPage(driver);
        String description = "New Card Description Test";

        goTo(driver, "/card/add");

        waitForElementToAppear(driver, addCardPage.title);
        enterTextBoxValue(addCardPage.description, description);
        clickOnElementWhenClickable(driver, addCardPage.submitButton);

        shortWait();
        waitForTextNotVisible(driver, title);
        waitForTextNotVisible(driver, description);
    }

    @Test
    public void cardWithTags() throws JSONException {
        String title = "Tags Card " + random();
        rest.deleteCardByTitle(title);
        String description = "New Tag Description Test";
        String tag1 = "tag1_" + random();
        String tag2 = "tag2_" + random();

        goTo(driver, "/card/add");
        waitForElementToAppear(driver, addCardPage.title);
        enterTextBoxValue(addCardPage.title, title);
        enterTextBoxValue(addCardPage.description, description);

        enterTextBoxValue(addCardPage.tags, tag1);
        addCardPage.tags.sendKeys(Keys.RETURN);
        enterTextBoxValue(addCardPage.tags, tag2);
        addCardPage.tags.sendKeys(Keys.RETURN);

        clickOnElementWhenClickable(driver, addCardPage.submitButton);

        shortWait();
        clickOnElementWhenClickable(driver, addCardPage.dismissCardCreatedButton);

        goTo(driver, "/card-collection/all");

        shortWait();
        waitForTextVisible(driver, title);
        waitForTextVisible(driver, tag1);
        waitForTextVisible(driver, tag2);

        rest.deleteCardByTitle(title);
    }

    @Test
    public void tagFiltering() throws JSONException {
        String tag1 = "tag1_" + random();
        String tag2 = "tag2_" + random();

        String title1 = "Tags Card " + random();
        rest.postCard(title1, "Tag filtering", 1, new ArrayList<String>(){{ add(tag1); }});

        String title2 = "Tags Card " + random();
        rest.postCard(title2, "Tag filtering", 1, new ArrayList<String>(){{ add(tag2); }});

        goTo(driver, "/card-collection/all");
        waitForTextVisible(driver, title1);

        WebElement tag1_ = getCardTagByTitle(driver, title1);

        waitForTextVisible(driver, title1);
        clickOnElementWhenClickable(driver, tag1_);

        waitForTextNotVisible(driver, title2);

        clickOnElementWhenClickable(driver, cardsPage.deleteTagFilter);

        waitForTextVisible(driver, title2);

        rest.deleteCardByTitle(title1);
        rest.deleteCardByTitle(title2);
    }
}
