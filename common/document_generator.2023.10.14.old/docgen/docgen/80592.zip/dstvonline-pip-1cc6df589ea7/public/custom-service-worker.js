

self.addEventListener('push', function(e) {

    let payload = e.data.json();
    let body;

    if (e.data) {
        body = payload.message;
    } else {
        body = 'Push message no payload';
    }

    var options = {
        body: body,
        icon: './icon/favicon-192x192.png',
        badge: './icon/badge-192x192.png',
        vibrate: [100, 50, 100],
        tag: "pip",
        data: {
            reference: payload.reference,
        },
    };
    e.waitUntil(
        self.registration.showNotification('Pip Notification', options)
    );
});

self.addEventListener('notificationclick', function(e) {
    console.log(e);
    var notification = e.notification;
    var action = e.action;

    if (action === 'close') {
        notification.close();
    } else {
        clients.openWindow('https://pip.dstv.com/card/'+notification.data.reference);
        notification.close();
    }
});