#!/bin/bash
set -e

DO_INTEGRATION_ENV=

function f_read_args {
	echo "=> Reading args..."
	echo $@
	while test $# -gt 0
	do
	    case "$1" in
		--integration-env)
			DO_INTEGRATION_ENV=1
		    ;;
	    esac
	    shift
	done
}

function f_build_maven_package {
	echo
	echo "##############################################"
	echo "            Running maven package...         "
	echo "##############################################"
	echo
	rm -rf target
	mvn clean package -DskipTests=true -Dtest.profile=local
}

function f_build_docker_image {
	echo
	echo "##############################################"
	echo "            Building docker image...          "
	echo "##############################################"
	echo

	echo "=> Setup docker build directory"
	mkdir -p target/docker
	cp docker/Dockerfile target/docker

	echo "=> Copying jar folder..."
	cp target/*.jar target/docker/pip.jar

	echo "=> Building image..."
	docker build -t bigdata/pip target/docker
}

function f_docker_clean_up {
    docker ps -aq --no-trunc | xargs docker rm || true
    docker rmi $(docker images -f "dangling=true" -q)s || true
}

function f_integration_env {

    f_build_maven_package
	f_build_docker_image

	echo
	echo "################################################################"
	echo "            Starting up integration test environment...         "
	echo "################################################################"


	docker-compose --file src/test/resources/debug-compose.yml down --remove-orphans || true

	docker-compose --file src/test/resources/debug-compose.yml up --exit-code-from pip
	docker-compose --file src/test/resources/debug-compose.yml down --remove-orphans


    f_docker_clean_up
}

function f_main {
	clear
	f_read_args "$@"

	if [[ -n ${DO_INTEGRATION_ENV} ]]
	then
        f_integration_env
	fi
}

f_main "$@"